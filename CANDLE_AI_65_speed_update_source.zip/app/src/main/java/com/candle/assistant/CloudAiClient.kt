package com.candle.assistant

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Direct Google Apps Script client. API keys remain in Apps Script properties, never in the APK. */
class CloudAiClient(private val backendUrl: String = DEFAULT_ENDPOINT) {
    companion object {
        const val DEFAULT_ENDPOINT = "https://script.google.com/macros/s/AKfycbz5LD9togwHN1Vk00rxaMsVoY-h54g5NpcTC76WqADdq7G3N3YTHGWh-Jtju30PsFg3Rw/exec"
    }

    fun analyzeChart(imageBytes: ByteArray, platform: String): CloudAnalysisResult {
        if (imageBytes.isEmpty()) return CloudAnalysisResult.Failure("الصورة فارغة")
        if (imageBytes.size > 7 * 1024 * 1024) return CloudAnalysisResult.Failure("حجم صورة الشارت كبير؛ قلّل دقتها")
        val endpoint = try { URL(backendUrl) } catch (_: Exception) {
            return CloudAnalysisResult.Failure("عنوان خدمة Gemini غير صحيح")
        }
        if (endpoint.protocol != "https") return CloudAnalysisResult.Failure("يجب استخدام HTTPS")

        var first: HttpURLConnection? = null
        var redirected: HttpURLConnection? = null
        return try {
            val payload = JSONObject()
                .put("platform", platform.take(80))
                .put("image_base64", Base64.encodeToString(imageBytes, Base64.NO_WRAP))
                .toString().toByteArray(Charsets.UTF_8)

            val postConnection = (endpoint.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20000
                readTimeout = 90000
                doOutput = true
                instanceFollowRedirects = false
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                setFixedLengthStreamingMode(payload.size)
            }
            first = postConnection
            postConnection.outputStream.use { it.write(payload) }
            var code = postConnection.responseCode
            var body = ""

            // Apps Script ContentService commonly redirects POST responses to googleusercontent.
            if (code in 300..399) {
                val location = postConnection.getHeaderField("Location")
                    ?: return CloudAnalysisResult.Failure("أعاد Google تحويل الطلب دون عنوان نتيجة")
                val target = URL(endpoint, location)
                if (target.protocol != "https" ||
                    !(target.host == "script.googleusercontent.com" || target.host.endsWith(".googleusercontent.com"))) {
                    return CloudAnalysisResult.Failure("رابط إعادة التوجيه من Google غير متوقع")
                }
                val getConnection = (target.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 20000
                    readTimeout = 90000
                    instanceFollowRedirects = true
                    setRequestProperty("Accept", "application/json")
                }
                redirected = getConnection
                code = getConnection.responseCode
                body = readBody(getConnection, code)
            } else {
                body = readBody(postConnection, code)
            }

            if (code !in 200..299) {
                val detail = try { JSONObject(body).optString("error", "") } catch (_: Exception) { "" }
                CloudAnalysisResult.Failure(if (detail.isNotBlank()) detail.take(240) else "خدمة Google أعادت HTTP $code: ${body.take(160)}")
            } else {
                val json = try { JSONObject(body) } catch (_: Exception) { null }
                val analysis = json?.optString("analysis", "")?.trim().orEmpty()
                if (analysis.isNotBlank()) CloudAnalysisResult.Success(analysis)
                else {
                    val detail = json?.optString("error", "")?.trim().orEmpty()
                    CloudAnalysisResult.Failure(detail.ifBlank { "وصل الرد من Google لكن لم نجد حقل analysis؛ تحقق من إصدار Apps Script المنشور" }.take(240))
                }
            }
        } catch (_: java.net.SocketTimeoutException) {
            CloudAnalysisResult.Failure("انتهت مهلة Gemini بعد إرسال الصورة؛ سيعيد التطبيق المحاولة في الدورة التالية")
        } catch (e: Exception) {
            CloudAnalysisResult.Failure("تعذر الاتصال بـ Gemini: ${(e.message ?: e.javaClass.simpleName).take(180)}")
        } finally {
            try { redirected?.disconnect() } catch (_: Exception) {}
            try { first?.disconnect() } catch (_: Exception) {}
        }
    }

    private fun readBody(connection: HttpURLConnection, code: Int): String {
        val stream = if (code in 200..299 || code in 300..399) connection.inputStream else connection.errorStream
        return stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
    }
}
