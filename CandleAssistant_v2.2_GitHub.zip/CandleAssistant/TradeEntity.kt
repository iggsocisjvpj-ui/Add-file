package com.candle.assistant

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trade_history")
data class TradeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val signalType: String,
    val confidenceScore: Int,
    val timeframe: String,
    val result: String
)
