package com.candle.assistant

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TradeDao {
    @Insert
    suspend fun insertTrade(trade: TradeEntity)

    @Query("SELECT * FROM trade_history ORDER BY timestamp DESC")
    suspend fun getAllTrades(): List<TradeEntity>

    @Query("SELECT COUNT(*) FROM trade_history WHERE result = 'SUCCESS'")
    suspend fun getSuccessCount(): Int

    @Query("SELECT COUNT(*) FROM trade_history WHERE result = 'FAILED'")
    suspend fun getFailureCount(): Int
}
