package com.candle.assistant

enum class SignalType {
    BUY, SELL, WAIT, NO_ACTION
}

data class SignalResult(
    val type: SignalType,
    val suggestedEntryTime: String,
    val suggestedDuration: String,
    val confidenceScore: Int,
    val reasons: List<String>,
    val invalidationReasons: List<String>
)
