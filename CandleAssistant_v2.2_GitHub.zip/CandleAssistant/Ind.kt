package com.candle.assistant

import kotlin.math.abs

object Ind {

    fun calculateEMA(prices: List<Double>, period: Int): List<Double> {
        if (prices.isEmpty()) return emptyList()
        val emaList = mutableListOf<Double>()
        val multiplier = 2.0 / (period + 1)
        var prevEMA = prices.first()
        emaList.add(prevEMA)

        for (i in 1 until prices.size) {
            val currentEMA = (prices[i] - prevEMA) * multiplier + prevEMA
            emaList.add(currentEMA)
            prevEMA = currentEMA
        }
        return emaList
    }

    fun calculateRSI(prices: List<Double>, period: Int = 14): Double {
        if (prices.size < period + 1) return 50.0
        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val diff = prices[prices.size - period + i - 1] - prices[prices.size - period + i - 2]
            if (diff >= 0) gains += diff else losses -= diff
        }

        val avgGain = gains / period
        val avgLoss = losses / period
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun evaluateMarket(
        closes: List<Double>,
        highs: List<Double>,
        lows: List<Double>,
        sensitivity: Int = 3,
        minConfidence: Int = 58
    ): SignalResult {
        if (closes.size < 5) {
            return SignalResult(
                SignalType.NO_ACTION,
                "-",
                "-",
                0,
                listOf("البيانات غير كافية لعمل التحليل الفني (يلزم المزيد من الشموع)"),
                listOf("انتظار اكتشاف باقي الشموع من الشاشة")
            )
        }

        val emaShortPeriod = if (sensitivity >= 4) 5 else 9
        val emaLongPeriod = if (sensitivity >= 4) 12 else 21

        val emaShort = calculateEMA(closes, emaShortPeriod).lastOrNull() ?: closes.last()
        val emaLong = calculateEMA(closes, emaLongPeriod).lastOrNull() ?: closes.last()
        val rsi = calculateRSI(closes)

        val reasons = mutableListOf<String>()
        val invalidation = mutableListOf<String>()
        var score = 0

        val isBullishTrend = emaShort > emaLong
        val isBearishTrend = emaShort < emaLong

        if (isBullishTrend) {
            score += 45
            reasons.add("تقاطع إيجابي: EMA $emaShortPeriod أعلى من EMA $emaLongPeriod")
            invalidation.add("انخفاض السعر وتقاطع EMA سلباً")
        } else if (isBearishTrend) {
            score += 45
            reasons.add("تقاطع سلبي: EMA $emaShortPeriod أقل من EMA $emaLongPeriod")
            invalidation.add("ارتفاع السعر وتقاطع EMA إيجاباً")
        }

        when {
            rsi > 55.0 -> {
                score += 35
                reasons.add("مؤشر RSI يدعم الزخم الصاعد ($rsi)")
            }
            rsi < 45.0 -> {
                score += 35
                reasons.add("مؤشر RSI يدعم الزخم الهابط ($rsi)")
            }
            else -> {
                score -= 10
                reasons.add("مؤشر RSI في منطقة تذبذب محايدة ($rsi)")
            }
        }

        if (score < minConfidence) {
            return SignalResult(
                SignalType.WAIT,
                "-",
                "-",
                score,
                listOf("نسبة التوافق ($score%) أقل من الحد الأدنى للثقة المحددة ($minConfidence%)"),
                listOf("زيادة وضوح الاتجاه العام للسوق")
            )
        }

        return when {
            score >= minConfidence && isBullishTrend -> SignalResult(
                SignalType.BUY,
                "عند إغلاق الشمعة الحالية",
                "مدة شمعة واحدة",
                score,
                reasons,
                invalidation
            )
            score >= minConfidence && isBearishTrend -> SignalResult(
                SignalType.SELL,
                "عند إغلاق الشمعة الحالية",
                "مدة شمعة واحدة",
                score,
                reasons,
                invalidation
            )
            else -> SignalResult(
                SignalType.NO_ACTION,
                "-",
                "-",
                score,
                listOf("شروط الدخول غير متوافقة"),
                listOf("تغير الاتجاه")
            )
        }
    }
}
