package com.candle.assistant

import android.graphics.Bitmap
import android.graphics.Color

object ScreenProcessor {

    data class ChartConfig(
        val startYPercent: Int = 12,
        val endYPercent: Int = 60,
        val candleDurationSec: Int = 60,
        val minConfidence: Int = 58,
        val sensitivity: Int = 3
    )

    fun processBitmap(bitmap: Bitmap, config: ChartConfig): Pair<Double, Double> {
        val width = bitmap.width
        val height = bitmap.height

        val startY = (height * config.startYPercent) / 100
        val endY = (height * config.endYPercent) / 100

        var greenPixelCount = 0
        var redPixelCount = 0

        val stepX = 5
        val stepY = 5

        for (x in 0 until width step stepX) {
            for (y in startY until endY step stepY) {
                val pixel = bitmap.getPixel(x, y)
                val red = Color.red(pixel)
                val green = Color.green(pixel)
                val blue = Color.blue(pixel)

                if (green > 160 && red < 120 && blue < 120) {
                    greenPixelCount++
                } else if (red > 160 && green < 120 && blue < 120) {
                    redPixelCount++
                }
            }
        }

        val totalDetected = (greenPixelCount + redPixelCount).toDouble()
        val closeValue = if (totalDetected > 0) {
            1.0 + (greenPixelCount - redPixelCount) / totalDetected
        } else {
            1.0
        }

        return Pair(closeValue, totalDetected)
    }
}
