# Candle Assistant v2.2 (Android)

محلل تداول محمول يعمل على أجهزة أندرويد لـ Pocket Option والمؤشرات الفنية.

## المكونات الأساسية:
- `Signal.kt`: إدارة الحالات والأسباب.
- `Ind.kt`: حساب EMA و RSI وضبط الحساسية.
- `ScreenProcessor.kt`: قراءة الشاشة وتحليل البكسلات.
- `CaptureService.kt`: خدمة الخلفية لحماية القارئ.
- `AppDatabase.kt` / `TradeDao.kt` / `TradeEntity.kt`: قاعدة بيانات Room لتسجيل وتوثيق النتائج.
