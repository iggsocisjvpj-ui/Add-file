package com.candle.assistant

class CandleBuffer(private val capacity: Int = 100) {
    private val closePrices = mutableListOf<Double>()
    val highPrices = mutableListOf<Double>()
    val lowPrices = mutableListOf<Double>()

    fun addCandle(close: Double, high: Double, low: Double) {
        if (closePrices.size >= capacity) {
            closePrices.removeAt(0)
            highPrices.removeAt(0)
            lowPrices.removeAt(0)
        }
        closePrices.add(close)
        highPrices.add(high)
        lowPrices.add(low)
    }

    fun getCloses(): List<Double> = closePrices.toList()
    fun getHighs(): List<Double> = highPrices.toList()
    fun getLows(): List<Double> = lowPrices.toList()
}
