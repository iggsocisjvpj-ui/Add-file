plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// توقيع ثابت: لازم يكون نفس المفتاح في كل بناء، حتى يتحدّث التطبيق فوق النسخة القديمة
// بدون حذفها، فتبقى البيانات (السجل، الإحصائيات، ملفات xlsx المستوردة).
// المفتاح يأتي من متغيرات البيئة في GitHub Actions. إذا لم تتوفر، يُستخدم مفتاح التصحيح.
val ksPath: String? = System.getenv("KEYSTORE_PATH")
val ksPass: String? = System.getenv("KEYSTORE_PASSWORD")
val ksAlias: String? = System.getenv("KEY_ALIAS")
val ksKeyPass: String? = System.getenv("KEY_PASSWORD")
val hasStableKey = !ksPath.isNullOrBlank() && !ksPass.isNullOrBlank() && !ksAlias.isNullOrBlank() && !ksKeyPass.isNullOrBlank()

// رقم البناء يجب أن يزيد في كل مرة، وإلا يرفض أندرويد التحديث
val buildNumber: Int = (System.getenv("BUILD_NUMBER")?.toIntOrNull() ?: 0) + 1000

android {
    namespace = "com.candle.assistant"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.candle.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = buildNumber
        versionName = "3.$buildNumber"
    }
    signingConfigs {
        if (hasStableKey) {
            create("stable") {
                storeFile = file(ksPath!!)
                storePassword = ksPass
                keyAlias = ksAlias
                keyPassword = ksKeyPass
            }
        }
    }
    buildTypes {
        getByName("debug") {
            if (hasStableKey) signingConfig = signingConfigs.getByName("stable")
        }
        getByName("release") {
            if (hasStableKey) signingConfig = signingConfigs.getByName("stable")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
