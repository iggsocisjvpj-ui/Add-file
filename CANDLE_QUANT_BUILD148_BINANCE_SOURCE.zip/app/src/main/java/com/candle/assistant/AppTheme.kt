package com.candle.assistant

import android.graphics.Color

/**
 * لوحة ألوان موحّدة للتطبيق: داكنة، هادئة، مع لون تمييز واحد.
 * أي تغيير هنا ينعكس على الشاشة الرئيسية كاملة.
 */
object AppTheme {
    // الخلفيات
    val BG: Int = Color.rgb(11, 16, 28)            // خلفية الشاشة
    val SURFACE: Int = Color.rgb(20, 28, 44)       // حقول الإدخال والبطاقات
    val SURFACE_ALT: Int = Color.rgb(28, 39, 60)   // بطاقات مرتفعة قليلاً

    // النصوص
    val TEXT: Int = Color.rgb(234, 240, 248)
    val TEXT_MUTED: Int = Color.rgb(139, 153, 176)

    // الألوان الدلالية
    val ACCENT: Int = Color.rgb(92, 160, 230)      // عناوين الأقسام
    val BUTTON: Int = Color.rgb(44, 104, 178)      // الأزرار الأساسية
    val SUCCESS: Int = Color.rgb(46, 160, 90)
    val DANGER: Int = Color.rgb(196, 62, 62)
    val WARNING: Int = Color.rgb(214, 150, 40)
    val DIVIDER: Int = Color.rgb(42, 56, 82)

    // الأبعاد
    const val RADIUS_DP = 14f
    const val RADIUS_BUTTON_DP = 16f
}
