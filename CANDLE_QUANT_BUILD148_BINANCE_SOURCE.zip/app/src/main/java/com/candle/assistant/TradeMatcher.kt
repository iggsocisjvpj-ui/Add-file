package com.candle.assistant

/**
 * قراءة تفاصيل صفقة مغلقة من لقطة شاشة للمنصة، ومطابقتها مع صفقات السجل بالوقت (بتوقيت UTC كما تعرضه المنصة).
 * المطابقة: نفس الزوج والاتجاه، وفرق الوقت لا يتجاوز 3 ثوانٍ.
 */
object TradeMatcher {

    data class Detail(
        val pair: String,        // مثل CHF/NOK
        val side: Int,           // 1 شراء، -1 بيع
        val openSec: Double,     // ثواني منذ منتصف الليل UTC
        val closeSec: Double,
        val openPrice: Double,
        val closePrice: Double
    )

    private val pairRe = Regex("([A-Z]{3}/[A-Z]{3})")
    private val timeRe = Regex("(\\d{2}):(\\d{2}):(\\d{2})(?:\\.(\\d+))?")
    private val numRe = Regex("(\\d+\\.\\d+)")

    /** يحلل نص لقطة تفاصيل الصفقة. يرجع null إن لم تكتمل الحقول */
    fun parse(text: String): Detail? {
        val pair = pairRe.find(text)?.groupValues?.get(1) ?: return null
        val times = timeRe.findAll(text).map { m ->
            val sec = m.groupValues[1].toDouble() * 3600 + m.groupValues[2].toDouble() * 60 + m.groupValues[3].toDouble()
            val frac = m.groupValues[4]
            if (frac.isNotEmpty()) sec + ("0.$frac").toDouble() else sec
        }.toList()
        if (times.size < 2) return null
        val openP = priceAfter(text, "سعر الفتح") ?: return null
        val closeP = priceAfter(text, "سعر الإغلاق") ?: return null
        val side = when {
            text.contains("بيع") -> -1
            text.contains("شراء") -> 1
            else -> return null
        }
        return Detail(pair, side, times[0], times[1], openP, closeP)
    }

    private fun priceAfter(text: String, label: String): Double? {
        val i = text.indexOf(label)
        if (i < 0) return null
        val m = numRe.find(text, i + label.length) ?: return null
        return m.value.toDoubleOrNull()
    }
}
