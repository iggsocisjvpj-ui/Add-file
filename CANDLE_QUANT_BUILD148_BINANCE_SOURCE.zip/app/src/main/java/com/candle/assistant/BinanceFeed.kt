package com.candle.assistant

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

/**
 * أسعار Binance العامة (بيانات الشموع فقط، بدون مفتاح API ولا تداول).
 * هذه أسعار حقيقية مباشرة من المصدر، فلا تعتمد على قراءة الشاشة ولا على المعايرة.
 * لا تُرسل أي صفقة إلى Binance من هذا الملف.
 */
object BinanceFeed {
    private const val BASE = "https://api.binance.com/api/v3/klines"
    private const val MAX_AGE_MS = 120_000L
    private const val REFRESH_MS = 15_000L

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    @Volatile private var cache: List<Candle> = emptyList()
    @Volatile private var cacheAt: Long = 0L
    @Volatile private var fetching = false
    @Volatile var lastError: String = ""

    /** المصدر مفعّل من الإعدادات (1 = Binance) */
    fun isOn(c: Context): Boolean =
        c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("priceSource", 0) == 1

    private fun symbol(c: Context): String =
        (c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("binSymbol", "BTCUSDT") ?: "BTCUSDT")
            .trim().uppercase().ifBlank { "BTCUSDT" }

    private fun interval(c: Context): String =
        c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("binInterval", "1m") ?: "1m"

    /** يعيد الشموع الحالية إن كانت حديثة، ويبدأ تحديثاً في الخلفية عند الحاجة */
    fun readOrFallback(c: Context): List<Candle> {
        refreshIfStale(c)
        val now = System.currentTimeMillis()
        return if (cache.isNotEmpty() && now - cacheAt < MAX_AGE_MS) cache else emptyList()
    }

    private fun refreshIfStale(c: Context) {
        val now = System.currentTimeMillis()
        if (fetching || now - cacheAt < REFRESH_MS) return
        fetching = true
        val sym = symbol(c)
        val itv = interval(c)
        Thread {
            try {
                val url = "$BASE?symbol=$sym&interval=$itv&limit=200"
                val req = Request.Builder().url(url).header("Accept", "application/json").build()
                http.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        lastError = "Binance HTTP ${resp.code}: ${body.take(200)}"
                        return@use
                    }
                    val arr = JSONArray(body)
                    val out = ArrayList<Candle>(arr.length())
                    for (i in 0 until arr.length()) {
                        val k = arr.getJSONArray(i)
                        // [openTime, open, high, low, close, volume, ...]
                        val o = k.getString(1).toDouble()
                        val h = k.getString(2).toDouble()
                        val l = k.getString(3).toDouble()
                        val cl = k.getString(4).toDouble()
                        if (h < l || o <= 0.0) continue
                        out.add(Candle(open = o, close = cl, high = h, low = l))
                    }
                    if (out.isNotEmpty()) {
                        cache = out
                        cacheAt = System.currentTimeMillis()
                        lastError = ""
                    }
                }
            } catch (e: Exception) {
                lastError = "تعذر الاتصال بـ Binance: ${e.message}"
            } finally {
                fetching = false
            }
        }.start()
    }
}
