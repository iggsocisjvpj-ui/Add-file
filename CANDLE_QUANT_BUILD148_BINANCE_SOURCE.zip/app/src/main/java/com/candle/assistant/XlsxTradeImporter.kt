package com.candle.assistant

import android.content.Context
import android.net.Uri
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.SimpleTimeZone
import java.util.zip.ZipInputStream

/**
 * استيراد ملف xlsx الذي يصدّره Pocket Option (export_history_*.xlsx)
 * ويحفظ الصفقات محلياً في ملف داخل التطبيق، مع فصل النتائج حسب العملة.
 * يقرأ الأعمدة بالاسم من الصف الأول، فلا يعتمد على ترتيبها.
 */
object XlsxTradeImporter {
    private const val STORE_FILE = "imported_trades.json"
    /** توقيت فتح الصفقة في الملف؛ غيّره إذا كان توقيت المنصة مختلفاً */
    private const val PLATFORM_TZ_OFFSET_MIN = 0

    data class Trade(
        val order: String, val direction: String, val durationSec: Int,
        val asset: String, val openMs: Long, val closeMs: Long,
        val openPrice: Double, val closePrice: Double,
        val amount: Double, val profit: Double, val currency: String
    ) {
        val win: Boolean get() = profit > 0
    }

    /** يقرأ الملف من Uri (ملف اختاره المستخدم) ويضيف الصفقات الجديدة فقط */
    fun import(c: Context, uri: Uri): Int {
        val input = c.contentResolver.openInputStream(uri) ?: return 0
        val parsed = input.use { readXlsx(it) }
        val existing = load(c)
        val seen = HashSet<String>()
        for (i in 0 until existing.length()) seen.add(existing.getJSONObject(i).getString("order"))
        val fresh = ArrayList<Trade>()
        for (t in parsed) {
            if (!seen.add(t.order)) continue
            existing.put(toJson(t))
            fresh.add(t)
        }
        save(c, existing)
        // نفس مسار الاستيراد الحالي للسجل: الدمج وإزالة المكرر وحد 5000 يطبق تلقائياً،
        // والمحلل والتعلم يقرآن هذا السجل كما يفعلان مع CSV/JSON.
        if (fresh.isNotEmpty()) TradeJournal.importCsv(c, journalCsv(fresh))
        return fresh.size
    }

    /**
     * يحوّل الصفقات إلى صيغة CSV التي يقرأها السجل الحالي:
     * time,symbol,side,result,hour,entrySec,moveTag,conf
     * call = BUY وput = SELL. أضفنا إزاحة من مللي ثانية ثابتة لكل صفقة (من رقم الطلب)،
     * لأن السجل يزيل المكرر بالوقت والزوج والاتجاه، وإلا ستُدمج صفقات فُتحت في الثانية نفسها.
     */
    fun journalCsv(list: List<Trade>): String {
        val sb = StringBuilder("time,symbol,side,result,hour,entrySec,moveTag,conf\n")
        for (t in list) {
            val side = if (t.direction == "call") "BUY" else "SELL"
            val result = if (t.win) "WIN" else "LOSS"
            val time = t.openMs + (Math.abs(t.order.hashCode()) % 1000)
            sb.append(time).append(',').append(t.asset).append(',').append(side).append(',')
                .append(result).append(",,,,0\n")
        }
        return sb.toString()
    }

    fun all(c: Context): List<Trade> {
        val arr = load(c)
        return (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }
    }

    /** تقرير مفصول لكل عملة: العدد ونسبة الربح والصافي وحسب المدة */
    fun report(c: Context, currency: String): String {
        val rs = all(c).filter { it.currency == currency }
        if (rs.isEmpty()) return "لا توجد صفقات بعملة $currency."
        val wins = rs.count { it.win }
        val net = rs.sumOf { it.profit }
        val sb = StringBuilder()
        sb.append("العملة $currency: ${rs.size} صفقة، ربح $wins، نسبة ${"%.1f".format(100.0 * wins / rs.size)}%، ")
        sb.append("الصافي ${"%.2f".format(net)}\n")
        val byDur = rs.groupBy { it.durationSec }.toSortedMap()
        for ((d, list) in byDur) {
            if (list.size < 5) continue
            val w = list.count { it.win }
            sb.append("  مدة ${d}ث: ${list.size} صفقة، ${"%.1f".format(100.0 * w / list.size)}%، صافي ${"%.2f".format(list.sumOf { it.profit })}\n")
        }
        return sb.toString().trimEnd()
    }

    fun currencies(c: Context): List<String> = all(c).map { it.currency }.distinct()

    fun reset(c: Context) { File(c.filesDir, STORE_FILE).delete() }

    // ---------- قراءة xlsx بدون مكتبات خارجية ----------

    private fun readXlsx(input: java.io.InputStream): List<Trade> {
        var shared: List<String> = emptyList()
        var sheetXml: ByteArray? = null
        ZipInputStream(input).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                when (e.name) {
                    "xl/sharedStrings.xml" -> shared = parseSharedStrings(zip.readBytes())
                    "xl/worksheets/sheet1.xml" -> sheetXml = zip.readBytes()
                }
                e = zip.nextEntry
            }
        }
        val xml = sheetXml ?: return emptyList()
        val rows = parseRows(xml, shared)
        if (rows.isEmpty()) return emptyList()
        val header = rows[0].mapIndexed { i, v -> v.trim() to i }.toMap()
        fun col(name: String): Int = header[name] ?: -1
        val iDir = col("Direction"); val iOrd = col("Order"); val iDur = col("Duration")
        val iAsset = col("Asset"); val iOpen = col("Open time"); val iClose = col("Close time")
        val iOp = col("Open price"); val iCp = col("Close price"); val iAmt = col("Trade amount")
        val iPro = col("Profit"); val iCur = col("Currency")
        if (listOf(iDir, iOrd, iAsset, iOpen, iPro).any { it < 0 }) return emptyList()

        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply {
            timeZone = SimpleTimeZone(PLATFORM_TZ_OFFSET_MIN * 60000, "P")
        }
        fun cell(r: List<String>, i: Int) = if (i in r.indices) r[i].trim() else ""
        fun num(s: String) = s.toDoubleOrNull() ?: 0.0
        fun ms(s: String) = try { fmt.parse(s)?.time ?: 0L } catch (_: Exception) { 0L }

        val out = ArrayList<Trade>()
        for (r in rows.drop(1)) {
            val order = cell(r, iOrd)
            if (order.isEmpty()) continue
            out.add(Trade(
                order = order,
                direction = cell(r, iDir).lowercase(),
                durationSec = cell(r, iDur).removePrefix("S").toIntOrNull() ?: 0,
                asset = cell(r, iAsset),
                openMs = ms(cell(r, iOpen)),
                closeMs = ms(cell(r, iClose)),
                openPrice = num(cell(r, iOp)),
                closePrice = num(cell(r, iCp)),
                amount = num(cell(r, iAmt)),
                profit = num(cell(r, iPro)),
                currency = cell(r, iCur).ifEmpty { "?" }
            ))
        }
        return out
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val p = Xml.newPullParser()
        p.setInput(bytes.inputStream(), "UTF-8")
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inSi = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "si" -> { inSi = true; sb.setLength(0) }
                    "t" -> if (inSi) sb.append(p.nextText())
                }
                XmlPullParser.END_TAG -> if (p.name == "si") { out.add(sb.toString()); inSi = false }
            }
            ev = p.next()
        }
        return out
    }

    /** يعيد الصفوف كقوائم نصوص مرتبة حسب الأعمدة (A=0، B=1 ...) */
    private fun parseRows(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val p = Xml.newPullParser()
        p.setInput(bytes.inputStream(), "UTF-8")
        val rows = ArrayList<List<String>>()
        val cur = HashMap<Int, String>()
        var cellCol = -1
        var cellType = ""
        var inV = false
        var inIs = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> cur.clear()
                    "c" -> {
                        cellType = p.getAttributeValue(null, "t") ?: ""
                        val ref = p.getAttributeValue(null, "r") ?: ""
                        cellCol = colIndex(ref)
                    }
                    "v" -> inV = true
                    "is" -> inIs = true
                    "t" -> if (inIs) cur[cellCol] = (cur[cellCol] ?: "") + p.nextText()
                }
                XmlPullParser.TEXT -> if (inV && cellCol >= 0) {
                    val raw = p.text
                    cur[cellCol] = if (cellType == "s") shared.getOrElse(raw.toIntOrNull() ?: -1) { "" } else raw
                }
                XmlPullParser.END_TAG -> when (p.name) {
                    "v" -> inV = false
                    "is" -> inIs = false
                    "row" -> {
                        val max = cur.keys.maxOrNull() ?: -1
                        rows.add(List(max + 1) { cur[it] ?: "" })
                    }
                }
            }
            ev = p.next()
        }
        return rows
    }

    /** A → 0، B → 1، ... AA → 26 */
    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (ch.isLetter()) n = n * 26 + (ch.uppercaseChar() - 'A' + 1) else break
        }
        return n - 1
    }

    // ---------- تخزين محلي ----------

    private fun toJson(t: Trade) = JSONObject()
        .put("order", t.order).put("direction", t.direction).put("dur", t.durationSec)
        .put("asset", t.asset).put("open", t.openMs).put("close", t.closeMs)
        .put("op", t.openPrice).put("cp", t.closePrice).put("amt", t.amount)
        .put("profit", t.profit).put("cur", t.currency)

    private fun fromJson(o: JSONObject) = Trade(
        order = o.getString("order"), direction = o.getString("direction"),
        durationSec = o.getInt("dur"), asset = o.getString("asset"),
        openMs = o.getLong("open"), closeMs = o.getLong("close"),
        openPrice = o.getDouble("op"), closePrice = o.getDouble("cp"),
        amount = o.getDouble("amt"), profit = o.getDouble("profit"),
        currency = o.getString("cur")
    )

    private fun load(c: Context): JSONArray {
        val f = File(c.filesDir, STORE_FILE)
        return try { if (f.exists()) JSONArray(f.readText()) else JSONArray() } catch (_: Exception) { JSONArray() }
    }

    private fun save(c: Context, arr: JSONArray) {
        File(c.filesDir, STORE_FILE).writeText(arr.toString())
    }
}
