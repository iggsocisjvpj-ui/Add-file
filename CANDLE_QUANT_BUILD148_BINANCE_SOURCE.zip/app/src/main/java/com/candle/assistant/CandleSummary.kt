package com.candle.assistant

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * يحوّل آخر N شمعة إلى بيانات رقمية ومؤشرات فنية وكمية، ترسل مع صورة الشارت إلى Gemini.
 * كل المؤشرات تُحسب محلياً، فيكون التحليل الفني والكمي مبنياً على الشموع نفسها (لا على تخمين).
 */
object CandleSummary {
    const val DEFAULT_COUNT = 120
    private const val MIN_CANDLES = 15   // التحليل من أول 15 شمعة مكتملة

    fun build(all: List<Candle>, count: Int = DEFAULT_COUNT): JSONObject? {
        if (all.size < MIN_CANDLES) return null
        val c = all.takeLast(max(MIN_CANDLES, count))
        val closes = c.map { it.close }
        val highs = c.map { it.high }
        val lows = c.map { it.low }

        val ema20 = ema(closes, 20)
        val ema50 = ema(closes, 50)
        val rsi14 = rsi(closes, 14)
        val atr14 = atr(c, 14)
        val last = c.size - 1
        val mean20 = closes.takeLast(20).average()
        val sd20 = sd(closes.takeLast(20), mean20)

        val candles = JSONArray()
        for (x in c) {
            candles.put(JSONArray(listOf(round(x.open), round(x.high), round(x.low), round(x.close))))
        }

        val tech = JSONObject()
            .put("last_close", round(closes[last]))
            .put("ema20", round(ema20[last]))
            .put("ema50", round(ema50[last]))
            .put("ema20_slope_10", round(ema20[last] - ema20[max(0, last - 10)]))
            .put("trend", when {
                ema20[last] > ema50[last] && closes[last] > ema20[last] -> "UP"
                ema20[last] < ema50[last] && closes[last] < ema20[last] -> "DOWN"
                else -> "RANGE"
            })
            .put("rsi14", round(rsi14[last]))
            .put("atr14", round(atr14[last]))
            .put("bb_upper", round(mean20 + 2 * sd20))
            .put("bb_mid", round(mean20))
            .put("bb_lower", round(mean20 - 2 * sd20))
            .put("resistance_60", round(highs.takeLast(60).max()))
            .put("support_60", round(lows.takeLast(60).min()))
            .put("last3_colors", JSONArray(c.takeLast(3).map { if (it.close >= it.open) "GREEN" else "RED" }))

        // كمي: إحصاء الحركة والاحتمالات التاريخية داخل النافذة نفسها
        val rets = closes.zipWithNext { a, b -> b - a }
        val ups = rets.count { it > 0 }
        val upRatio = ups.toDouble() / rets.size
        val avgAbs = rets.map { abs(it) }.average()
        // احتمال الاستمرار: بعد شمعة صاعدة، كم مرة تلتها صاعدة؟
        var afterUp = 0; var afterUpNext = 0; var afterDown = 0; var afterDownNext = 0
        for (i in 1 until c.size - 1) {
            val prevUp = c[i - 1].close >= c[i - 1].open
            val nextUp = c[i + 1].close >= c[i + 1].open
            if (prevUp) { afterUp++; if (nextUp) afterUpNext++ } else { afterDown++; if (nextUp) afterDownNext++ }
        }
        val quant = JSONObject()
            .put("window_candles", c.size)
            .put("up_ratio", round(upRatio))
            .put("avg_abs_move", round(avgAbs))
            .put("p_up_after_up", if (afterUp > 0) round(afterUpNext.toDouble() / afterUp) else JSONObject.NULL)
            .put("p_up_after_down", if (afterDown > 0) round(afterDownNext.toDouble() / afterDown) else JSONObject.NULL)
            .put("zscore_last", if (sd20 > 0) round((closes[last] - mean20) / sd20) else 0.0)

        return JSONObject()
            .put("candles_ohlc", candles)
            .put("technical", tech)
            .put("quantitative", quant)
    }

    private fun round(v: Double): Double = if (v.isNaN() || v.isInfinite()) 0.0 else Math.round(v * 100000.0) / 100000.0

    private fun ema(v: List<Double>, p: Int): DoubleArray {
        val out = DoubleArray(v.size)
        val k = 2.0 / (p + 1)
        out[0] = v[0]
        for (i in 1 until v.size) out[i] = v[i] * k + out[i - 1] * (1 - k)
        return out
    }

    private fun rsi(v: List<Double>, p: Int): DoubleArray {
        val out = DoubleArray(v.size) { 50.0 }
        if (v.size <= p) return out
        var gain = 0.0; var loss = 0.0
        for (i in 1..p) { val d = v[i] - v[i - 1]; if (d >= 0) gain += d else loss -= d }
        var ag = gain / p; var al = loss / p
        out[p] = if (al == 0.0) 100.0 else 100 - 100 / (1 + ag / al)
        for (i in p + 1 until v.size) {
            val d = v[i] - v[i - 1]
            ag = (ag * (p - 1) + max(d, 0.0)) / p
            al = (al * (p - 1) + max(-d, 0.0)) / p
            out[i] = if (al == 0.0) 100.0 else 100 - 100 / (1 + ag / al)
        }
        return out
    }

    private fun atr(c: List<Candle>, p: Int): DoubleArray {
        val tr = DoubleArray(c.size)
        for (i in c.indices) {
            tr[i] = if (i == 0) c[i].high - c[i].low else
                max(c[i].high - c[i].low, max(abs(c[i].high - c[i - 1].close), abs(c[i].low - c[i - 1].close)))
        }
        val out = DoubleArray(c.size)
        var s = 0.0
        for (i in c.indices) {
            if (i < p) { s += tr[i]; out[i] = s / (i + 1) }
            else { out[i] = (out[i - 1] * (p - 1) + tr[i]) / p }
        }
        return out
    }

    private fun sd(v: List<Double>, mean: Double): Double {
        if (v.size < 2) return 0.0
        return Math.sqrt(v.sumOf { (it - mean) * (it - mean) } / v.size)
    }
}
