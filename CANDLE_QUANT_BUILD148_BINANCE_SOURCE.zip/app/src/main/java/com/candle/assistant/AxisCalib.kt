package com.candle.assistant

/**
 * معايرة السعر من أرقام المحور الأيمن للشارت.
 * كل رقم مكتوب على المحور له موقع رأسي (y) وقيمة سعر، فنحسب خط الانحدار: السعر = m * y + c.
 * المعايرة تُقبل فقط إذا كانت نقاطها كافية ومتسقة، وإلا تبقى غير صالحة ولا تُستخدم.
 */
object AxisCalib {

    @Volatile var m: Double = Double.NaN
    @Volatile var c: Double = Double.NaN
    @Volatile var points: Int = 0
    @Volatile var maxError: Double = Double.NaN
    @Volatile var updatedAt: Long = 0L
    @Volatile var valid: Boolean = false
    @Volatile var status: String = "لم تُحسب المعايرة بعد"

    /** يُستدعى من الخدمة لعرض الحالة للمستخدم (مرة عند تغيّرها فقط) */
    var onStatus: ((String) -> Unit)? = null

    /** أقصى خطأ مسموح كنسبة من السعر (0.0002 = 0.02%) */
    private const val MAX_RELATIVE_ERROR = 0.0002

    /** pts: قائمة أزواج (y بالبكسل داخل صورة الشاشة، السعر المقروء) */
    fun update(pts: List<Pair<Double, Double>>) {
        val n = pts.size
        if (n < 3) {
            setStatus("المعايرة: نقاط غير كافية ($n من 3)", false, n)
            return
        }
        var sy = 0.0; var sp = 0.0; var syy = 0.0; var syp = 0.0
        for ((y, p) in pts) {
            sy += y; sp += p; syy += y * y; syp += y * p
        }
        val denom = n * syy - sy * sy
        if (denom == 0.0) {
            setStatus("المعايرة: أرقام المحور متطابقة الموقع", false, n)
            return
        }
        val slope = (n * syp - sy * sp) / denom
        val intercept = (sp - slope * sy) / n

        var worst = 0.0
        var avgPrice = 0.0
        for ((y, p) in pts) {
            val est = slope * y + intercept
            val err = kotlin.math.abs(est - p)
            if (err > worst) worst = err
            avgPrice += p
        }
        avgPrice /= n
        val relErr = if (avgPrice != 0.0) worst / kotlin.math.abs(avgPrice) else Double.MAX_VALUE
        val ok = relErr <= MAX_RELATIVE_ERROR && slope < 0.0 // السعر يزيد كلما صعد الموقع (y يقل)

        m = slope
        c = intercept
        points = n
        maxError = worst
        updatedAt = System.currentTimeMillis()
        valid = ok
        setStatus(
            if (ok) "المعايرة صالحة: $n نقاط، أقصى خطأ ${"%.5f".format(worst)}"
            else "المعايرة غير متسقة: $n نقاط، أقصى خطأ ${"%.5f".format(worst)}",
            ok, n
        )
    }

    /** المعايرة صالحة الآن (حديثة وصالحة) */
    fun isUsable(now: Long = System.currentTimeMillis()): Boolean =
        valid && now - updatedAt < 5000L

    /** تحويل موقع رأسي إلى سعر، أو NaN إن لم تكن المعايرة صالحة */
    fun priceAtY(y: Double): Double =
        if (isUsable()) m * y + c else Double.NaN

    private var lastNotified = ""
    private fun setStatus(msg: String, ok: Boolean, n: Int) {
        status = msg
        // إشعار المستخدم عند تغيّر الحالة فقط، لا عند كل تحديث
        val key = (if (ok) "ok" else "bad") + (if (n >= 3) "" else "few")
        if (key != lastNotified) {
            lastNotified = key
            onStatus?.invoke(msg)
        }
    }
}
