package com.candle.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * ذاكرة الأخطاء (نسخة 2):
 * عند كل دخول تُحفظ: الزوج، الفاصل، الاتجاه، سعر الدخول، وحركة آخر 20 شمعة قبل الدخول.
 * عند إشارة جديدة: إذا وُجد أكثر من 3 خسارات لصفقات بنفس الاتجاه
 * وبسعر قريب جداً ونفس حركة الشموع السابقة، تُمنع الإشارة.
 */
object MistakeMemory {
    private const val PREF = "mistake_memory"
    private const val CANDLES_BACK = 20
    private const val MAX_RECORDS = 3000

    /** أكثر من 3 خسارات متشابهة = منع */
    const val LOSS_LIMIT = 3
    /** نسبة فرق السعر المسموحة (0.0003 = 0.03% تقريباً، مثل 3 نقاط على EUR/USD) */
    var priceTolerance = 0.0003
    /** أقصى مسافة بين بصمتي حركة الشموع لاعتبارهما متشابهتين (0 = متطابقتان تماماً) */
    var movementTolerance = 0.35

    data class Verdict(val block: Boolean, val wins: Int, val losses: Int, val reason: String)

    /**
     * بصمة حركة الشموع: 40 رقماً = 20 قيمة لجسم كل شمعة (بين -1 و1)
     * + 20 قيمة لموقع إغلاق كل شمعة بالنسبة لسعر الدخول داخل نطاق الفترة.
     * يعود null إذا كانت الشموع أقل من 20.
     */
    fun movementVector(candles: List<Candle>, entryPrice: Double): DoubleArray? {
        if (candles.size < CANDLES_BACK || entryPrice <= 0.0) return null
        val w = candles.takeLast(CANDLES_BACK)
        val hi = w.maxOf { it.high }
        val lo = w.minOf { it.low }
        val range = (hi - lo).coerceAtLeast(1e-12)
        val v = DoubleArray(CANDLES_BACK * 2)
        for (i in w.indices) {
            val c = w[i]
            val cr = (c.high - c.low).coerceAtLeast(1e-12)
            v[i] = ((c.close - c.open) / cr).coerceIn(-1.0, 1.0)
            v[CANDLES_BACK + i] = ((c.close - entryPrice) / range).coerceIn(-2.0, 2.0)
        }
        return v
    }

    private fun distance(a: DoubleArray, b: DoubleArray): Double {
        var s = 0.0
        for (i in a.indices) { val d = a[i] - b[i]; s += d * d }
        return sqrt(s / a.size)
    }

    private fun samePrice(a: Double, b: Double): Boolean =
        abs(a - b) / b <= priceTolerance

    /** تسجيل صفقة مؤكدة عند نتيجتها. candles = الشموع لحظة الدخول، وentryPrice = سعر الدخول */
    fun record(
        c: Context, pair: String, tfSeconds: Int, side: Int,
        candles: List<Candle>, entryPrice: Double, win: Boolean,
        nowMs: Long = System.currentTimeMillis()
    ) {
        if (side == 0) return
        val v = movementVector(candles, entryPrice) ?: return
        val all = load(c)
        val rec = JSONObject()
            .put("t", nowMs)
            .put("pair", pair)
            .put("tf", tfSeconds)
            .put("side", if (side > 0) 1 else -1)
            .put("price", entryPrice)
            .put("win", win)
            .put("v", JSONArray().apply { v.forEach { put(it) } })
        all.put(rec)
        // الاحتفاظ بآخر MAX_RECORDS فقط
        val trimmed = JSONArray()
        val start = maxOf(0, all.length() - MAX_RECORDS)
        for (i in start until all.length()) trimmed.put(all.get(i))
        save(c, trimmed)
    }

    /** فحص الإشارة قبل عرضها */
    fun check(
        c: Context, pair: String, tfSeconds: Int, side: Int,
        candles: List<Candle>, entryPrice: Double
    ): Verdict {
        if (side == 0) return Verdict(false, 0, 0, "")
        val v = movementVector(candles, entryPrice)
            ?: return Verdict(false, 0, 0, "")   // شموع أقل من 20: لا فحص

        val all = load(c)
        var wins = 0
        var losses = 0
        val dir = if (side > 0) 1 else -1
        for (i in 0 until all.length()) {
            val r = all.optJSONObject(i) ?: continue
            if (r.optString("pair") != pair) continue
            if (r.optInt("tf") != tfSeconds) continue
            if (r.optInt("side") != dir) continue
            if (!samePrice(entryPrice, r.optDouble("price", Double.NaN))) continue
            val arr = r.optJSONArray("v") ?: continue
            if (arr.length() != v.size) continue
            val other = DoubleArray(v.size) { arr.optDouble(it, 0.0) }
            if (distance(v, other) > movementTolerance) continue
            if (r.optBoolean("win")) wins++ else losses++
        }

        if (losses > LOSS_LIMIT && losses > wins) {
            return Verdict(
                true, wins, losses,
                "نفس السعر تقريباً ونفس حركة الشموع السابقة خسرت $losses مرات (ربح $wins). تم منع الإشارة لتجنب تكرار الخطأ."
            )
        }
        return Verdict(false, wins, losses, "")
    }

    fun summary(c: Context): String {
        val all = load(c)
        return "عدد الصفقات المحفوظة: ${all.length()}"
    }

    fun reset(c: Context) { prefs(c).edit().clear().apply() }

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun load(c: Context): JSONArray =
        try { JSONArray(prefs(c).getString("records", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    private fun save(c: Context, arr: JSONArray) {
        prefs(c).edit().putString("records", arr.toString()).apply()
    }
}
