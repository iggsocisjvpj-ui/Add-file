package com.candle.assistant

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * مطابقة صفحات الصفقات المغلقة في Pocket Option (لقطات شاشة) مع سجل التطبيق.
 * من كل لقطة نقرأ: الزوج، تاريخ اليوم، وقت الفتح والإغلاق، سعر الفتح والإغلاق،
 * ثم نطابق الصفقة بالزوج ووقت الفتح (بفارق لا يتجاوز 5 ثوانٍ)، ونستبدل التقدير بالقيم المقروءة.
 * المنصة تعرض التوقيت بـ UTC، لذلك نحوّل الوقت المقروء منه كـ UTC.
 */
object PlatformMatcher {

    data class PlatformTrade(
        val pair: String,
        val openMs: Long,
        val closeMs: Long,
        val openPx: Double,
        val closePx: Double
    )

    private val pairRe = Regex("[A-Z]{3}/[A-Z]{3}(\\s?OTC)?")
    private val dateRe = Regex("\\d{4}-\\d{2}-\\d{2}")
    private val timeRe = Regex("\\d{1,2}:\\d{2}:\\d{2}(\\.\\d{1,3})?")
    private val priceRe = Regex("^\\d{1,3}\\.\\d{3,6}$")

    /** يحوّل نص اللقطة إلى صفقة، أو null إن لم تكتمل الحقول */
    fun parse(lines: List<String>): PlatformTrade? {
        val all = lines.map { it.trim() }.filter { it.isNotEmpty() }
        val pair = all.firstNotNullOfOrNull { pairRe.find(it)?.value } ?: return null
        val date = all.firstNotNullOfOrNull { dateRe.find(it)?.value } ?: return null

        val openT = valueAfterLabel(all, "الفتح") { timeRe.find(it)?.value }
            ?: return null
        val closeT = valueAfterLabel(all, "الإغلاق") { timeRe.find(it)?.value }
            ?: return null
        val openP = valueAfterLabel(all, "سعر الفتح") { if (priceRe.matches(it)) it else null }
            ?: return null
        val closeP = valueAfterLabel(all, "سعر الإغلاق") { if (priceRe.matches(it)) it else null }
            ?: return null

        val openMs = toEpoch(date, openT) ?: return null
        val closeMs = toEpoch(date, closeT) ?: return null
        return PlatformTrade(
            pair = normalizePair(pair),
            openMs = openMs,
            closeMs = closeMs,
            openPx = openP.toDouble(),
            closePx = closePx(closeP)
        )
    }

    private fun closePx(s: String) = s.toDouble()

    /** يبحث عن سطر فيه الكلمة، ثم يأخذ أول قيمة مطابقة في الأسطر التالية القريبة */
    private fun valueAfterLabel(lines: List<String>, label: String, pick: (String) -> String?): String? {
        val idx = lines.indexOfFirst { it.contains(label) }
        if (idx < 0) return null
        for (j in idx..minOf(lines.size - 1, idx + 3)) {
            val v = pick(lines[j]) ?: continue
            return v
        }
        return null
    }

    private fun toEpoch(date: String, time: String): Long? = try {
        val t = if (time.contains('.')) time else "$time.000"
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
            isLenient = false
        }
        fmt.parse("$date $t")?.time
    } catch (_: Exception) { null }

    /** نوحّد اسم الزوج: بدون مسافة وكلمة OTC، ليتطابق "CHF/NOK OTC" مع "CHF/NOK" */
    fun normalizePair(p: String): String = p.replace("OTC", "").replace(" ", "").trim()

    /** يشغّل التعرف على النص لكل لقطة، ثم يستدعي callback بالنتيجة */
    fun readImages(context: Context, uris: List<Uri>, done: (List<PlatformTrade>, Int) -> Unit) {
        val recognizer = TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS)
        val out = ArrayList<PlatformTrade>()
        var pending = uris.size
        var failed = 0
        if (pending == 0) { done(out, 0); return }
        for (u in uris) {
            try {
                val img = InputImage.fromFilePath(context, u)
                recognizer.process(img)
                    .addOnSuccessListener { text ->
                        val lines = text.textBlocks.flatMap { b -> b.lines.map { it.text } }
                        val t = parse(lines)
                        if (t != null) out.add(t) else failed++
                    }
                    .addOnFailureListener { failed++ }
                    .addOnCompleteListener {
                        pending--
                        if (pending == 0) done(out, failed)
                    }
            } catch (_: Exception) {
                failed++
                pending--
                if (pending == 0) done(out, failed)
            }
        }
    }
}
