package com.candle.assistant

import android.content.Context
import java.io.File

/**
 * يسجل كل شمعة مكتملة يقرؤها التطبيق في ملف CSV داخل التطبيق،
 * لتكوين بيانات تاريخية للاختبار دون الاعتماد على مصدر خارجي.
 */
object CandleLog {
    private const val FILE = "candle_log.csv"
    private const val MAX_BYTES = 5L * 1024 * 1024

    private fun file(c: Context) = File(c.filesDir, FILE)

    fun append(c: Context, symbol: String, tfSec: Int, candle: Candle, timeMs: Long) {
        val f = file(c)
        if (!f.exists() || f.length() == 0L) {
            f.writeText("time,symbol,tf,open,high,low,close\n")
        }
        if (f.length() > MAX_BYTES) return // لا نتجاوز 5 ميغابايت
        val line = "$timeMs,${symbol.replace(",", " ")},$tfSec,${candle.open},${candle.high},${candle.low},${candle.close}\n"
        f.appendText(line)
    }

    fun read(c: Context): String = file(c).takeIf { it.exists() }?.readText() ?: ""

    fun clear(c: Context) { file(c).delete() }
}
