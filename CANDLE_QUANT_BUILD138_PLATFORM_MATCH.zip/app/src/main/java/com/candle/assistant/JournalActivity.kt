package com.candle.assistant

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** شاشة سجل الصفقات: كل الأزواج أو زوج محدد، مع إحصاءات الساعة والتوقيت وحركة السعر. */
class JournalActivity : Activity() {
    private lateinit var body: TextView
    private lateinit var chips: LinearLayout
    private lateinit var actions: LinearLayout
    private var selected: String? = null
    private val reqImportFile = 5002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.rgb(11, 18, 32))
        root.setPadding(dp(12), dp(28), dp(12), dp(8))

        val title = TextView(this)
        title.text = "📒 سجل الصفقات والتعلّم"
        title.textSize = 20f
        title.setTextColor(Color.WHITE)
        root.addView(title)

        actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        val importActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun act(t: String, f: () -> Unit) {
            val b = Button(this)
            b.text = t; b.isAllCaps = false; b.textSize = 12f; b.setTextColor(Color.WHITE)
            val g = GradientDrawable(); g.setColor(Color.rgb(60, 80, 120)); g.cornerRadius = 12f * d
            b.background = g
            b.setOnClickListener { f() }
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f); lp.setMargins(0, dp(6), dp(4), dp(2))
            actions.addView(b, lp)
        }
        act("📋 نسخ") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("trades", TradeJournal.exportCsv(this)))
            Toast.makeText(this, "نُسخ السجل. الصقه في ملاحظاتك للحفظ", Toast.LENGTH_LONG).show()
        }
        act("📤 مشاركة") {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, TradeJournal.exportCsv(this))
            startActivity(Intent.createChooser(i, "مشاركة السجل"))
        }
        fun importAct(t: String, f: () -> Unit) {
            val b = Button(this)
            b.text = t; b.isAllCaps = false; b.textSize = 12f; b.setTextColor(Color.WHITE)
            val g = GradientDrawable(); g.setColor(Color.rgb(60, 80, 120)); g.cornerRadius = 12f * d
            b.background = g
            b.setOnClickListener { f() }
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f); lp.setMargins(0, dp(3), dp(4), dp(2))
            importActions.addView(b, lp)
        }
        importAct("📥 الحافظة") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val txt = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            val n = TradeJournal.importText(this, txt)
            Toast.makeText(this, if (n > 0) "أُضيفت $n صفقة" else "لم يتم العثور على صفقات جديدة في الحافظة", Toast.LENGTH_LONG).show()
            refresh()
        }
        importAct("📂 استيراد ملف") { pickImportFile() }
        act("📋 الأسعار") { showPriceLog() }
        act("🖼 مطابقة صور المنصة") { pickPlatformShots() }
        act("📥 مطابقة من المنصة") {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            startActivityForResult(pick, 778)
        }
        act("📤 CSV الأسعار") {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, TradeHistory.exportCsv(this@JournalActivity))
            }
            startActivity(Intent.createChooser(i, "تصدير الأسعار"))
        }
        root.addView(actions, LinearLayout.LayoutParams(-1, -2))
        root.addView(importActions, LinearLayout.LayoutParams(-1, -2))

        val hs = HorizontalScrollView(this)
        chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        hs.addView(chips)
        root.addView(hs, LinearLayout.LayoutParams(-1, -2))

        body = TextView(this)
        body.textSize = 13f
        body.setTextColor(Color.rgb(225, 233, 245))
        body.setTextIsSelectable(true)
        body.setPadding(0, dp(10), 0, dp(20))
        val sv = ScrollView(this)
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        selected = intent?.getStringExtra("symbol")?.takeIf { it.isNotBlank() && it != "غير معروف" }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        TradeJournal.invalidate()
        refresh()
    }


    private fun pickImportFile() {
        val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/plain", "application/json", "application/vnd.ms-excel"))
        }
        startActivityForResult(pick, reqImportFile)
    }

    private fun processPlatformImages(uris: List<android.net.Uri>) {
        val recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(
            com.google.mlkit.vision.text.TextRecognizerOptions.DEFAULT_OPTIONS)
        val total = uris.size
        val done = java.util.concurrent.atomic.AtomicInteger(0)
        val parsed = java.util.concurrent.atomic.AtomicInteger(0)
        val matched = java.util.concurrent.atomic.AtomicInteger(0)
        fun finishOne() {
            if (done.incrementAndGet() == total) runOnUiThread {
                android.app.AlertDialog.Builder(this)
                    .setTitle("نتيجة المطابقة")
                    .setMessage("قُرئت $parsed من $total لقطة، وطُوبقت ${matched.get()} صفقة من السجل.\n" +
                        "الأسعار المطابقة صارت مؤكدة من المنصة، والباقي يبقى تقديرياً.")
                    .setPositiveButton("حسناً", null)
                    .show()
            }
        }
        for (u in uris) {
            val bmp = try {
                contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it) }
            } catch (e: Exception) { null }
            if (bmp == null) { finishOne(); continue }
            recognizer.process(com.google.mlkit.vision.common.InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { t ->
                    val d = TradeMatcher.parse(t.text)
                    if (d != null) {
                        parsed.incrementAndGet()
                        matched.addAndGet(TradeHistory.applyPlatform(
                            this, d.pair, d.side, d.openSec, d.openPrice, d.closePrice))
                    }
                }
                .addOnCompleteListener { finishOne() }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 778) {
            if (resultCode != RESULT_OK || data == null) return
            val uris = ArrayList<android.net.Uri>()
            data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
            if (uris.isEmpty()) data.data?.let { uris.add(it) }
            if (uris.isNotEmpty()) processPlatformImages(uris)
            return
        }
        if (requestCode != reqImportFile || resultCode != RESULT_OK || data?.data == null) return
        try {
            val text = contentResolver.openInputStream(data.data!!)?.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > 8 * 1024 * 1024) throw IllegalArgumentException("حجم الملف يتجاوز 8 ميغابايت")
                    output.write(buffer, 0, count)
                }
                String(output.toByteArray(), Charsets.UTF_8)
            }.orEmpty()
            val added = TradeJournal.importText(this, text)
            Toast.makeText(
                this,
                if (added > 0) "تم استيراد $added صفقة ودمجها دون تكرار" else "لم أجد صفقات صالحة جديدة في الملف؛ تأكد أنه CSV أو JSON يحتوي time/symbol/side/result",
                Toast.LENGTH_LONG
            ).show()
            refresh()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر استيراد الملف: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }

    private fun chip(text: String, active: Boolean, action: () -> Unit) {
        val d = resources.displayMetrics.density
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 12f
        b.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.setColor(if (active) Color.rgb(34, 91, 160) else Color.rgb(25, 35, 54))
        g.cornerRadius = 14f * d
        b.background = g
        b.setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-2, (40 * d).toInt())
        lp.setMargins(0, (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
        chips.addView(b, lp)
    }

    private val reqPlatformShots = 4101

    private fun pickPlatformShots() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, reqPlatformShots)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPlatformShots || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<android.net.Uri>()
        data.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        android.widget.Toast.makeText(this, "جارٍ قراءة ${uris.size} لقطة...", android.widget.Toast.LENGTH_SHORT).show()
        PlatformMatcher.readImages(this, uris) { found, failed ->
            var matched = 0
            for (t in found) {
                if (TradeHistory.applyPlatform(this, t.pair, t.openMs, t.openPx, t.closePx, t.closeMs)) matched++
            }
            runOnUiThread {
                android.app.AlertDialog.Builder(this)
                    .setTitle("نتيجة المطابقة")
                    .setMessage("قُرئت ${found.size} صفقة، طُوبقت $matched مع السجل، تعذّرت قراءة $failed لقطة.\n\nالصفقات المطابقة صارت أسعارها مؤكدة من المنصة.")
                    .setPositiveButton("حسناً", null)
                    .show()
            }
        }
    }

    private fun showPriceLog() {
        android.app.AlertDialog.Builder(this)
            .setTitle("الصفقات بالأسعار")
            .setMessage(TradeHistory.lastText(this, 80))
            .setPositiveButton("حسناً", null)
            .show()
    }

    private fun refresh() {
        chips.removeAllViews()
        val pairs = TradeJournal.pairs(this)
        if (selected != null && selected !in pairs) selected = null
        chip("الكل", selected == null) { selected = null; refresh() }
        for (p in pairs) chip(p, selected == p) { selected = p; refresh() }
        body.text = TradeJournal.report(this, selected)
        body.visibility = View.VISIBLE
    }
}
