package com.candle.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * سجل الصفقات المؤكدة وميزات الدخول الفنية/الكمية؛ يُستخدم للتقارير ولفحص السياق.
 */
object TradeJournal {
    private const val PREF = "trade_journal"

    class Rec(
        val time: Long, val symbol: String, val side: String, val win: Boolean,
        val hour: Int, val entrySec: Int, val move: String,
        val x: DoubleArray? = null
    )

    @Volatile private var cache: List<Rec>? = null

    fun invalidate() { cache = null }

    private fun parse(o: JSONObject): Rec? {
        val t = o.optLong("time", 0L)
        if (t <= 0L) return null
        val cal = Calendar.getInstance()
        cal.timeInMillis = t
        val hour = if (o.has("hour")) o.optInt("hour") else cal.get(Calendar.HOUR_OF_DAY)
        val fa = o.optJSONArray("features")
        var fx: DoubleArray? = null
        if (fa != null && fa.length() >= 12) {
            val arr = DoubleArray(fa.length())
            for (k in 0 until fa.length()) arr[k] = if (fa.isNull(k)) Double.NaN else fa.optDouble(k, Double.NaN)
            fx = arr
        }
        return Rec(
            t, o.optString("symbol", "غير معروف"), o.optString("side", ""),
            o.optString("result") == "WIN", hour, o.optInt("entrySec", -1),
            o.optString("moveTag", ""), fx
        )
    }

    fun records(c: Context): List<Rec> {
        val cached = cache
        if (cached != null) return cached
        val raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("records", "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val out = ArrayList<Rec>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val r = parse(o)
            if (r != null) out.add(r)
        }
        cache = out
        return out
    }

    fun pairs(c: Context): List<String> =
        records(c).groupBy { it.symbol }.entries.sortedByDescending { it.value.size }.map { it.key }

    /** الحد الأعلى لفاصل ثقة ويلسون (≈95% من جهة واحدة) لنسبة النجاح */
    private fun wilsonUpper(w: Int, n: Int): Double {
        if (n <= 0) return 1.0
        val z = 1.64
        val p = w.toDouble() / n
        val z2 = z * z
        val up = (p + z2 / (2.0 * n) + z * sqrt(p * (1 - p) / n + z2 / (4.0 * n * n))) / (1 + z2 / n)
        return up.coerceIn(0.0, 1.0)
    }

    private fun hourDist(a: Int, b: Int): Int {
        val d = abs(a - b)
        return minOf(d, 24 - d)
    }

    private fun pct(l: List<Rec>): String = if (l.isEmpty()) "—" else "${l.count { it.win } * 100 / l.size}%"

    /**
     * فحص السياق: 0 لا شيء، 1 تنبيه، 2 حجب الإشارة.
     * الحجب فقط عندما تكون العينة كافية والحد الأعلى لفاصل الثقة ما زال أقل من نقطة التعادل be.
     */
    fun check(c: Context, symbol: String, hour: Int, be: Double): Pair<Int, String> {
        val all = records(c).filter { it.symbol == symbol }
        if (all.isEmpty()) return Pair(0, "")
        val near = all.filter { hourDist(it.hour, hour) <= 1 }
        val beTxt = (be * 100).toInt()
        if (near.size >= 12 && wilsonUpper(near.count { it.win }, near.size) < be) {
            return Pair(2, "$symbol قرب الساعة $hour: ${near.size} صفقة، نجاح ${pct(near)} (التعادل $beTxt%)")
        }
        if (all.size >= 15 && wilsonUpper(all.count { it.win }, all.size) < be) {
            return Pair(2, "$symbol عمومًا: ${all.size} صفقة، نجاح ${pct(all)} (التعادل $beTxt%)")
        }
        if (near.size >= 8 && near.count { it.win }.toDouble() / near.size < be) {
            return Pair(1, "سجلك لـ $symbol قرب الساعة $hour ضعيف: ${near.size} صفقة، نجاح ${pct(near)}")
        }
        return Pair(0, "")
    }

    /** نسخة نصية (CSV) من السجل للحفظ خارج التطبيق */
    fun exportCsv(c: Context): String {
        val raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("records", "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val sb = StringBuilder("time,symbol,side,result,hour,entrySec,moveTag,conf\n")
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val r = parse(o) ?: continue
            sb.append(r.time).append(',').append(csvEscape(r.symbol)).append(',').append(r.side).append(',')
                .append(if (r.win) "WIN" else "LOSS").append(',').append(r.hour).append(',').append(r.entrySec).append(',')
                .append(csvEscape(r.move)).append(',').append(o.optInt("conf", 0)).append('\n')
        }
        return sb.toString()
    }

    /** استيراد CSV أو JSON من الحافظة أو ملف، مع دمج السجل الحالي وإزالة التكرار. */
    fun importCsv(c: Context, text: String): Int = importText(c, text)

    fun importText(c: Context, text: String): Int {
        val cleaned = text.removePrefix("\uFEFF").trim()
        if (cleaned.isBlank()) return 0
        val candidates = try {
            if (cleaned.startsWith("[") || cleaned.startsWith("{")) parseJsonRecords(cleaned) else parseCsvRecords(cleaned)
        } catch (_: Exception) {
            emptyList()
        }
        if (candidates.isEmpty()) return 0

        val p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val old = try { JSONArray(p.getString("records", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val seen = HashSet<String>()
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            seen.add(recordKey(o.optLong("time"), o.optString("symbol"), o.optString("side")))
        }

        var added = 0
        for (o in candidates) {
            val time = o.optLong("time", 0L)
            val symbol = o.optString("symbol").trim()
            val side = normalizeSide(o.optString("side"))
            if (time <= 0L || symbol.isBlank() || side.isBlank()) continue
            if (!seen.add(recordKey(time, symbol, side))) continue
            o.put("time", time)
            o.put("symbol", symbol)
            o.put("side", side)
            o.put("imported", true)
            old.put(o)
            added++
        }
        if (added > 0) {
            val list = ArrayList<JSONObject>()
            for (i in 0 until old.length()) { val o = old.optJSONObject(i); if (o != null) list.add(o) }
            list.sortBy { it.optLong("time") }
            // Keep a larger history so old/first trades imported from backup files are not immediately discarded.
            val retained = if (list.size <= 5_000) list else list.take(2_500) + list.takeLast(2_500)
            val capped = JSONArray()
            for (o in retained) capped.put(o)
            p.edit().putString("records", capped.toString()).apply()
            invalidate()
        }
        return added
    }

    private fun parseJsonRecords(source: String): List<JSONObject> {
        val root = org.json.JSONTokener(source).nextValue()
        val array = when (root) {
            is JSONArray -> root
            is JSONObject -> {
                sequenceOf("records", "trades", "data", "history")
                    .mapNotNull { root.opt(it) }
                    .firstOrNull { it is JSONArray }
                    as? JSONArray ?: JSONArray().put(root)
            }
            else -> JSONArray()
        }
        val out = ArrayList<JSONObject>()
        for (i in 0 until array.length()) {
            val src = array.optJSONObject(i) ?: continue
            val time = parseTimestamp(firstValue(src, "time", "timestamp", "timestampMillis", "date", "createdAt", "tradeTime"))
            val symbol = firstText(src, "symbol", "pair", "asset", "instrument", "assetName")
            val side = normalizeSide(firstText(src, "side", "direction", "action", "tradeSide"))
            val result = normalizeResult(firstText(src, "result", "outcome", "status", "winLoss", "profit", "isWin", "won"))
            if (time <= 0L || symbol.isBlank() || side.isBlank() || result.isBlank()) continue
            val outObj = JSONObject()
                .put("time", time)
                .put("symbol", symbol)
                .put("side", side)
                .put("result", result)
                .put("hour", firstText(src, "hour").toIntOrNull() ?: hourOf(time))
                .put("entrySec", firstText(src, "entrySec", "entry_sec", "entrySeconds", "entry_second").toIntOrNull() ?: -1)
                .put("moveTag", firstText(src, "moveTag", "move", "movement", "context"))
                .put("conf", firstText(src, "conf", "confidence", "score").toIntOrNull() ?: 0)
            val features = src.optJSONArray("features")
            if (features != null) outObj.put("features", features)
            out.add(outObj)
        }
        return out
    }

    private fun parseCsvRecords(source: String): List<JSONObject> {
        val lines = source.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.isEmpty()) return emptyList()
        var header: Map<String, Int>? = null
        val first = splitCsvLine(lines.first()).map { normalizeHeader(it) }
        if (first.any { it in setOf("time", "timestamp", "date", "symbol", "pair", "side", "result", "outcome") }) {
            header = first.mapIndexedNotNull { index, key -> if (key.isBlank()) null else key to index }.toMap()
        }

        fun indexOf(h: Map<String, Int>, vararg aliases: String): Int = aliases.firstNotNullOfOrNull { h[normalizeHeader(it)] } ?: -1
        fun field(row: List<String>, h: Map<String, Int>, vararg aliases: String): String {
            val idx = indexOf(h, *aliases)
            return if (idx in row.indices) row[idx].trim() else ""
        }

        val out = ArrayList<JSONObject>()
        val start = if (header != null) 1 else 0
        for (lineIndex in start until lines.size) {
            val row = splitCsvLine(lines[lineIndex])
            if (row.size < 4) continue
            val timeText: String
            val symbol: String
            val sideText: String
            val resultText: String
            val hourText: String
            val entryText: String
            val moveText: String
            val confText: String
            if (header != null) {
                timeText = field(row, header, "time", "timestamp", "timestampMillis", "date", "createdAt", "tradeTime")
                symbol = field(row, header, "symbol", "pair", "asset", "instrument", "assetName")
                sideText = field(row, header, "side", "direction", "action", "tradeSide")
                resultText = field(row, header, "result", "outcome", "status", "winLoss", "profit", "isWin", "won")
                hourText = field(row, header, "hour")
                entryText = field(row, header, "entrySec", "entry_sec", "entrySeconds", "entry_second")
                moveText = field(row, header, "moveTag", "move", "movement", "context")
                confText = field(row, header, "conf", "confidence", "score")
            } else {
                timeText = row.getOrElse(0) { "" }
                symbol = row.getOrElse(1) { "" }
                sideText = row.getOrElse(2) { "" }
                resultText = row.getOrElse(3) { "" }
                hourText = row.getOrElse(4) { "" }
                entryText = row.getOrElse(5) { "" }
                // Older exports sometimes inserted aiSide. Keep moveTag at column 7 when column 6 is an AI direction.
                val hasAiSide = row.size >= 9 && normalizeSide(row.getOrElse(6) { "" }).isNotBlank()
                moveText = row.getOrElse(if (hasAiSide) 7 else 6) { "" }
                confText = row.getOrElse(if (row.size >= 9) 8 else 7) { "" }
            }
            val time = parseTimestamp(timeText)
            val side = normalizeSide(sideText)
            val result = normalizeResult(resultText)
            if (time <= 0L || symbol.isBlank() || side.isBlank() || result.isBlank()) continue
            out.add(JSONObject()
                .put("time", time)
                .put("symbol", symbol.trim())
                .put("side", side)
                .put("result", result)
                .put("hour", hourText.toIntOrNull() ?: hourOf(time))
                .put("entrySec", entryText.toIntOrNull() ?: -1)
                .put("moveTag", moveText)
                .put("conf", confText.toIntOrNull() ?: 0))
        }
        return out
    }

    private fun splitCsvLine(line: String): List<String> {
        val fields = ArrayList<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { current.append('"'); i++ }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> { fields.add(current.toString()); current.setLength(0) }
                else -> current.append(ch)
            }
            i++
        }
        fields.add(current.toString())
        return fields
    }

    private fun csvEscape(value: String): String = if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' })
        "\"${value.replace("\"", "\"\"")}\"" else value

    private fun normalizeHeader(value: String): String = value.trim().removePrefix("\uFEFF")
        .lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    private fun normalizeSide(value: String): String {
        val v = value.trim().uppercase(Locale.ROOT)
        return when (v) {
            "BUY", "CALL", "UP", "LONG", "شراء", "صاعد", "صعود" -> "BUY"
            "SELL", "PUT", "DOWN", "SHORT", "بيع", "هابط", "هبوط" -> "SELL"
            else -> ""
        }
    }

    private fun normalizeResult(value: String): String {
        val v = value.trim().uppercase(Locale.ROOT)
        return when (v) {
            "WIN", "WON", "PROFIT", "SUCCESS", "TRUE", "1", "ربح", "رابحة", "ناجحة" -> "WIN"
            "LOSS", "LOST", "FAIL", "FALSE", "0", "خسارة", "خاسرة", "خاسر" -> "LOSS"
            else -> ""
        }
    }

    private fun parseTimestamp(value: String): Long {
        val v = value.trim().trim('"')
        val number = v.toLongOrNull()
        if (number != null) return if (number in 1L..9_999_999_999L) number * 1000L else number
        val formats = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd HH:mm:ss", "MM/dd/yyyy HH:mm:ss", "yyyy-MM-dd")
        for (pattern in formats) {
            try {
                val f = SimpleDateFormat(pattern, Locale.US).apply { isLenient = false }
                val date = f.parse(v)
                if (date != null) return date.time
            } catch (_: Exception) { }
        }
        return 0L
    }

    private fun hourOf(time: Long): Int = Calendar.getInstance().apply { timeInMillis = time }.get(Calendar.HOUR_OF_DAY)

    private fun firstValue(o: JSONObject, vararg keys: String): String = firstText(o, *keys)

    private fun firstText(o: JSONObject, vararg keys: String): String {
        for (key in keys) {
            val value = o.opt(key) ?: continue
            val text = when (value) {
                is String -> value
                JSONObject.NULL -> ""
                else -> value.toString()
            }.trim()
            if (text.isNotBlank() && text != "null") return text
        }
        return ""
    }

    private fun recordKey(time: Long, symbol: String, side: String): String = "$time|${symbol.trim()}|${normalizeSide(side)}"

    private fun featDist(a: DoubleArray, b: DoubleArray): Double {
        val n = minOf(a.size, b.size, 12)
        var s = 0.0
        var k = 0
        for (i in 0 until n) {
            if (a[i].isFinite() && b[i].isFinite()) { val d = a[i] - b[i]; s += d * d; k++ }
        }
        return if (k < 6) 9.0 else sqrt(s / k)
    }

    /**
     * ذاكرة الأخطاء: هل تشبه الإشارة الحالية (نفس الاتجاه ونفس بصمة المؤشرات) صفقات سابقة خاسرة؟
     * 0 لا شيء، 1 تنبيه، 2 حجب (عينة كافية وفاصل الثقة العلوي لنسبة النجاح ما زال أقل من نقطة التعادل).
     */
    fun mistakeCheck(c: Context, symbol: String, side: Int, x: DoubleArray, be: Double): Pair<Int, String> {
        val sideStr = if (side == 1) "BUY" else "SELL"
        val near = ArrayList<Rec>()
        for (r in records(c)) {
            if (r.side != sideStr) continue
            val rx = r.x ?: continue
            if (featDist(rx, x) < 0.30) near.add(r)
        }
        if (near.isEmpty()) return Pair(0, "")
        val local = near.filter { it.symbol == symbol }
        val lw = local.count { it.win }
        if (local.size >= 4 && wilsonUpper(lw, local.size) < be) {
            return Pair(2, "نمط يشبه ${local.size} صفقات سابقة على $symbol ربحت منها $lw فقط")
        }
        val gw = near.count { it.win }
        if (near.size >= 12 && wilsonUpper(gw, near.size) < be) {
            return Pair(2, "نمط يشبه ${near.size} صفقات سابقة (كل الأزواج) ربحت منها $gw فقط")
        }
        if (local.size >= 3 && lw.toDouble() / local.size < be) {
            return Pair(1, "يشبه ${local.size} صفقات سابقة على $symbol ربحت منها $lw فقط")
        }
        return Pair(0, "")
    }

    fun pairLine(c: Context, symbol: String): String {
        val l = records(c).filter { it.symbol == symbol }
        return if (l.isEmpty()) "سجل $symbol: لا صفقات مسجلة بعد"
        else "سجل $symbol: ${l.size} صفقة | نجاح ${pct(l)}"
    }

    private fun line(name: String, l: List<Rec>): String =
        "• $name: ${l.size} صفقة | ${l.count { it.win }} ربح | نجاح ${pct(l)}"

    fun report(c: Context, symbol: String?): String {
        val all = records(c)
        val l = if (symbol == null) all else all.filter { it.symbol == symbol }
        if (l.isEmpty()) return "لا توجد صفقات مسجلة بعد.\nتُسجَّل الصفقة عند تأكيد نتيجتها من النافذة العائمة (ربحت/خسرت/تأكيد المقدّر)."
        val sb = StringBuilder()
        sb.append(if (symbol == null) "كل الأزواج" else symbol).append("\n")
        sb.append(line("الإجمالي", l)).append("\n")
        if (l.size < 30) sb.append("⚠ العينة صغيرة (أقل من 30 صفقة): النسب غير موثوقة إحصائيًا.\n")
        if (symbol == null) {
            sb.append("\nحسب الزوج\n")
            for ((k, v) in l.groupBy { it.symbol }.entries.sortedByDescending { it.value.size }) sb.append(line(k, v)).append("\n")
        }
        sb.append("\nحسب ساعات اليوم (توقيت الهاتف)\n")
        for ((b, v) in l.groupBy { it.hour / 3 }.entries.sortedBy { it.key }) {
            sb.append(line(String.format(Locale.US, "%02d:00–%02d:59", b * 3, b * 3 + 2), v)).append("\n")
        }
        sb.append("\nحسب ثانية الدخول داخل الشمعة\n")
        val order = listOf("غير معروف", "0–4ث", "5–14ث", "15–29ث", "30ث+")
        val byEntry = l.groupBy {
            when {
                it.entrySec < 0 -> order[0]
                it.entrySec < 5 -> order[1]
                it.entrySec < 15 -> order[2]
                it.entrySec < 30 -> order[3]
                else -> order[4]
            }
        }
        for (k in order) { val v = byEntry[k] ?: continue; sb.append(line(k, v)).append("\n") }
        val withMove = l.filter { it.move.isNotEmpty() }
        if (withMove.isNotEmpty()) {
            sb.append("\nحسب حركة السعر قبل الدخول\n")
            for ((k, v) in withMove.groupBy { it.move }.entries.sortedByDescending { it.value.size }) sb.append(line(k, v)).append("\n")
        }
        sb.append("\nحسب الاتجاه\n")
        sb.append(line("شراء", l.filter { it.side == "BUY" })).append("\n")
        sb.append(line("بيع", l.filter { it.side == "SELL" })).append("\n")
        sb.append("\nآخر الصفقات\n")
        val fmt = SimpleDateFormat("MM/dd HH:mm", Locale.US)
        for (r in l.takeLast(25).reversed()) {
            val side = if (r.side == "BUY") "▲" else "▼"
            val sec = if (r.entrySec >= 0) " | ث${r.entrySec}" else ""
            val mv = if (r.move.isNotEmpty()) " | ${r.move}" else ""
            sb.append("${if (r.win) "✔" else "✘"} ${fmt.format(Date(r.time))} $side ${r.symbol}$sec$mv\n")
        }
        return sb.toString().trimEnd()
    }
}
