package com.candle.assistant

/** Google Apps Script endpoint is supplied by the user and saved in app preferences. */
object VisionAiConfig {
    // Do not silently target the endpoint bundled by the previous build.
    const val DEFAULT_ENDPOINT = ""
    const val LEGACY_DEFAULT_ENDPOINT = "https://script.google.com/macros/s/AKfycbz5LD9togwHN1Vk00rxaMsVoY-h54g5NpcTC76WqADdq7G3N3YTHGWh-Jtju30PsFg3Rw/exec"
    const val DEFAULT_PLATFORM = "Pocket Option"

    const val CONNECT_TIMEOUT_MS = 30_000
    // Apps Script executions in the supplied log take close to six minutes.
    // Keep the Android client waiting longer than the backend execution.
    const val READ_TIMEOUT_MS = 420_000
    const val DEFAULT_INTERVAL_SEC = 10
    const val MIN_INTERVAL_SEC = 5
    const val MAX_INTERVAL_SEC = 120
    const val MAX_IMAGE_SIDE = 1024

    // تعليمات إضافية ترسل مع الصورة؛ إن تجاهلها سكربت Apps Script يبقى التطبيق يستخرج الاتجاه من نص الرد.
    const val INSTRUCTION = "حلّل صورة الشارت الحالية (شموع يابانية) واختر قراراً واحداً فقط للدخول الآن: BUY أو SELL أو WAIT. " +
        "استخدم WAIT عندما لا يوجد تأكيد دخول واضح. ابدأ ردّك بسطر بهذا الشكل: DIRECTION: BUY أو DIRECTION: SELL أو DIRECTION: WAIT، " +
        "ثم اذكر السبب في سطرين كحد أقصى. هذه قراءة بصرية للشارت وليست ضماناً للربح."
    const val JPEG_QUALITY = 75

    fun normalizeEndpoint(value: String): String = value.trim()
}
