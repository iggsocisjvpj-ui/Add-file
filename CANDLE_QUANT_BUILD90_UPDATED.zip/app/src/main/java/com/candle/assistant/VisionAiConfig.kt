package com.candle.assistant

/** Google Apps Script endpoint is supplied by the user and saved in app preferences. */
object VisionAiConfig {
    // Do not silently target the endpoint bundled by the previous build.
    const val DEFAULT_ENDPOINT = ""
    const val LEGACY_DEFAULT_ENDPOINT = "https://script.google.com/macros/s/AKfycbz5LD9togwHN1Vk00rxaMsVoY-h54g5NpcTC76WqADdq7G3N3YTHGWh-Jtju30PsFg3Rw/exec"
    const val DEFAULT_PLATFORM = "Pocket Option"

    const val CONNECT_TIMEOUT_MS = 30_000
    // Apps Script executions in the supplied log take close to six minutes.
    // Keep the Android client waiting longer than the backend execution.
    const val READ_TIMEOUT_MS = 420_000
    const val MAX_IMAGE_SIDE = 1024
    const val JPEG_QUALITY = 75

    fun normalizeEndpoint(value: String): String = value.trim()
}
