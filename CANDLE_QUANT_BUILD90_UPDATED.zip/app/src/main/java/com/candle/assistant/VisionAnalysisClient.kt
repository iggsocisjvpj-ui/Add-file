package com.candle.assistant

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

sealed class VisionAnalysisResult {
    data class Success(val analysis: String, val direction: String, val model: String) : VisionAnalysisResult()
    data class Failure(val message: String) : VisionAnalysisResult()
}

/** Sends only the chart image to the user's Google Apps Script Web App. */
class VisionAnalysisClient(
    private val endpoint: String,
    private val readTimeoutMs: Int = VisionAiConfig.READ_TIMEOUT_MS
) {
    fun analyzeChart(imageBytes: ByteArray, platform: String): VisionAnalysisResult {
        if (imageBytes.isEmpty()) return VisionAnalysisResult.Failure("الصورة فارغة")
        val url = try { URL(VisionAiConfig.normalizeEndpoint(endpoint)) }
            catch (_: Exception) { return VisionAnalysisResult.Failure("رابط Apps Script غير صحيح") }
        if (url.protocol != "https" || !url.host.endsWith("google.com"))
            return VisionAnalysisResult.Failure("استخدم رابط Web App المنشور من Google Apps Script عبر HTTPS")

        var connection: HttpURLConnection? = null
        return try {
            val dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(imageBytes, Base64.NO_WRAP)
            val payload = JSONObject()
                .put("platform", platform.take(80))
                .put("image_base64", dataUrl)
                .put("instruction", VisionAiConfig.INSTRUCTION)
            val body = payload.toString().toByteArray(Charsets.UTF_8)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = VisionAiConfig.CONNECT_TIMEOUT_MS
                readTimeout = readTimeoutMs
                doOutput = true
                instanceFollowRedirects = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            connection.outputStream.use { it.write(body) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(text) } catch (_: Exception) { null }
            if (code !in 200..299) return VisionAnalysisResult.Failure("Apps Script HTTP $code: ${text.take(180)}")
            if (json == null) {
                // A few older Web Apps return plain text instead of a JSON object.
                val plainText = text.trim()
                if (plainText.isNotBlank() && !plainText.startsWith("<") && !plainText.startsWith("{")) {
                    return VisionAnalysisResult.Success(plainText, parseDirection(plainText), "Gemini via Apps Script (plain text)")
                }
                return VisionAnalysisResult.Failure("Apps Script لم يُرجع JSON أو نص تحليل صالحًا: ${text.take(120)}")
            }
            if (json.optBoolean("ok", true).not()) {
                return VisionAnalysisResult.Failure(firstNonBlank(json, "error", "message", "detail").ifBlank { "فشل تحليل الصورة" })
            }
            // Accept the stable `analysis` response as well as common field names used by older deployments.
            val analysis = firstNonBlank(json, "analysis", "text", "result", "response", "output").trim()
            if (analysis.isBlank()) return VisionAnalysisResult.Failure(
                firstNonBlank(json, "error", "message").ifBlank { "الرد لا يحتوي على نص التحليل (analysis/text/result)" }
            )
            val rawDirection = firstNonBlank(json, "direction", "signal", "recommendation").ifBlank { analysis }
            val direction = parseDirection(rawDirection)
            VisionAnalysisResult.Success(analysis, direction, firstNonBlank(json, "model", "model_name").ifBlank { "Gemini via Apps Script" })
        } catch (_: java.net.SocketTimeoutException) {
            VisionAnalysisResult.Failure("انتهت مهلة الاتصال بعد 7 دقائق. تحقق من سجل تنفيذ Apps Script؛ زمن المعالجة على الخادم قد يكون أطول من مهلة Google.")
        } catch (_: java.net.UnknownHostException) {
            VisionAnalysisResult.Failure("تعذر الوصول إلى Google Apps Script؛ تحقق من الإنترنت")
        } catch (e: Exception) {
            VisionAnalysisResult.Failure("فشل اتصال Apps Script: ${e.javaClass.simpleName}: ${(e.message ?: "").take(100)}")
        } finally { connection?.disconnect() }
    }

    private fun firstNonBlank(json: JSONObject, vararg keys: String): String {
        for (key in keys) {
            val value = json.optString(key, "").trim()
            if (value.isNotBlank() && value != "null") return value
        }
        return ""
    }

    /** يقرأ سطراً صريحاً مثل DIRECTION: BUY أو القرار: انتظار قبل أي تحليل للنص الحر. */
    private fun explicitDirection(value: String): String? {
        val m = Regex("(direction|signal|decision|الاتجاه|القرار|الإشارة|الاشارة)\\s*[:=：]\\s*[\"']?\\s*([a-zA-Z\\u0600-\\u06FF]+)", RegexOption.IGNORE_CASE).find(value) ?: return null
        return when (m.groupValues[2].lowercase(Locale.ROOT)) {
            "buy", "call", "long", "شراء", "صعود", "صاعد" -> "BUY"
            "sell", "put", "short", "بيع", "هبوط", "هابط" -> "SELL"
            "wait", "hold", "none", "neutral", "انتظار" -> "WAIT"
            else -> null
        }
    }

    private fun parseDirection(value: String): String {
        explicitDirection(value)?.let { return it }
        val s = value.lowercase(Locale.ROOT)
        val buy = Regex("(^|[^a-z])buy([^a-z]|$)|شراء|صاعد|صعود|bullish").containsMatchIn(s)
        val sell = Regex("(^|[^a-z])sell([^a-z]|$)|بيع|هابط|هبوط|bearish").containsMatchIn(s)
        return when { buy && !sell -> "BUY"; sell && !buy -> "SELL"; else -> "WAIT" }
    }
}
