package com.candle.assistant

import android.Manifest
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.ImageView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var symbolField: EditText
    private lateinit var autoBtn: Button
    private val reqCapture = 1001
    private val reqChartImage = 1002
    private val reqImportXlsx = 1003
    private var selectedChartBitmap: Bitmap? = null
    private lateinit var aiResult: TextView
    private lateinit var imagePreview: ImageView
    private lateinit var backendField: EditText
    private lateinit var platformField: EditText
    private lateinit var stats: TextView
    private lateinit var advancedDashboard: LinearLayout
    private lateinit var quantStatusView: TextView
    private lateinit var autoStat: TextView
    private lateinit var btnPrimary: Button
    private lateinit var btnGemini: Button
    private lateinit var btnMerge: Button
    private lateinit var btnAutoMart: Button
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent?.getBooleanExtra("import_xlsx", false) == true) {
            android.os.Handler(mainLooper).postDelayed({ openXlsxPicker() }, 300L)
        }
        if (intent?.getBooleanExtra("po_setup", false) == true) {
            android.os.Handler(mainLooper).postDelayed({ showPoSetupDialog() }, 300L)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        val lv = getSharedPreferences("learn", Context.MODE_PRIVATE)
        if (lv.getInt("ver", 0) != Learner.VER) lv.edit().clear().putInt("ver", Learner.VER).apply()
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        // Clear only the endpoint hard-coded by the previous app build; keep any URL the user entered.
        if (p.getString("vision_backend", null) == VisionAiConfig.LEGACY_DEFAULT_ENDPOINT) {
            p.edit().remove("vision_backend").apply()
        }
        // Safety baseline: automatic trading remains disabled until platform/account verification is redesigned.
        p.edit().putInt("auto", 0).apply()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(AppTheme.BG)
        }
        var container: LinearLayout = root
        fun rounded(color: Int, radius: Float = 18f): GradientDrawable = GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }
        fun label(t: String, size: Float = 15f) {
            container.addView(TextView(this).apply {
                text = t; textSize = size; setTextColor(AppTheme.TEXT)
                setPadding(0, 20, 0, 7)
                if (size >= 21f) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            })
        }
        fun sectionHeader(t: String) {
            root.addView(View(this).apply { setBackgroundColor(AppTheme.DIVIDER) },
                LinearLayout.LayoutParams(-1, 2).apply { topMargin = 34 })
            root.addView(TextView(this).apply {
                text = t; textSize = 17f; setTextColor(AppTheme.ACCENT)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setPadding(0, 14, 0, 6)
            })
        }
        fun card(title: String, collapsible: Boolean = false) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(22, 18, 22, 20)
                background = rounded(AppTheme.SURFACE, 18f)
            }
            val header = TextView(this).apply {
                text = if (collapsible) "$title  ▾" else title
                textSize = 16f
                setTextColor(AppTheme.ACCENT)
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setPadding(0, 0, 0, 8)
            }
            val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            box.addView(header)
            box.addView(body)
            if (collapsible) {
                body.visibility = View.GONE
                header.setOnClickListener {
                    val open = body.visibility != View.VISIBLE
                    body.visibility = if (open) View.VISIBLE else View.GONE
                    header.text = if (open) "$title  ▴" else "$title  ▾"
                }
            }
            root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 22 })
            container = body
        }
        fun field(key: String, title: String, def: Int) {
            label(title, 14f)
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(p.getInt(key, def).toString())
                setTextColor(Color.WHITE); setHintTextColor(AppTheme.TEXT_MUTED)
                setPadding(18, 14, 18, 14); background = rounded(AppTheme.SURFACE, AppTheme.RADIUS_DP)
            }
            fields[key] = e
            container.addView(e, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 })
        }
        fun button(t: String, action: () -> Unit) {
            container.addView(Button(this).apply {
                text = t; isAllCaps = false; textSize = 14f
                setTextColor(Color.WHITE); background = rounded(AppTheme.BUTTON, AppTheme.RADIUS_BUTTON_DP)
                setPadding(14, 14, 14, 14); setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 7; bottomMargin = 5 })
        }

        label("CANDLE QUANT", 28f)
        label("محلل الشموع الكمي", 14f)
        label("اعرض الشارت على المنصة، ويُفضّل 30 شمعة واضحة على الأقل. مدة الصفقة تساوي مدة الشمعة.", 13f)
        /* chart setup */
        card("📊 إعدادات قراءة الشارت")
        field("top", "بداية الشارت من أعلى الشاشة %", 12)
        field("bottom", "نهاية الشارت من أعلى الشاشة %", 60)
        field("tf", "مدة الشمعة بالثواني (60 = دقيقة)", 60)
        field("conf", "الحد الأدنى لثقة المحرك المحلي % (50 إلى 95)", 58)
        field("minTechnical", "الحد الأدنى لقوة المحرك الفني % (يدوي)", 70)
        field("minQuant", "الحد الأدنى لقوة المحرك الكمي % (يدوي)", 70)
        field("sens", "الحساسية (1 صارم وبطيء، 5 حساس وسريع)", 3)
        field("dur", "مدة الصفقة كما هي مضبوطة في المنصة (بالثواني)", 60)
        field("payout", "عائد المنصة % (يظهر بجانب زر الشراء)", 85)
        label("اسم الزوج يدويًا (اتركه فارغًا للقراءة التلقائية من الشاشة)", 14f)
        symbolField = EditText(this).apply {
            setText(p.getString("symbol_override", "") ?: "")
            hint = "مثال: AUD/CHF OTC"
            setTextColor(Color.WHITE); setHintTextColor(AppTheme.TEXT_MUTED)
            setPadding(18, 14, 18, 14); background = rounded(AppTheme.SURFACE, AppTheme.RADIUS_DP)
        }
        container.addView(symbolField, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 })
        card("🛠 الإعداد الأولي")
        label("اتبع الخطوات بالترتيب، ثم اختبر على Demo فقط.", 13f)
        button("1) تفعيل خدمة إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2) تحديد موضع زري الشراء والبيع") {
            val svc = TapService.instance
            if (svc != null) svc.calibrate()
            else Toast.makeText(this, "فعّل خدمة «محلل الشموع - نقر تجريبي» أولاً", Toast.LENGTH_LONG).show()
        }
        card("🤖 التداول التلقائي (Demo فقط)")
        field("maxDayLosses", "أقصى عدد خسائر في اليوم (0 = بلا حد، الافتراضي 5)", 5)
        field("maxConsecLosses", "أقصى عدد خسائر متتالية (0 = بلا حد، الافتراضي 3)", 3)
        label("حدّد وقف الخسارة وجني الربح بجانب الزر. لا يضمن التطبيق أي ربح.", 13f)
        button("📒 سجل الصفقات والتعلّم") { startActivity(Intent(this, JournalActivity::class.java)) }
        val autoRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        autoBtn = Button(this).apply {
            isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE)
            background = rounded(AppTheme.BUTTON, AppTheme.RADIUS_BUTTON_DP); setPadding(10, 8, 10, 8)
            setOnClickListener { toggleAuto() }
        }
        fun moneyField(key: String, hintText: String): EditText = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            hint = hintText; textSize = 13f
            setText(p.getString(key, "") ?: "")
            setTextColor(Color.WHITE); setHintTextColor(AppTheme.TEXT_MUTED)
            setPadding(12, 10, 12, 10); background = rounded(AppTheme.SURFACE, AppTheme.RADIUS_DP)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    p.edit().putString(key, s?.toString()?.trim() ?: "").apply()
                }
            })
        }
        autoRow.addView(autoBtn, LinearLayout.LayoutParams(0, -2, 1.5f).apply { marginEnd = 6 })
        autoRow.addView(moneyField("autoSL", "وقف الخسارة"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 })
        autoRow.addView(moneyField("autoTP", "جني الربح"), LinearLayout.LayoutParams(0, -2, 1f))
        container.addView(autoRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 7; bottomMargin = 5 })
        label("المارتينجيل (عدد المراحل والمضاعف)", 16f)
        btnAutoMart = Button(this).apply {
            isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE)
            background = rounded(AppTheme.BUTTON, AppTheme.RADIUS_BUTTON_DP); setPadding(10, 8, 10, 8)
            setOnClickListener { toggleAutoMart() }
        }
        container.addView(btnAutoMart, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 4; bottomMargin = 5 })
        val manualMartRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        fun manualNumber(key: String, hintText: String, defaultValue: String, decimal: Boolean): EditText = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or (if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
            hint = hintText
            setText(p.getString(key, defaultValue) ?: defaultValue)
            textSize = 13f; setTextColor(Color.WHITE); setHintTextColor(AppTheme.TEXT_MUTED)
            setPadding(12, 10, 12, 10); background = rounded(AppTheme.SURFACE, AppTheme.RADIUS_DP)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    p.edit().putString(key, s?.toString()?.trim() ?: "").apply()
                }
            })
        }
        manualMartRow.addView(manualNumber("manualMartMax", "عدد المراحل (0 إيقاف)", "0", false), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 })
        manualMartRow.addView(manualNumber("manualMartMultiplier", "المضاعف (مثلاً 2)", "2", true), LinearLayout.LayoutParams(0, -2, 1f))
        container.addView(manualMartRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 })
        button("تصفير مستوى المارتينجيل اليدوي") {
            p.edit().putInt("manualMartLevel", 0).apply()
            Toast.makeText(this, "تم تصفير مستوى المارتينجيل اليدوي", Toast.LENGTH_SHORT).show()
        }
label("في الصفقات اليدوية: بعد تسجيل الخسارة يعرض التطبيق المبلغ المقترح للصفقة التالية حسب المضاعف وتنفّذها أنت بنفسك. في التداول التلقائي (عند تشغيل زر المارتينجيل أعلاه): بعد كل خسارة يرفع التطبيق المستوى فينقر زر الدخول عدداً من المرات يساوي المضاعف مرفوعاً للمستوى (مثلاً ×2 ثم ×4 ثم ×8) بحد أقصى 8 نقرات، ولا يضاعف إن كانت الخسارة المحتملة ستتجاوز وقف الخسارة. بعد الربح أو عند بلوغ عدد المراحل يعود للمبلغ الأساسي. يعمل ذلك على الحساب التجريبي فقط.", 12f)
        autoStat = TextView(this).apply { textSize = 14f; setTextColor(Color.rgb(255, 205, 105)); setPadding(14, 14, 14, 14); background = rounded(Color.rgb(47, 39, 27), 14f); text = "التداول التلقائي: ⚪ متوقف" }
        container.addView(autoStat)
        button("ابدأ التحليل") { start() }
        button("إيقاف التحليل") {
            stopService(Intent(this, CaptureService::class.java))
            Toast.makeText(this, "تم الإيقاف", Toast.LENGTH_SHORT).show()
        }
        button("تصفير الإحصاءات والتعلم") {
            Learner.reset(this)
            getSharedPreferences("stats", Context.MODE_PRIVATE).edit().clear().apply()
            refreshStats()
        }
        stats = TextView(this).apply { textSize = 16f; setTextColor(AppTheme.TEXT); setPadding(14, 18, 14, 18); background = rounded(Color.rgb(20, 30, 47), 16f) }
        container.addView(stats)

        // Gemini يعمل عبر Google Apps Script لتحليل صورة الشارت فقط؛ المحرك الكمي محلي ومستمر.
        card("⚙ المحركات: الأساسي وجمني")
        label("• الأساسي: التحليل الفني والكمي المحلي.\n• جمني: يحلل لقطة الشارت في الخلفية عبر Apps Script ويعطي شراء أو بيع أو «انتظار تأكيد دخول» (فاصل الإرسال في الحقل أدناه، الافتراضي 10 ثوانٍ، وطلب واحد فقط في كل مرة).\n• دمج (يعمل عند تشغيل الاثنين معاً): لا إشارة إلا إذا اتفق المحركان. بدون دمج: تكفي إشارة أحدهما، وإذا تعارضا فالنتيجة انتظار.\nنفس هذه الأزرار موجودة في النافذة العائمة (اضغط على نصها لفتحها). التغيير يسري فوراً دون إعادة التشغيل.", 13f)
        val engineRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        fun engineButton(kind: Int): Button = Button(this).apply {
            isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 8)
            setOnClickListener { toggleEngine(kind) }
        }
        btnPrimary = engineButton(0); btnGemini = engineButton(1); btnMerge = engineButton(2)
        engineRow.addView(btnPrimary, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 })
        engineRow.addView(btnGemini, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6 })
        engineRow.addView(btnMerge, LinearLayout.LayoutParams(0, -2, 1f))
        container.addView(engineRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 4; bottomMargin = 5 })
        field("geminiSec", "فاصل إرسال لقطة جمني بالثواني (من 5 إلى 120، الافتراضي 10) — يُطبّق عند الضغط على «ابدأ التحليل»", VisionAiConfig.DEFAULT_INTERVAL_SEC)
        field("geminiCandles", "عدد الشموع بين كل إرسال لجمني (1 = كل شمعة، 0 = استخدم الثواني أعلاه)", 0)
        card("🧪 اختبار جمني يدوي", collapsible = true)

        platformField = EditText(this).apply {
            hint = "مصدر الشارت (اختياري)"
            setSingleLine(true)
            setText(getSharedPreferences("cfg", Context.MODE_PRIVATE)
                .getString("vision_platform", VisionAiConfig.DEFAULT_PLATFORM) ?: VisionAiConfig.DEFAULT_PLATFORM)
            setTextColor(Color.WHITE); setHintTextColor(AppTheme.TEXT_MUTED)
            setPadding(18, 14, 18, 14); background = rounded(AppTheme.SURFACE, AppTheme.RADIUS_DP)
        }
        container.addView(platformField)

        imagePreview = ImageView(this).apply {
            adjustViewBounds = true
            maxHeight = 420
            visibility = View.GONE
            contentDescription = "معاينة صورة الشارت المختارة"
            setBackgroundColor(Color.rgb(20, 30, 47)); setPadding(8, 8, 8, 8)
        }
        container.addView(imagePreview)

        button("اختيار صورة الشارت من الهاتف") {
            val pick = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(Intent.createChooser(pick, "اختر صورة الشارت"), reqChartImage)
        }

        button("تحليل الصورة كميًا دون إنترنت") {
            val bmp = selectedChartBitmap
            if (bmp == null) Toast.makeText(this, "اختر صورة الشارت أولاً", Toast.LENGTH_SHORT).show()
            else runLocalImageAnalysis(bmp)
        }

        label("رابط Google Apps Script Web App (/exec)", 14f)
        label("الصق رابط النشر الحالي من Apps Script ثم اضغط حفظ الرابط. لم يعد التطبيق يستخدم رابط النسخة القديمة تلقائياً.", 12f)
        backendField = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            hint = "https://script.google.com/macros/s/.../exec"
            setText(getSharedPreferences("cfg", Context.MODE_PRIVATE)
                .getString("vision_backend", VisionAiConfig.DEFAULT_ENDPOINT) ?: VisionAiConfig.DEFAULT_ENDPOINT)
            setTextColor(Color.WHITE); setHintTextColor(AppTheme.TEXT_MUTED)
            setPadding(18, 14, 18, 14); background = rounded(AppTheme.SURFACE, AppTheme.RADIUS_DP)
        }
        container.addView(backendField)

        button("حفظ رابط Apps Script") {
            val endpoint = VisionAiConfig.normalizeEndpoint(backendField.text.toString())
            if (endpoint.isBlank() || !endpoint.startsWith("https://script.google.com/macros/s/") || !endpoint.endsWith("/exec")) {
                Toast.makeText(this, "أدخل رابط Google Apps Script المنشور وينتهي بـ /exec", Toast.LENGTH_LONG).show()
            } else {
                getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
                    .putString("vision_backend", endpoint)
                    .putString("vision_platform", platformField.text.toString().trim().ifBlank { VisionAiConfig.DEFAULT_PLATFORM })
                    .apply()
                VisionAiStore.updateStatus(this, "تم حفظ رابط Apps Script. سيُختبر عند تحليل صورة الشارت التالية.")
                updateVisionPanel()
                Toast.makeText(this, "تم حفظ رابط Apps Script", Toast.LENGTH_SHORT).show()
            }
        }

        button("اختبار Gemini على صورة الشارت المختارة") {
            val bmp = selectedChartBitmap
            val endpoint = VisionAiConfig.normalizeEndpoint(backendField.text.toString())
            val platform = platformField.text.toString().trim().ifBlank { VisionAiConfig.DEFAULT_PLATFORM }
            if (bmp == null) Toast.makeText(this, "اختر صورة الشارت أولاً", Toast.LENGTH_SHORT).show()
            else if (!endpoint.startsWith("https://script.google.com/macros/s/") || !endpoint.endsWith("/exec")) {
                Toast.makeText(this, "أدخل رابط Apps Script المنشور وينتهي بـ /exec", Toast.LENGTH_LONG).show()
            } else {
                getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
                    .putString("vision_backend", endpoint)
                    .putString("vision_platform", platform)
                    .apply()
                runVisionImageAnalysis(bmp, endpoint, platform)
            }
        }

        aiResult = TextView(this).apply {
            textSize = 14f
            setTextColor(AppTheme.TEXT)
            setPadding(16, 18, 16, 18)
            background = rounded(Color.rgb(20, 30, 47), 16f)
            text = "حالة Gemini عبر Apps Script: ${VisionAiStore.status(this@MainActivity)}\n\n${VisionAiStore.analysis(this@MainActivity)}"
        }
        container.addView(aiResult)

        card("📈 لوحة التحليل الكمي", collapsible = true)
        label("المحرك الكمي محلي في الخلفية ويعيد تقييم الشمعة الحالية دورياً. Footprint تقديري من OHLC ولا يمثل حجم تداول حقيقياً. مدة الصفقة تستخدم القيمة المضبوطة في حقل مدة الصفقة بالثواني، ويجب أن تطابق إعداد المنصة.", 12f)
        advancedDashboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            background = rounded(Color.rgb(18, 27, 43), 18f)
        }
        container.addView(advancedDashboard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8; bottomMargin = 12 })
        quantStatusView = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(190, 215, 225))
            setPadding(14, 12, 14, 12)
            background = rounded(Color.rgb(20, 35, 48), 14f)
        }
        container.addView(quantStatusView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        updateQuantStatusPanel()
        renderDashboardPlaceholder()

        card("ℹ طريقة العمل", collapsible = true)
        label("طريقة العمل: الحالات 🟢 شراء، 🔴 بيع، 🟡 انتظار (المؤشرات متعارضة)، ⚪ لا تدخل (بيانات غير كافية أو غير موثوقة). تظهر الإشارة في أول ثوانٍ من الشمعة الجديدة مع وقت الدخول والمدة وأسبابها. نفّذ الصفقة في المنصة بمدة شمعة، ثم اضغط في النافذة العائمة «دخلت شراء» أو «دخلت بيع» حسب ما نفّذت. يتوقف التحليل حتى تنتهي الصفقة، ثم يقدّر التطبيق الربح أو الخسارة ويعرضها لتؤكدها أو تصححها، ويتعلم منها تلقائياً. ضع النافذة بعيداً عن الشارت (الافتراضي أسفل الشاشة).", 13f)
        label("تنبيه: الثقة المعروضة درجة تقديرية من النموذج وليست احتمالاً مضموناً. لا يوجد نظام يضمن نسبة ربح، والقرار والنقر بيدك. " +
            "جرّب بالحساب التجريبي وراقب النسبة الفعلية لـ 50 صفقة على الأقل قبل أي مال حقيقي.", 13f)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshEngineButtons()
        refreshStats()
        updateVisionPanel()
        updateQuantStatusPanel()
    }

    private fun updateQuantStatusPanel() {
        if (!::quantStatusView.isInitialized) return
        quantStatusView.text = "المحرك الكمي بالخلفية\n${QuantitativeBackgroundEngine.savedSummary(this@MainActivity)}"
    }

    private fun updateVisionPanel() {
        if (!::aiResult.isInitialized) return
        val status = VisionAiStore.status(this)
        val result = VisionAiStore.analysis(this)
        aiResult.text = "حالة تحليل الصور: $status" + if (result.isBlank()) "\n\nلم تصل نتيجة صورة بعد." else "\n\nآخر تحليل بصري:\n$result"
    }

    private fun cfgFlag(key: String, def: Int): Boolean =
        getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt(key, def) == 1

    private fun refreshEngineButtons() {
        if (!::btnPrimary.isInitialized) return
        fun paint(b: Button, name: String, on: Boolean, onText: String, offText: String) {
            b.text = "$name\n" + if (on) onText else offText
            b.background = GradientDrawable().apply {
                setColor(if (on) Color.rgb(30, 120, 70) else Color.rgb(70, 78, 95)); cornerRadius = 16f
            }
        }
        paint(btnPrimary, "الأساسي", cfgFlag("primaryOn", 1), "▶ يعمل", "⏸ موقوف")
        paint(btnGemini, "جمني", cfgFlag("geminiOn", 0), "▶ يعمل", "⏸ موقوف")
        paint(btnMerge, "دمج", cfgFlag("mergeOn", 0), "✓ مفعّل", "✗ معطّل")
        if (::btnAutoMart.isInitialized) {
            btnAutoMart.text = if (cfgFlag("autoMart", 0)) "🟢 المارتينجيل في التداول التلقائي: مفعّل — اضغط للإيقاف"
            else "⚪ تشغيل المارتينجيل في التداول التلقائي"
        }
    }

    private fun toggleEngine(kind: Int) {
        val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val key = when (kind) { 0 -> "primaryOn"; 1 -> "geminiOn"; else -> "mergeOn" }
        val was = cfg.getInt(key, if (kind == 0) 1 else 0)
        cfg.edit().putInt(key, if (was == 1) 0 else 1).apply()
        if (kind == 1 && was == 0 && cfg.getString("vision_backend", "").orEmpty().isBlank()) {
            Toast.makeText(this, "ضع رابط Apps Script واحفظه أولاً ليعمل جمني", Toast.LENGTH_LONG).show()
        }
        if (kind == 2 && was == 0 && !(cfgFlag("primaryOn", 1) && cfgFlag("geminiOn", 0))) {
            Toast.makeText(this, "الدمج يعمل فقط عند تشغيل الأساسي وجمني معاً", Toast.LENGTH_LONG).show()
        }
        refreshEngineButtons()
    }

    private fun toggleAutoMart() {
        val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (cfg.getInt("autoMart", 0) == 1) {
            cfg.edit().putInt("autoMart", 0).apply()
        } else {
            val steps = (cfg.getString("manualMartMax", "0")?.toIntOrNull() ?: 0).coerceIn(0, 20)
            if (steps == 0) {
                Toast.makeText(this, "حدّد عدد المراحل (أكبر من 0) أولاً", Toast.LENGTH_LONG).show()
                return
            }
            cfg.edit().putInt("autoMart", 1).apply()
        }
        refreshEngineButtons()
    }

    private fun toggleAuto() {
        val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (cfg.getInt("auto", 0) == 1) {
            cfg.edit().putInt("auto", 0).apply()
            Toast.makeText(this, "أُوقف التداول التلقائي", Toast.LENGTH_SHORT).show()
            refreshStats()
            return
        }
        val sl = cfg.getString("autoSL", "")?.toDoubleOrNull() ?: 0.0
        val tp = cfg.getString("autoTP", "")?.toDoubleOrNull() ?: 0.0
        if (sl <= 0.0) {
            Toast.makeText(this, "حدّد مبلغ وقف الخسارة أولاً (الحقل بجانب الزر)", Toast.LENGTH_LONG).show()
            return
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("تأكيد: حساب تجريبي فقط")
            .setMessage("سينقر التطبيق على زري الشراء والبيع تلقائياً. فعّله فقط وأنت على الحساب التجريبي، وسيرفض العمل إن لم تظهر كلمة Demo على الشاشة.\n\nوقف الخسارة: $sl\nجني الربح: ${if (tp > 0.0) tp.toString() else "غير محدد"}\nيُحسب الربح والخسارة من رصيد الحساب المقروء من الشاشة لحظة التفعيل، ويُفحص بين الصفقات (قد تتجاوز آخر صفقة الحد بمقدار قيمتها).\n\nهل أنت الآن على حساب تجريبي؟")
            .setPositiveButton("نعم، حساب تجريبي") { _, _ ->
                cfg.edit().putInt("auto", 1).apply()
                refreshStats()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun start() {
        val ed = getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
        for ((k, e) in fields) ed.putInt(k, e.text.toString().toIntOrNull() ?: 0)
        ed.putString("symbol_override", symbolField.text.toString().trim())
        ed.apply()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» ثم ارجع واضغط ابدأ", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    /** نافذة إدخال session وuid للديمو. تُحفظ على الهاتف فقط */
    private fun showPoSetupDialog() {
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 20, 40, 0)
        }
        val sessionField = android.widget.EditText(this).apply { hint = "session (ديمو)" }
        val uidField = android.widget.EditText(this).apply {
            hint = "uid (ديمو)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        box.addView(sessionField)
        box.addView(uidField)
        android.app.AlertDialog.Builder(this)
            .setTitle("إعداد API الديمو")
            .setMessage("هذه البيانات للديمو فقط، وتبقى على هذا الهاتف ولا تُرفع إلى GitHub.")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val s = sessionField.text.toString().trim()
                val u = uidField.text.toString().trim().toLongOrNull()
                if (s.isBlank() || u == null) {
                    android.widget.Toast.makeText(this, "أدخل session و uid صحيحين", android.widget.Toast.LENGTH_LONG).show()
                } else {
                    PocketApi.saveDemoCredentials(this, s, u)
                    android.widget.Toast.makeText(this, "تم الحفظ، اضغط زر API مرة أخرى للاتصال", android.widget.Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun openXlsxPicker() {
        val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "text/csv", "application/json"))
        }
        startActivityForResult(pick, reqImportXlsx)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqImportXlsx) {
            val uri = data?.data
            if (resultCode != RESULT_OK || uri == null) return
            Thread {
                val added = try { XlsxTradeImporter.import(this, uri) } catch (_: Exception) { -1 }
                runOnUiThread {
                    if (added < 0) {
                        android.widget.Toast.makeText(this, "تعذّر قراءة الملف، تأكد أنه ملف تصدير Pocket Option", android.widget.Toast.LENGTH_LONG).show()
                    } else {
                        val rep = XlsxTradeImporter.currencies(this).joinToString("\n\n") { XlsxTradeImporter.report(this, it) }
                        android.app.AlertDialog.Builder(this)
                            .setTitle("تم استيراد $added صفقة جديدة")
                            .setMessage(if (rep.isBlank()) "لا توجد صفقات بعد" else rep)
                            .setPositiveButton("حسناً", null)
                            .show()
                    }
                }
            }.start()
            return
        }
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        } else if (requestCode == reqChartImage && resultCode == RESULT_OK && data?.data != null) {
            try {
                val uri = data.data!!
                val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bitmap == null) {
                    Toast.makeText(this, "تعذر قراءة الصورة", Toast.LENGTH_SHORT).show()
                } else {
                    selectedChartBitmap?.recycle()
                    selectedChartBitmap = bitmap
                    imagePreview.setImageBitmap(bitmap)
                    imagePreview.visibility = View.VISIBLE
                    aiResult.text = "تم اختيار الصورة. اختر التحليل الكمي المحلي أو اختبار خادم الرؤية."
                }
            } catch (_: Exception) {
                Toast.makeText(this, "حدث خطأ أثناء فتح الصورة", Toast.LENGTH_LONG).show()
            }
        }
    }


    private fun runLocalImageAnalysis(source: Bitmap) {
        aiResult.text = "جارٍ تحليل الصورة محليًا..."
        Thread {
            var candles: List<Candle> = emptyList()
            val resultText = try {
                val maxSide = 1800
                val scale = minOf(1.0, maxSide.toDouble() / maxOf(source.width, source.height))
                val bitmap = if (scale < 1.0) Bitmap.createScaledBitmap(
                    source, (source.width * scale).toInt().coerceAtLeast(1),
                    (source.height * scale).toInt().coerceAtLeast(1), true
                ) else source
                val pixels = IntArray(bitmap.width * bitmap.height)
                bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
                candles = CandleReader.read(pixels, bitmap.width, bitmap.height)
                if (bitmap !== source) bitmap.recycle()
                if (candles.size < 30) {
                    "لم يستطع المحلل المحلي استخراج 30 شمعة موثوقة. الشموع المكتشفة: ${candles.size}.\nجرّب صورة أوضح، مع إظهار الشموع فقط وإخفاء القوائم قدر الإمكان."
                } else {
                    val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
                    val reg = Signal.regimeOf(candles)
                    val key = "${cfg.getInt("tf", 60)}_$reg"
                    val output = Signal.compute(
                        candles, cfg.getInt("conf", 58), cfg.getInt("sens", 3),
                        Learner.weights(this, key), Learner.bias(this, key)
                    )
                    val quant = QuantitativeBackgroundEngine.analyze(candles)
                    "التحليل الكمي المحلي للصورة\nالاتجاه الفني: ${when (output.side) { 1 -> "شراء محتمل"; -1 -> "بيع محتمل"; else -> "انتظار" }}\nدرجة توافق المحرك الفني: ${output.conf}%\nعدد الشموع: ${candles.size}\n\nالأسباب: ${output.why} ${output.block}\n\n${quant?.compactLine() ?: "البيانات الكمية غير كافية"}${AdvancedMarketAnalysis.summary(candles)}\n\nملاحظة: درجات التوافق ليست احتمال ربح. Footprint تقديري من OHLC ولا يمثل حجم تداول حقيقيًا."
                }
            } catch (e: Exception) {
                "تعذر تحليل الصورة محليًا: ${e.message ?: "خطأ غير معروف"}"
            }
            runOnUiThread {
                aiResult.text = resultText
                if (candles.size >= 30) renderAdvancedDashboard(candles)
            }
        }.start()
    }

    private fun renderDashboardPlaceholder() {
        advancedDashboard.removeAllViews()
        val t = TextView(this).apply {
            text = "آخر حالة للمحرك الكمي: ${QuantitativeBackgroundEngine.savedSummary(this@MainActivity)}\n\nتتحدث البيانات المحفوظة مع كل شمعة مغلقة بعد توافر 30 شمعة موثوقة."
            textSize = 14f
            setTextColor(Color.rgb(190, 204, 224))
            setPadding(12, 16, 12, 16)
        }
        advancedDashboard.addView(t)
    }

    private fun renderAdvancedDashboard(candles: List<Candle>) {
        advancedDashboard.removeAllViews()
        val fractals = AdvancedMarketAnalysis.fractals(candles)
        val trend = AdvancedMarketAnalysis.supertrend(candles).lastOrNull()
        val lastHigh = fractals.lastOrNull { it.isHigh }
        val lastLow = fractals.lastOrNull { !it.isHigh }
        val recent = candles.takeLast(30)
        val range = (recent.maxOfOrNull { it.high } ?: 0.0) - (recent.minOfOrNull { it.low } ?: 0.0)
        val tick = (range / 400.0).coerceAtLeast(0.01)
        val footprint = AdvancedMarketAnalysis.estimatedFromCandles(candles, tick, 80)
        val flow = AdvancedMarketAnalysis.analyzeFlow(footprint, trend?.direction ?: 0)
        val trendText = when (trend?.direction) { 1 -> "صاعد"; -1 -> "هابط"; else -> "غير متاح" }
        val trendColor = when (trend?.direction) { 1 -> Color.rgb(53, 190, 130); -1 -> Color.rgb(240, 95, 100); else -> Color.LTGRAY }

        fun addCard(title: String, body: String, accent: Int = Color.rgb(92, 160, 230)) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                background = GradientDrawable().apply {
                    setColor(Color.rgb(27, 39, 59)); cornerRadius = 16f
                    setStroke(2, accent)
                }
            }
            card.addView(TextView(this).apply {
                text = title; textSize = 15f; setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setTextColor(accent); setPadding(0, 0, 0, 6)
            })
            card.addView(TextView(this).apply {
                text = body; textSize = 14f; setTextColor(Color.rgb(225, 233, 245))
            })
            advancedDashboard.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
        }

        addCard("اتجاه Supertrend · ATR 10 / معامل 3", "$trendText\nقيمة الخط: ${trend?.value?.let { String.format(java.util.Locale.US, "%.4f", it) } ?: "—"}", trendColor)
        addCard("Fractal · خمس شموع", "آخر قمة مؤكدة: ${lastHigh?.price?.let { String.format(java.util.Locale.US, "%.4f", it) } ?: "—"}\nآخر قاع مؤكد: ${lastLow?.price?.let { String.format(java.util.Locale.US, "%.4f", it) } ?: "—"}")
        val quantitative = QuantitativeBackgroundEngine.analyze(candles)
        if (quantitative != null) {
            addCard("المحرك الكمي المستقل · يعمل بالخلفية", quantitative.compactLine() +
                "\nSupertrend: ${if (quantitative.supertrend > 0) "صاعد" else if (quantitative.supertrend < 0) "هابط" else "محايد"}" +
                "\n+DI ${String.format(java.util.Locale.US, "%.1f", quantitative.plusDi)} | -DI ${String.format(java.util.Locale.US, "%.1f", quantitative.minusDi)}" +
                "\nدعم مؤكد: ${quantitative.support?.let { String.format(java.util.Locale.US, "%.5f", it) } ?: "—"}" +
                " | مقاومة مؤكدة: ${quantitative.resistance?.let { String.format(java.util.Locale.US, "%.5f", it) } ?: "—"}" +
                "\nدرجة التوافق الكمي ليست احتمال ربح ولا تُستخدم كضمان لاتجاه الصفقة.", Color.rgb(90, 180, 170))
        }
        addCard("Volume Footprint · تقديري", "الشراء التقديري: ${String.format(java.util.Locale.US, "%.1f", footprint.totalBuy)}\nالبيع التقديري: ${String.format(java.util.Locale.US, "%.1f", footprint.totalSell)}\nDelta تقديري: ${String.format(java.util.Locale.US, "%.1f", footprint.delta)}\nPOC تقريبي: ${footprint.poc?.let { String.format(java.util.Locale.US, "%.4f", it) } ?: "—"}", Color.rgb(235, 180, 80))
        addCard("جدول الشموع الرقمي · آخر 10 شموع · تقديري", AdvancedMarketAnalysis.rowsText(candles, 10) + "\n\nالنشاط = مدى الشمعة ÷ المتوسط (ليس حجمًا فعليًا). الشراء/البيع تقدير من موقع الإغلاق. Δ = شراء − بيع، وΣΔ تراكمي.", Color.rgb(120, 200, 170))
        addCard("Footprint المرئي · شراء مقابل بيع", "الأشرطة الخضراء تمثل ضغط الشراء التقديري، والحمراء ضغط البيع التقديري. كل صف يمثل مستوى سعريًا، وΔ هو الفرق بينهما. الإطار الذهبي يحدد POC التقديري.", Color.rgb(135, 160, 210))
        advancedDashboard.addView(FootprintChartView(this, footprint.levels, footprint.poc), LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = (10 * resources.displayMetrics.density).toInt()
        })
        addCard(
            "محرك Order Flow الذكي · قراءة وصفية",
            "الميل: ${flow.dominantSide}\nقوة الميل النسبي: ${String.format(java.util.Locale.US, "%.1f", flow.pressurePercent)}%\nمستويات Buy Imbalance (3:1): ${flow.buyImbalances}\nمستويات Sell Imbalance (3:1): ${flow.sellImbalances}\n\n${flow.interpretation}\n\nمقارنة الاتجاه: ${flow.trendAgreement}\n\n${flow.limitations}",
            Color.rgb(110, 170, 220)
        )
        val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val technicalKey = "${cfg.getInt("tf", 60)}_${Signal.regimeOf(candles)}"
        val technicalOutput = Signal.compute(
            candles, cfg.getInt("conf", 58), cfg.getInt("sens", 3),
            Learner.weights(this, technicalKey), Learner.bias(this, technicalKey)
        )
        val decision = DecisionEngine.evaluate(
            technicalOutput, trend?.direction ?: 0, flow,
            footprint.quality == AdvancedMarketAnalysis.DataQuality.ESTIMATED_FROM_OHLC
        )
        val decisionColor = when (decision.colorCode) {
            1 -> Color.rgb(53, 190, 130)
            -1 -> Color.rgb(240, 95, 100)
            else -> Color.rgb(235, 180, 80)
        }
        addCard(
            "القرار التحليلي الموحّد · CANDLE QUANT",
            "النتيجة: ${decision.title}\nدرجة التوافق: ${decision.confidence}%\nالحالة: ${decision.status}\n\nالأسباب:\n• " +
                decision.reasons.joinToString("\n• ") +
                "\n\nالإشارة النهائية تعتمد على المحرك الفني أو الكمي محلياً؛ جمني اختياري ويُشغَّل أو يُوقف من أزرار المحركات.",
            decisionColor
        )
        addCard("جودة البيانات", "تقديري من شكل الشموع فقط — ليس حجم تداول حقيقيًا ولا بيانات Bid/Ask. لا نستنتج Absorption أو Exhaustion من هذه البيانات. البيانات الحقيقية ستظهر فقط بعد ربط مصدر صفقات موثوق.", Color.rgb(235, 180, 80))
    }

    private fun runVisionImageAnalysis(source: Bitmap, endpoint: String, platform: String) {
        aiResult.text = "جارٍ اختبار Gemini يدوياً على صورة الشارت..."
        Thread {
            var scaledBitmap: Bitmap? = null
            val result = try {
                val maxSide = VisionAiConfig.MAX_IMAGE_SIDE
                val scale = minOf(1.0, maxSide.toDouble() / maxOf(source.width, source.height))
                val bitmap = if (scale < 1.0) Bitmap.createScaledBitmap(
                    source, (source.width * scale).toInt().coerceAtLeast(1),
                    (source.height * scale).toInt().coerceAtLeast(1), true
                ).also { scaledBitmap = it } else source
                val stream = java.io.ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, VisionAiConfig.JPEG_QUALITY, stream)
                when (val response = VisionAnalysisClient(endpoint).analyzeChart(
                    stream.toByteArray(), platform
                )) {
                    is VisionAnalysisResult.Success -> {
                        VisionAiStore.updateResult(this, "نجح تحليل الصورة من الخادم (${response.model.ifBlank { "Vision AI" }})", response.analysis, response.direction, response.model)
                        "التحليل البصري من الخادم\nالاتجاه: ${response.direction}\n\n${response.analysis}\n\nهذا رأي بصري مساعد، وليس إشارة تداول آلية."
                    }
                    is VisionAnalysisResult.Failure -> {
                        VisionAiStore.updateStatus(this, "فشل اختبار Apps Script: ${response.message}")
                        "فشل تحليل الصورة: ${response.message}"
                    }
                }
            } catch (e: Exception) {
                val message = "تعذر تجهيز الصورة: ${e.message ?: "خطأ غير معروف"}"
                VisionAiStore.updateStatus(this, message)
                message
            } finally {
                try { scaledBitmap?.recycle() } catch (_: Exception) {}
            }
            runOnUiThread { aiResult.text = result }
        }.start()
    }

    override fun onDestroy() {
        selectedChartBitmap?.recycle()
        selectedChartBitmap = null
        super.onDestroy()
    }

    private fun refreshStats() {
        val cfg0 = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        autoBtn.text = if (cfg0.getInt("auto", 0) == 1) "🟢 مفعّل — اضغط للإيقاف" else "⚪ تفعيل التداول التلقائي"
        autoStat.text = "التداول التلقائي: " + (if (cfg0.getInt("auto", 0) == 1) "🟢 مفعّل (تجريبي)" else "⚪ متوقف") +
            " | الخدمة: " + (if (TapService.instance != null) "تعمل" else "غير مفعّلة") +
            " | الأزرار: " + (if (cfg0.getInt("buyX", 0) > 0 && cfg0.getInt("sellX", 0) > 0) "مضبوطة" else "غير مضبوطة")
        val s = getSharedPreferences("stats", Context.MODE_PRIVATE)
        val w = s.getInt("w", 0)
        val l = s.getInt("l", 0)
        val n = w + l
        val rate = if (n == 0) 0 else w * 100 / n
        val ps = Learner.paperStats(this)
        stats.text = "صفقاتك المؤكدة: $n | ربح $w | خسارة $l | $rate%\n" +
            "الإشارات الافتراضية: ${ps.first} | النجاح ${(ps.second * 100).toInt()}%\n" +
            "عينات التعلم: ${Learner.samples(this)}" + (if (Learner.locked(this, 1.0 / (1.0 + getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("payout", 85) / 100.0))) "\n⛔ قفل الأمان مفعّل (نجاح الإشارات دون نقطة التعادل)" else "") +
            Learner.keyReport(this).let { if (it.isEmpty()) "" else "\nحسب الفاصل وحالة السوق (إشارات افتراضية):\n$it" }
    }
}
