package com.candle.assistant

import android.content.Context
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Quantitative background layer. It consumes only the candles already read by the app.
 * Scores are technical agreement measures, never probabilities of profit.
 */
object QuantitativeBackgroundEngine {
    data class Snapshot(
        val candleCount: Int,
        val side: Int,
        val score: Double,
        val supertrend: Int,
        val rsi14: Double,
        val adx14: Double,
        val plusDi: Double,
        val minusDi: Double,
        val pressure: Double,
        val atrPercent: Double,
        val support: Double?,
        val resistance: Double?,
        val updatedAt: Long
    ) {
        val sideText: String get() = when (side) { 1 -> "يميل للصعود"; -1 -> "يميل للهبوط"; else -> "محايد / انتظار" }
        val scoreText: String get() = String.format(java.util.Locale.US, "%.0f/100", abs(score) * 100.0)

        fun compactLine(): String = buildString {
            append("كمّي: ").append(sideText)
            append(" | توافق ").append(scoreText)
            append(" | RSI ").append(rsi14.toInt())
            append(" | ADX ").append(adx14.toInt())
            append(" | ضغط Δ ").append(String.format(java.util.Locale.US, "%+.2f", pressure))
            append(" | ATR ").append(String.format(java.util.Locale.US, "%.3f", atrPercent)).append("%")
        }

        fun toVisionContext(): String = buildString {
            append("candles=").append(candleCount)
            append("; quant_side=").append(side)
            append("; agreement_score=").append(String.format(java.util.Locale.US, "%.3f", score))
            append("; supertrend=").append(supertrend)
            append("; rsi14=").append(String.format(java.util.Locale.US, "%.2f", rsi14))
            append("; adx14=").append(String.format(java.util.Locale.US, "%.2f", adx14))
            append("; plus_di=").append(String.format(java.util.Locale.US, "%.2f", plusDi))
            append("; minus_di=").append(String.format(java.util.Locale.US, "%.2f", minusDi))
            append("; estimated_pressure_proxy=").append(String.format(java.util.Locale.US, "%.3f", pressure))
            append("; atr_percent=").append(String.format(java.util.Locale.US, "%.4f", atrPercent))
            support?.let { append("; support=").append(String.format(java.util.Locale.US, "%.6f", it)) }
            resistance?.let { append("; resistance=").append(String.format(java.util.Locale.US, "%.6f", it)) }
        }

        fun tradeAgreement(tradeSide: Int): String = when {
            tradeSide == 0 || side == 0 -> "التحليل الكمي غير حاسم أثناء الصفقة"
            side == tradeSide -> "التحليل الكمي يوافق اتجاه الصفقة"
            else -> "تحذير: التحليل الكمي يعارض اتجاه الصفقة"
        }
    }

    fun analyze(candles: List<Candle>): Snapshot? {
        if (candles.size < 30) return null
        val safe = candles.takeLast(150)
        val closes = safe.map { it.close }
        val last = safe.last()
        val atr = Ind.atr(safe, 14).coerceAtLeast(1e-9)
        val rsi = Ind.rsi(closes, 14).coerceIn(0.0, 100.0)
        val adx = Ind.adx(safe, 14)
        val trend = AdvancedMarketAnalysis.supertrend(safe, 10, 3.0).lastOrNull()?.direction ?: 0
        val pressure = AdvancedMarketAnalysis.pressureScore(safe, min(12, safe.size - 2))
        val fast = Ind.ema(closes.takeLast(30), 9).lastOrNull() ?: last.close
        val slow = Ind.ema(closes.takeLast(30), 21).lastOrNull() ?: last.close
        val fractals = AdvancedMarketAnalysis.fractals(safe, 2)
        val support = fractals.lastOrNull { !it.isHigh && it.price <= last.close }?.price
        val resistance = fractals.lastOrNull { it.isHigh && it.price >= last.close }?.price

        // Independent weighted votes. Neutral components do not contribute to the denominator.
        val votes = ArrayList<Pair<Double, Double>>()
        if (trend != 0) votes.add(trend.toDouble() to 0.28)
        val rsiVote = when { rsi >= 56.0 -> 1.0; rsi <= 44.0 -> -1.0; else -> 0.0 }
        if (rsiVote != 0.0) votes.add(rsiVote to 0.16)
        if (adx[0] >= 18.0) {
            val diVote = when { adx[1] > adx[2] * 1.08 -> 1.0; adx[2] > adx[1] * 1.08 -> -1.0; else -> 0.0 }
            if (diVote != 0.0) votes.add(diVote to 0.18)
        }
        if (abs(pressure) >= 0.16) votes.add((if (pressure > 0) 1.0 else -1.0) to 0.16)
        if (abs(fast - slow) / atr >= 0.08) votes.add((if (fast > slow) 1.0 else -1.0) to 0.12)
        val impulse = (last.close - safe[safe.size - 6].close) / atr
        if (abs(impulse) >= 0.20) votes.add((if (impulse > 0) 1.0 else -1.0) to 0.10)

        val totalWeight = votes.sumOf { it.second }.coerceAtLeast(1e-9)
        val score = (votes.sumOf { it.first * it.second } / totalWeight).coerceIn(-1.0, 1.0)
        val side = when { score >= 0.34 -> 1; score <= -0.34 -> -1; else -> 0 }
        return Snapshot(
            candleCount = safe.size,
            side = side,
            score = score,
            supertrend = trend,
            rsi14 = rsi,
            adx14 = adx[0].coerceAtLeast(0.0),
            plusDi = adx[1].coerceAtLeast(0.0),
            minusDi = adx[2].coerceAtLeast(0.0),
            pressure = pressure,
            atrPercent = atr / max(abs(last.close), 1e-9) * 100.0,
            support = support,
            resistance = resistance,
            updatedAt = System.currentTimeMillis()
        )
    }

    fun persist(context: Context, snapshot: Snapshot) {
        context.getSharedPreferences("quant_background", Context.MODE_PRIVATE).edit()
            .putInt("candles", snapshot.candleCount)
            .putInt("side", snapshot.side)
            .putFloat("score", snapshot.score.toFloat())
            .putInt("supertrend", snapshot.supertrend)
            .putFloat("rsi14", snapshot.rsi14.toFloat())
            .putFloat("adx14", snapshot.adx14.toFloat())
            .putFloat("plus_di", snapshot.plusDi.toFloat())
            .putFloat("minus_di", snapshot.minusDi.toFloat())
            .putFloat("pressure", snapshot.pressure.toFloat())
            .putFloat("atr_pct", snapshot.atrPercent.toFloat())
            .putLong("updated_at", snapshot.updatedAt)
            .putString("summary", snapshot.compactLine())
            .apply()
    }

    fun savedSummary(context: Context): String = context
        .getSharedPreferences("quant_background", Context.MODE_PRIVATE)
        .getString("summary", "لم يبدأ التحليل الكمي بعد") ?: "لم يبدأ التحليل الكمي بعد"
}
