package com.candle.assistant

import android.content.Context

/** Shared status/results for the app screen; nothing is rendered in the floating overlay. */
object VisionAiStore {
    private const val PREF = "vision_ai"

    fun updateStatus(context: Context, status: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("status", status)
            .putLong("updated_at", System.currentTimeMillis())
            .apply()
    }

    fun updateResult(context: Context, status: String, analysis: String, direction: String = "WAIT", model: String = "") {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("status", status)
            .putString("analysis", analysis.take(6000))
            .putString("direction", direction)
            .putString("model", model)
            .putLong("updated_at", System.currentTimeMillis())
            .apply()
    }

    fun status(context: Context): String = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .getString("status", "لم يتم تشغيل تحليل الصور بعد") ?: "لم يتم تشغيل تحليل الصور بعد"

    fun analysis(context: Context): String = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .getString("analysis", "") ?: ""
}
