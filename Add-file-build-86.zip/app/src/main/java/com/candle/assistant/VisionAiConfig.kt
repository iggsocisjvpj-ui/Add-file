package com.candle.assistant

/** Google Apps Script endpoint used only for Gemini chart-image analysis. */
object VisionAiConfig {
    const val DEFAULT_ENDPOINT = "https://script.google.com/macros/s/AKfycbz5LD9togwHN1Vk00rxaMsVoY-h54g5NpcTC76WqADdq7G3N3YTHGWh-Jtju30PsFg3Rw/exec"
    const val DEFAULT_PLATFORM = "Pocket Option"

    fun normalizeEndpoint(value: String): String = value.trim()
}
