package com.candle.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * سجل الصفقات المؤكدة وميزات الدخول الفنية/الكمية؛ يُستخدم للتقارير ولفحص السياق.
 */
object TradeJournal {
    private const val PREF = "trade_journal"

    class Rec(
        val time: Long, val symbol: String, val side: String, val win: Boolean,
        val hour: Int, val entrySec: Int, val move: String,
        val x: DoubleArray? = null
    )

    @Volatile private var cache: List<Rec>? = null

    fun invalidate() { cache = null }

    private fun parse(o: JSONObject): Rec? {
        val t = o.optLong("time", 0L)
        if (t <= 0L) return null
        val cal = Calendar.getInstance()
        cal.timeInMillis = t
        val hour = if (o.has("hour")) o.optInt("hour") else cal.get(Calendar.HOUR_OF_DAY)
        val fa = o.optJSONArray("features")
        var fx: DoubleArray? = null
        if (fa != null && fa.length() >= 12) {
            val arr = DoubleArray(fa.length())
            for (k in 0 until fa.length()) arr[k] = if (fa.isNull(k)) Double.NaN else fa.optDouble(k, Double.NaN)
            fx = arr
        }
        return Rec(
            t, o.optString("symbol", "غير معروف"), o.optString("side", ""),
            o.optString("result") == "WIN", hour, o.optInt("entrySec", -1),
            o.optString("moveTag", ""), fx
        )
    }

    fun records(c: Context): List<Rec> {
        val cached = cache
        if (cached != null) return cached
        val raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("records", "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val out = ArrayList<Rec>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val r = parse(o)
            if (r != null) out.add(r)
        }
        cache = out
        return out
    }

    fun pairs(c: Context): List<String> =
        records(c).groupBy { it.symbol }.entries.sortedByDescending { it.value.size }.map { it.key }

    /** الحد الأعلى لفاصل ثقة ويلسون (≈95% من جهة واحدة) لنسبة النجاح */
    private fun wilsonUpper(w: Int, n: Int): Double {
        if (n <= 0) return 1.0
        val z = 1.64
        val p = w.toDouble() / n
        val z2 = z * z
        val up = (p + z2 / (2.0 * n) + z * sqrt(p * (1 - p) / n + z2 / (4.0 * n * n))) / (1 + z2 / n)
        return up.coerceIn(0.0, 1.0)
    }

    private fun hourDist(a: Int, b: Int): Int {
        val d = abs(a - b)
        return minOf(d, 24 - d)
    }

    private fun pct(l: List<Rec>): String = if (l.isEmpty()) "—" else "${l.count { it.win } * 100 / l.size}%"

    /**
     * فحص السياق: 0 لا شيء، 1 تنبيه، 2 حجب الإشارة.
     * الحجب فقط عندما تكون العينة كافية والحد الأعلى لفاصل الثقة ما زال أقل من نقطة التعادل be.
     */
    fun check(c: Context, symbol: String, hour: Int, be: Double): Pair<Int, String> {
        val all = records(c).filter { it.symbol == symbol }
        if (all.isEmpty()) return Pair(0, "")
        val near = all.filter { hourDist(it.hour, hour) <= 1 }
        val beTxt = (be * 100).toInt()
        if (near.size >= 12 && wilsonUpper(near.count { it.win }, near.size) < be) {
            return Pair(2, "$symbol قرب الساعة $hour: ${near.size} صفقة، نجاح ${pct(near)} (التعادل $beTxt%)")
        }
        if (all.size >= 15 && wilsonUpper(all.count { it.win }, all.size) < be) {
            return Pair(2, "$symbol عمومًا: ${all.size} صفقة، نجاح ${pct(all)} (التعادل $beTxt%)")
        }
        if (near.size >= 8 && near.count { it.win }.toDouble() / near.size < be) {
            return Pair(1, "سجلك لـ $symbol قرب الساعة $hour ضعيف: ${near.size} صفقة، نجاح ${pct(near)}")
        }
        return Pair(0, "")
    }

    /** نسخة نصية (CSV) من السجل للحفظ خارج التطبيق */
    fun exportCsv(c: Context): String {
        val raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("records", "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val sb = StringBuilder("time,symbol,side,result,hour,entrySec,moveTag,conf\n")
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val r = parse(o) ?: continue
            sb.append(r.time).append(',').append(r.symbol.replace(',', ' ')).append(',').append(r.side).append(',')
                .append(if (r.win) "WIN" else "LOSS").append(',').append(r.hour).append(',').append(r.entrySec).append(',')
                .append(r.move.replace(',', ' ')).append(',').append(o.optInt("conf", 0)).append('\n')
        }
        return sb.toString()
    }

    /** استيراد نص CSV (من الحافظة) ودمجه دون تكرار؛ يرجع عدد الصفقات المضافة */
    fun importCsv(c: Context, text: String): Int {
        val p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val old = try { JSONArray(p.getString("records", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val seen = HashSet<String>()
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            seen.add("${o.optLong("time")}|${o.optString("symbol")}")
        }
        var added = 0
        for (line in text.lines()) {
            val f = line.trim().split(",")
            if (f.size < 8) continue
            val t = f[0].toLongOrNull() ?: continue
            if (!seen.add("$t|${f[1]}")) continue
            val o = JSONObject()
            o.put("time", t); o.put("symbol", f[1]); o.put("side", f[2])
            o.put("result", if (f[3] == "WIN") "WIN" else "LOSS")
            o.put("hour", f[4].toIntOrNull() ?: 0); o.put("entrySec", f[5].toIntOrNull() ?: -1)
            o.put("moveTag", f[6])
            // يدعم CSV القديم ذي عمود aiSide، لكن لا يعيد استخدامه في المحرك الجديد.
            val confIndex = if (f.size >= 9) 8 else 7
            o.put("conf", f[confIndex].toIntOrNull() ?: 0); o.put("imported", true)
            old.put(o)
            added++
        }
        if (added > 0) {
            val list = ArrayList<JSONObject>()
            for (i in 0 until old.length()) { val o = old.optJSONObject(i); if (o != null) list.add(o) }
            list.sortBy { it.optLong("time") }
            val capped = JSONArray()
            for (o in list.takeLast(500)) capped.put(o)
            p.edit().putString("records", capped.toString()).apply()
            invalidate()
        }
        return added
    }

    private fun featDist(a: DoubleArray, b: DoubleArray): Double {
        val n = minOf(a.size, b.size, 12)
        var s = 0.0
        var k = 0
        for (i in 0 until n) {
            if (a[i].isFinite() && b[i].isFinite()) { val d = a[i] - b[i]; s += d * d; k++ }
        }
        return if (k < 6) 9.0 else sqrt(s / k)
    }

    /**
     * ذاكرة الأخطاء: هل تشبه الإشارة الحالية (نفس الاتجاه ونفس بصمة المؤشرات) صفقات سابقة خاسرة؟
     * 0 لا شيء، 1 تنبيه، 2 حجب (عينة كافية وفاصل الثقة العلوي لنسبة النجاح ما زال أقل من نقطة التعادل).
     */
    fun mistakeCheck(c: Context, symbol: String, side: Int, x: DoubleArray, be: Double): Pair<Int, String> {
        val sideStr = if (side == 1) "BUY" else "SELL"
        val near = ArrayList<Rec>()
        for (r in records(c)) {
            if (r.side != sideStr) continue
            val rx = r.x ?: continue
            if (featDist(rx, x) < 0.30) near.add(r)
        }
        if (near.isEmpty()) return Pair(0, "")
        val local = near.filter { it.symbol == symbol }
        val lw = local.count { it.win }
        if (local.size >= 4 && wilsonUpper(lw, local.size) < be) {
            return Pair(2, "نمط يشبه ${local.size} صفقات سابقة على $symbol ربحت منها $lw فقط")
        }
        val gw = near.count { it.win }
        if (near.size >= 12 && wilsonUpper(gw, near.size) < be) {
            return Pair(2, "نمط يشبه ${near.size} صفقات سابقة (كل الأزواج) ربحت منها $gw فقط")
        }
        if (local.size >= 3 && lw.toDouble() / local.size < be) {
            return Pair(1, "يشبه ${local.size} صفقات سابقة على $symbol ربحت منها $lw فقط")
        }
        return Pair(0, "")
    }

    private fun entryBucket(s: Int): Int = when {
        s < 0 -> -1
        s < 5 -> 0
        s < 15 -> 1
        s < 30 -> 2
        else -> 3
    }

    /**
     * ذاكرة تكرار الخطأ: تقارن الدخول الحالي بصفقات سابقة (آخر 7 أيام) على الزوج والاتجاه نفسيهما.
     * 2 حجب: خسارتان مشابهتان على الأقل وصافي الخسائر خسارتان فأكثر. 1 تنبيه.
     * المقارنة تتم ببصمة المؤشرات، وبالسياق (حركة السعر قبل الدخول + ثانية الدخول).
     */
    fun repeatCheck(c: Context, symbol: String, side: Int, x: DoubleArray, moveTag: String, entrySec: Int): Pair<Int, String> {
        val sideStr = if (side == 1) "BUY" else "SELL"
        val since = System.currentTimeMillis() - 7L * 24L * 3600L * 1000L
        val same = records(c).filter { it.symbol == symbol && it.side == sideStr && it.time >= since }.takeLast(60)
        if (same.isEmpty()) return Pair(0, "")
        var fl = 0
        var fw = 0
        for (r in same) {
            val rx = r.x ?: continue
            if (featDist(rx, x) < 0.45) { if (r.win) fw++ else fl++ }
        }
        if (fl >= 2 && fl - fw >= 2) return Pair(2, "تكرار خطأ: بصمة مؤشرات مشابهة خسرت $fl مرات وربحت $fw على $symbol")
        if (moveTag.isNotEmpty()) {
            val b = entryBucket(entrySec)
            var cl = 0
            var cw = 0
            for (r in same) {
                if (r.move != moveTag || entryBucket(r.entrySec) != b) continue
                if (r.win) cw++ else cl++
            }
            if (cl >= 2 && cl - cw >= 2) return Pair(2, "تكرار خطأ: نفس حركة السعر ($moveTag) ونفس توقيت الدخول خسرت $cl مرات وربحت $cw")
        }
        if (fl >= 2 && fl > fw) return Pair(1, "بصمة مشابهة لصفقات خاسرة: $fl خسارة مقابل $fw ربح")
        return Pair(0, "")
    }

    fun pairLine(c: Context, symbol: String): String {
        val l = records(c).filter { it.symbol == symbol }
        return if (l.isEmpty()) "سجل $symbol: لا صفقات مسجلة بعد"
        else "سجل $symbol: ${l.size} صفقة | نجاح ${pct(l)}"
    }

    private fun line(name: String, l: List<Rec>): String =
        "• $name: ${l.size} صفقة | ${l.count { it.win }} ربح | نجاح ${pct(l)}"

    fun report(c: Context, symbol: String?): String {
        val all = records(c)
        val l = if (symbol == null) all else all.filter { it.symbol == symbol }
        if (l.isEmpty()) return "لا توجد صفقات مسجلة بعد.\nتُسجَّل الصفقة عند تأكيد نتيجتها من النافذة العائمة (ربحت/خسرت/تأكيد المقدّر)."
        val sb = StringBuilder()
        sb.append(if (symbol == null) "كل الأزواج" else symbol).append("\n")
        sb.append(line("الإجمالي", l)).append("\n")
        if (l.size < 30) sb.append("⚠ العينة صغيرة (أقل من 30 صفقة): النسب غير موثوقة إحصائيًا.\n")
        if (symbol == null) {
            sb.append("\nحسب الزوج\n")
            for ((k, v) in l.groupBy { it.symbol }.entries.sortedByDescending { it.value.size }) sb.append(line(k, v)).append("\n")
        }
        sb.append("\nحسب ساعات اليوم (توقيت الهاتف)\n")
        for ((b, v) in l.groupBy { it.hour / 3 }.entries.sortedBy { it.key }) {
            sb.append(line(String.format(Locale.US, "%02d:00–%02d:59", b * 3, b * 3 + 2), v)).append("\n")
        }
        sb.append("\nحسب ثانية الدخول داخل الشمعة\n")
        val order = listOf("غير معروف", "0–4ث", "5–14ث", "15–29ث", "30ث+")
        val byEntry = l.groupBy {
            when {
                it.entrySec < 0 -> order[0]
                it.entrySec < 5 -> order[1]
                it.entrySec < 15 -> order[2]
                it.entrySec < 30 -> order[3]
                else -> order[4]
            }
        }
        for (k in order) { val v = byEntry[k] ?: continue; sb.append(line(k, v)).append("\n") }
        val withMove = l.filter { it.move.isNotEmpty() }
        if (withMove.isNotEmpty()) {
            sb.append("\nحسب حركة السعر قبل الدخول\n")
            for ((k, v) in withMove.groupBy { it.move }.entries.sortedByDescending { it.value.size }) sb.append(line(k, v)).append("\n")
        }
        sb.append("\nحسب الاتجاه\n")
        sb.append(line("شراء", l.filter { it.side == "BUY" })).append("\n")
        sb.append(line("بيع", l.filter { it.side == "SELL" })).append("\n")
        sb.append("\nآخر الصفقات\n")
        val fmt = SimpleDateFormat("MM/dd HH:mm", Locale.US)
        for (r in l.takeLast(25).reversed()) {
            val side = if (r.side == "BUY") "▲" else "▼"
            val sec = if (r.entrySec >= 0) " | ث${r.entrySec}" else ""
            val mv = if (r.move.isNotEmpty()) " | ${r.move}" else ""
            sb.append("${if (r.win) "✔" else "✘"} ${fmt.format(Date(r.time))} $side ${r.symbol}$sec$mv\n")
        }
        return sb.toString().trimEnd()
    }
}
