package com.candle.assistant

import kotlin.math.abs

/**
 * معايرة السعر من أرقام المحور الأيمن للشارت.
 * كل رقم مكتوب على المحور له موقع رأسي (y) وقيمة سعر، فنحسب خط الانحدار: السعر = m * y + c.
 * القراءات الخاطئة من OCR تُستبعد تلقائياً (أبعد نقطة عن الخط) ما دام يبقى 3 نقاط على الأقل،
 * ولا تُقبل المعايرة إلا إذا كانت متسقة بعد الاستبعاد.
 */
object AxisCalib {

    @Volatile var m: Double = Double.NaN
    @Volatile var c: Double = Double.NaN
    @Volatile var points: Int = 0
    @Volatile var maxError: Double = Double.NaN
    @Volatile var updatedAt: Long = 0L
    @Volatile var valid: Boolean = false
    @Volatile var status: String = "لم تُحسب المعايرة بعد"

    /** يُستدعى من الخدمة لعرض الحالة للمستخدم (مرة عند تغيّرها فقط) */
    var onStatus: ((String) -> Unit)? = null

    /** أقصى خطأ مسموح كنسبة من السعر (0.0002 = 0.02%) */
    private const val MAX_RELATIVE_ERROR = 0.0002

    /** مدة صلاحية المعايرة بعد آخر تحديث ناجح (ms) */
    private const val VALID_FOR_MS = 8000L

    /** pts: قائمة أزواج (y بالبكسل داخل صورة الشاشة، السعر المقروء) */
    fun update(pts: List<Pair<Double, Double>>) {
        val n0 = pts.size
        if (n0 < 3) {
            setStatus("المعايرة: نقاط غير كافية ($n0 من 3)", false, n0)
            return
        }
        val work = pts.toMutableList()
        var fit = fitLine(work)
        if (fit == null) {
            setStatus("المعايرة: أرقام المحور متطابقة الموقع", false, n0)
            return
        }

        // استبعاد القراءات الخاطئة: نحذف أبعد نقطة طالما خطؤها أكبر من الحد، مع بقاء 3 نقاط على الأقل
        while (work.size > 3) {
            val avg = work.sumOf { abs(it.second) } / work.size
            val (slope, icpt) = fit!!
            val worst = work.maxByOrNull { abs(slope * it.first + icpt - it.second) } ?: break
            val err = abs(slope * worst.first + icpt - worst.second)
            if (avg == 0.0 || err / abs(avg) <= MAX_RELATIVE_ERROR) break
            work.remove(worst)
            fit = fitLine(work) ?: break
        }

        val (slope, intercept) = fit!!
        val n = work.size
        var worst = 0.0
        var avgPrice = 0.0
        for ((y, p) in work) {
            val err = abs(slope * y + intercept - p)
            if (err > worst) worst = err
            avgPrice += p
        }
        avgPrice /= n
        val relErr = if (avgPrice != 0.0) worst / abs(avgPrice) else Double.MAX_VALUE
        val ok = n >= 3 && relErr <= MAX_RELATIVE_ERROR && slope < 0.0 // السعر يزيد كلما صعد الموقع (y يقل)

        m = slope
        c = intercept
        points = n
        maxError = worst
        updatedAt = System.currentTimeMillis()
        valid = ok
        val dropped = n0 - n
        setStatus(
            if (ok) "المعايرة صالحة: $n نقاط" + (if (dropped > 0) " (استُبعد $dropped)" else "") + ", أقصى خطأ ${"%.5f".format(worst)}"
            else "المعايرة غير متسقة: $n نقاط، أقصى خطأ ${"%.5f".format(worst)}",
            ok, n
        )
    }

    /** خط الانحدار للنقاط، أو null إن تطابقت مواقع النقاط */
    private fun fitLine(pts: List<Pair<Double, Double>>): Pair<Double, Double>? {
        val n = pts.size
        var sy = 0.0; var sp = 0.0; var syy = 0.0; var syp = 0.0
        for ((y, p) in pts) {
            sy += y; sp += p; syy += y * y; syp += y * p
        }
        val denom = n * syy - sy * sy
        if (denom == 0.0) return null
        val slope = (n * syp - sy * sp) / denom
        val intercept = (sp - slope * sy) / n
        return Pair(slope, intercept)
    }

    /** المعايرة صالحة الآن (حديثة وصالحة) */
    fun isUsable(now: Long = System.currentTimeMillis()): Boolean =
        valid && now - updatedAt < VALID_FOR_MS

    /** تحويل موقع رأسي إلى سعر، أو NaN إن لم تكن المعايرة صالحة */
    fun priceAtY(y: Double): Double =
        if (isUsable()) m * y + c else Double.NaN

    private var lastNotified = ""
    private fun setStatus(msg: String, ok: Boolean, n: Int) {
        status = msg
        // إشعار المستخدم عند تغيّر الحالة فقط، لا عند كل تحديث
        val key = (if (ok) "ok" else "bad") + (if (n >= 3) "" else "few")
        if (key != lastNotified) {
            lastNotified = key
            onStatus?.invoke(msg)
        }
    }
}
