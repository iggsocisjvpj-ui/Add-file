package com.candle.assistant

import android.content.Context
import kotlin.math.exp

/**
 * وحدة التعلم: أوزان مستقلة لكل (فاصل زمني × حالة سوق)، ونتائج مقارنة لكل منها.
 * المفتاح key = "الفاصل_الحالة" مثل 60_0 (0 عادي، 1 نشط، 2 هادئ).
 */
object Learner {
    const val N = 12
    const val VER = 6
    // 0 اتجاه EMA | 1 ارتداد EMA20 | 2 RSI7 | 3 دايفرجنس | 4 بولنجر | 5 جسم الشمعة | 6 ROC | 7 Z-Score | 8 ستوكاستك | 9 حركة السعر | 10 MACD | 11 ADX/DI
    private val DEF = doubleArrayOf(0.35, 0.28, 0.30, 0.22, 0.34, 0.26, 0.20, 0.26, 0.28, 0.30, 0.30, 0.22)
    private fun prefs(c: Context) = c.getSharedPreferences("learn", Context.MODE_PRIVATE)

    fun weights(c: Context, key: String): DoubleArray {
        val d = DEF.copyOf()
        val p = prefs(c).getString("w_$key", null)?.split(",")
        if (p != null && p.size == N) for (i in 0 until N) {
            val v = p[i].toDoubleOrNull()
            if (v != null && v.isFinite()) d[i] = v.coerceIn(-1.2, 1.2)
        }
        return d
    }

    fun bias(c: Context, key: String): Double = prefs(c).getFloat("b_$key", 0f).toDouble().coerceIn(-1.0, 1.0)

    private fun step(c: Context, key: String, x: DoubleArray, y: Double, rate: Double) {
        if (x.size != N || x.any { !it.isFinite() } || x.all { it == 0.0 }) return
        val w = weights(c, key)
        var b = bias(c, key)
        var z = b
        for (i in 0 until N) z += w[i] * x[i]
        z = z.coerceIn(-20.0, 20.0)
        val err = y - 1.0 / (1.0 + exp(-z))
        for (i in 0 until N) w[i] = (w[i] + rate * err * x[i]).coerceIn(-1.2, 1.2)
        b = (b + rate * err).coerceIn(-1.0, 1.0)
        val p = prefs(c)
        p.edit().putString("w_$key", w.joinToString(",")).putFloat("b_$key", b.toFloat())
            .putInt("samples", p.getInt("samples", 0) + 1).apply()
    }

    /** side: اتجاه الصفقة الفعلية، win: نتيجتها */
    fun learn(c: Context, key: String, x: DoubleArray, side: Int, win: Boolean, rate: Double) {
        if (side == 0) return
        step(c, key, x, if (if (side == 1) win else !win) 1.0 else 0.0, rate)
    }

    /** تعلّم من كل شمعة مغلقة: هل أغلقت صاعدة؟ */
    fun learnDir(c: Context, key: String, x: DoubleArray, up: Boolean, rate: Double) {
        step(c, key, x, if (up) 1.0 else 0.0, rate)
    }

    fun samples(c: Context): Int = prefs(c).getInt("samples", 0)

    /** نتيجة صفقة مؤكدة (إجمالي + لكل مفتاح) */
    fun stat(c: Context, win: Boolean, key: String) {
        val st = c.getSharedPreferences("stats", Context.MODE_PRIVATE)
        val k = if (win) "w" else "l"
        st.edit().putInt(k, st.getInt(k, 0) + 1).putInt("$k$key", st.getInt("$k$key", 0) + 1).apply()
    }

    /** نتيجة الإشارات الافتراضية (آخر 100 إجمالاً، وآخر 100 لكل مفتاح) */
    fun paper(c: Context, win: Boolean, key: String) {
        val p = prefs(c)
        val ch = if (win) "1" else "0"
        val all = (p.getString("paper", "") ?: "") + ch
        val per = (p.getString("pk_$key", "") ?: "") + ch
        p.edit().putString("paper", all.takeLast(100)).putString("pk_$key", per.takeLast(100)).apply()
    }

    fun paperStats(c: Context, key: String? = null): Pair<Int, Double> {
        val s = prefs(c).getString(if (key == null) "paper" else "pk_$key", "") ?: ""
        if (s.isEmpty()) return Pair(0, 0.0)
        return Pair(s.length, s.count { it == '1' }.toDouble() / s.length)
    }

    /** قفل الأمان: بعد 30 إشارة افتراضية على الأقل، إن كان النجاح أقل من 52% */
    fun locked(c: Context): Boolean = locked(c, 0.52)

    /** be = نقطة التعادل 1/(1+العائد). يُقفل بعد 30 إشارة افتراضية على الأقل إن كان النجاح أقل منها */
    fun locked(c: Context, be: Double): Boolean {
        val (n, r) = paperStats(c)
        return n >= 30 && r < be
    }

    /** قفل خاص بحالة السوق الحالية (فاصل × حالة) بعد 20 إشارة افتراضية فيها */
    fun lockedKey(c: Context, key: String, be: Double): Boolean {
        val s = prefs(c).getString("pk_$key", "") ?: ""
        return s.length >= 20 && s.count { it == '1' }.toDouble() / s.length < be
    }

    /** مقارنة النتائج حسب الفاصل الزمني وحالة السوق */
    fun keyReport(c: Context): String {
        val names = arrayOf("عادي", "نشط", "هادئ")
        val sb = StringBuilder()
        for ((k, v) in prefs(c).all) {
            if (!k.startsWith("pk_") || v !is String || v.isEmpty()) continue
            val parts = k.removePrefix("pk_").split("_")
            val reg = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val rate = v.count { it == '1' } * 100 / v.length
            sb.append("• ${parts[0]} ث / ${names.getOrElse(reg) { "؟" }}: ${v.length} إشارة، نجاح $rate%\n")
        }
        return sb.toString().trimEnd()
    }

    fun reset(c: Context) { prefs(c).edit().clear().putInt("ver", VER).apply() }
}
