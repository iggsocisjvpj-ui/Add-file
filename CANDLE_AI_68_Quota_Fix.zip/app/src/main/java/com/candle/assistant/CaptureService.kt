package com.candle.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    private class Paper(val side: Int, val x: DoubleArray, val entryTotal: Long, val key: String)
    private class Feat(val x: DoubleArray, val entryTotal: Long, val key: String)
    private class Trade(
        val side: Int, val x: DoubleArray, var entry: Double, var endAt: Long, val key: String,
        val totalAtEntry: Long, val fromCandleStart: Boolean, val auto: Boolean = false
    ) {
        var created = 0L
        var entryStarted = 0L       // وقت ضغط المستخدم لتأكيد دخول الصفقة
        var viaBalance = false      // دخول الصفقة مؤكد بانخفاض الرصيد
        var afterEntry = Double.NaN
        var stake = 0.0
        val symbol = "غير معروف"
        var maxFavorableAtr = 0.0
        var maxAgainstAtr = 0.0
        var samples = 0
        var lastSampleAt = 0L
        var lastObservedPrice = Double.NaN
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var root: LinearLayout? = null
    private var tv: TextView? = null
    private var rowA: LinearLayout? = null
    private var rowB: LinearLayout? = null
    private var rowC: LinearLayout? = null
    private var worker: HandlerThread? = null
    private val main = Handler(Looper.getMainLooper())
    private var lastRun = 0L
    private var bmp: Bitmap? = null
    private var rowBytes = ByteArray(0)
    private var cls = ByteArray(0)
    private var screenW = 1080
    private var screenH = 2400
    @Volatile private var alive = false
    private var bandText = ""

    private val lock = Any()
    private val buffer = CandleBuffer()
    private var state = 0                 // 0 تحليل، 1 صفقة جارية، 2 نتيجة بانتظار التأكيد
    private var candleStartMs = 0L
    private var rawSig: Output? = null
    private var paper: Paper? = null
    private var feat: Feat? = null
    private var trade: Trade? = null
    private var tradeAnalysisLine: String = "تحليل الصفقة: بانتظار تحديث الشمعة"
    private var resultEst = -1            // 1 ربح، 0 خسارة، -1 تعادل
    private var lastFormingClose = Double.NaN
    private var lastAtr = 1.0
    private var tfSec = 60
    private var rawKey = "60_0"
    private var diagRead = 0
    private var diagNew = 0
    private var diagBad = 0
    private val tickT = LongArray(600)
    private val tickP = DoubleArray(600)
    private var tickN = 0
    private val cooldownByKey = HashMap<String, Int>()
    private val resultBySymbol = HashMap<String, String>()
    private var activeSymbol = "غير معروف"
    private var autoCount = 0
    private var autoLossRun = 0
    private var autoDoneFor = -1L
    private val lossStreak = HashMap<String, Int>()
    private var prevSide = 0
    private var growthSeenAt = 0L
    private var curConf = 60
    private var curSens = 3
    private var cancelNote = ""
    private var ocrBytes = ByteArray(0)
    private var lastOcr = 0L
    private var lastProcessedAt = 0L
    private var verifiedByBalance = false

    // Gemini يعمل في خيط مستقل وبطلب واحد فقط كل 4 ثوانٍ كحد أدنى.
    private val cloudExecutor = Executors.newSingleThreadExecutor()
    private val cloudBusy = AtomicBoolean(false)
    @Volatile private var cloudStatus = "Gemini: غير مهيأ"
    @Volatile private var cloudAnalysisLine = ""
    @Volatile private var lastCloudDirection = 0
    private var lastCloudRequestAt = 0L
    @Volatile private var cloudBackoffUntil = 0L

    private var fullText = ""
    private var expanded = false
    @Volatile private var ovX = 0
    @Volatile private var ovY = 0
    @Volatile private var ovW = 0
    @Volatile private var ovH = 0
    @Volatile private var coverNote = ""
    private val confirmRunnable = Runnable { discard() }
    private val endRunnable = Runnable { synchronized(lock) { if (state == 1) finishTrade() } }
    // مؤقت مستقل عن قراءة الشموع: يحدّث عدّاد الصفقة كل ثانية حتى لو تعذرت قراءة الشارت
    private val ticker = object : Runnable {
        override fun run() {
            if (!alive) return
            synchronized(lock) {
                val nowT = System.currentTimeMillis()
                if (state == 1 || state == 3) tradeTick(nowT)
                else if (state == 0 && lastProcessedAt > 0 && nowT - lastProcessedAt > 5000) {
                    ui("⚠ لا تصل لقطات جديدة منذ ${(nowT - lastProcessedAt) / 1000} ث\nالشاشة ثابتة أو تعثّر الالتقاط. أعد تشغيل التحليل إن استمر", Signal.OV_AMBER, 0)
                }
            }
            main.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (alive) return START_NOT_STICKY
        startForegroundCompat()
        val code = intent.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        }
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            alive = true
            beginCapture(code, data)
        } catch (e: Exception) {
            alive = false
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cap", "التحليل", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAct = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "إيقاف", stopPi
        ).build()
        val n: Notification = Notification.Builder(this, "cap")
            .setContentTitle("محلل الشموع يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(stopAct)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }
    }

    private fun beginCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { if (alive) stopSelf() }
        }, main)

        val (w, h) = screenSize()
        screenW = w
        screenH = h
        val dpi = resources.displayMetrics.densityDpi
        val t = HandlerThread("analyze").also { it.start() }
        worker = t
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        display = proj.createVirtualDisplay(
            "cap", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        r.setOnImageAvailableListener({ rd -> onImage(rd) }, Handler(t.looper))
        showOverlay()
    }

    private fun onImage(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            if (!alive) return
            val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
            val sens = cfg.getInt("sens", 3).coerceIn(1, 5)
            // هدف المعالجة المحلية 50ms (20Hz)؛ المعدل الفعلي يظل محدوداً بمعدل إطارات MediaProjection والجهاز.
            val interval = 50L
            val now = System.currentTimeMillis()
            if (now - lastRun < interval) return
            lastRun = now
            val topPct = cfg.getInt("top", 16).coerceIn(0, 95)
            val botPct = cfg.getInt("bottom", 60).coerceIn(topPct + 3, 100)
            val tf = cfg.getInt("tf", 60).coerceAtLeast(5)
            val minConf = cfg.getInt("conf", 60).coerceIn(50, 95)

            val plane = img.planes[0]
            val rowStride = plane.rowStride
            val w = img.width
            val ih = img.height
            var topPx = ih * topPct / 100
            var botPx = ih * botPct / 100
            // النافذة العائمة تظهر في اللقطة نفسها، فنُخرج منطقتها من التحليل بدل أن تُقرأ كشموع
            if (ovW > 0 && ovY + ovH > topPx && ovY < botPx) {
                val mid = (topPx + botPx) / 2
                if (ovY + ovH / 2 < mid) topPx = minOf(botPx - 60, ovY + ovH + 4)
                else botPx = maxOf(topPx + 60, ovY - 4)
            }
            val top = topPx.coerceIn(0, ih - 20)
            val bandH = (botPx - top).coerceIn(10, ih - top)
            bandText = "المنطقة المحللة ${top * 100 / ih}% إلى ${(top + bandH) * 100 / ih}%"
            // قراءة مباشرة من ذاكرة اللقطة للمنطقة المطلوبة فقط، وتحويلها إلى أرقام (0/1/2) دون Bitmap
            val need = (bandH - 1) * rowStride + w * 4
            val buf = plane.buffer
            buf.position(top * rowStride)
            if (buf.remaining() < need) return
            if (rowBytes.size < need) rowBytes = ByteArray(need)
            buf.get(rowBytes, 0, need)
            maybeAnalyzeCloud(rowBytes.copyOf(need), w, bandH, rowStride, now)
            if (cls.size != w * bandH) cls = ByteArray(w * bandH)
            CandleReader.classifyRgba(rowBytes, rowStride, w, bandH, cls)

            // قراءة الرصيد ونوع الحساب (OCR) من شريط أعلى الشاشة، بشرط ألا تغطيه النافذة العائمة
            val ocrGap = if (state != 0) 500L else 1500L
            if (now - lastOcr >= ocrGap && !ScreenOcr.busy) {
                lastOcr = now
                val sh = (ih * (if (w > ih) 0.28 else 0.22)).toInt().coerceIn(60, ih / 2)
                if (ovW > 0 && ovY < sh + 8) {
                    ScreenOcr.coverNote = true
                } else {
                    ScreenOcr.coverNote = false
                    val need2 = (sh - 1) * rowStride + w * 4
                    buf.position(0)
                    if (buf.remaining() >= need2) {
                        if (ocrBytes.size < need2) ocrBytes = ByteArray(need2)
                        buf.get(ocrBytes, 0, need2)
                        val pxs = IntArray(w * sh)
                        for (y in 0 until sh) {
                            var i = y * rowStride
                            val o = y * w
                            for (x in 0 until w) {
                                val r = ocrBytes[i].toInt() and 255
                                val g = ocrBytes[i + 1].toInt() and 255
                                val b = ocrBytes[i + 2].toInt() and 255
                                pxs[o + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
                                i += 4
                            }
                        }
                        val bm = Bitmap.createBitmap(w, sh, Bitmap.Config.ARGB_8888)
                        bm.setPixels(pxs, 0, w, 0, 0, w, sh)
                        ScreenOcr.process(bm)
                    }
                }
            }

            val read = CandleReader.readCls(cls, w, bandH)
            process(read, now, tf, minConf, sens)
        } catch (e: Exception) {
            main.post { tv?.text = "خطأ في التحليل" }
        } finally {
            img.close()
        }
    }

    /**
     * يرسل منطقة الشارت فقط (لا الشاشة كاملة ولا شريط الرصيد) إلى Gemini.
     * لا يوقف التحليل المحلي، ولا يسمح بتداخل الطلبات أو تجاوز 15 طلباً/دقيقة.
     */
    private fun maybeAnalyzeCloud(rgba: ByteArray, width: Int, height: Int, rowStride: Int, now: Long) {
        val endpoint = getSharedPreferences("cfg", Context.MODE_PRIVATE)
            .getString("ai_backend", CloudAiConfig.DEFAULT_ENDPOINT)
            ?.trim().orEmpty().ifBlank { CloudAiConfig.DEFAULT_ENDPOINT }
        if (endpoint.isBlank()) {
            cloudStatus = "Gemini: أضف عنوان HTTPS من إعدادات التطبيق"
            return
        }
        if (now < cloudBackoffUntil || now - lastCloudRequestAt < 30000L || !cloudBusy.compareAndSet(false, true)) return
        lastCloudRequestAt = now
        val platform = getSharedPreferences("cfg", Context.MODE_PRIVATE)
            .getString("platform", "Pocket Option") ?: "Pocket Option"
        val trainingFeatures = synchronized(lock) { rawSig?.x?.copyOf() }
        val trainingKey = synchronized(lock) { rawKey }
        cloudStatus = "Gemini: جارٍ التحليل..."
        cloudExecutor.execute {
            var bitmap: Bitmap? = null
            try {
                val pixels = IntArray(width * height)
                for (y in 0 until height) {
                    var src = y * rowStride
                    val dst = y * width
                    for (x in 0 until width) {
                        val r = rgba[src].toInt() and 255
                        val g = rgba[src + 1].toInt() and 255
                        val b = rgba[src + 2].toInt() and 255
                        pixels[dst + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
                        src += 4
                    }
                }
                bitmap = Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
                val maxSide = 1280
                if (maxOf(width, height) > maxSide) {
                    val scale = maxSide.toDouble() / maxOf(width, height)
                    val scaled = Bitmap.createScaledBitmap(
                        bitmap!!, (width * scale).toInt().coerceAtLeast(1),
                        (height * scale).toInt().coerceAtLeast(1), true
                    )
                    bitmap?.recycle()
                    bitmap = scaled
                }
                val bytes = ByteArrayOutputStream()
                bitmap!!.compress(Bitmap.CompressFormat.JPEG, 78, bytes)
                val response = CloudAiClient(endpoint, null, 45_000).analyzeChart(bytes.toByteArray(), platform)
                when (response) {
                    is CloudAnalysisResult.Success -> {
                        val analysis = response.analysis
                        val upper = analysis.uppercase(java.util.Locale.ROOT)
                        val side = when {
                            Regex("إشارة التحليل\\s*[:：]\\s*BUY", RegexOption.IGNORE_CASE).containsMatchIn(analysis) -> 1
                            Regex("إشارة التحليل\\s*[:：]\\s*SELL", RegexOption.IGNORE_CASE).containsMatchIn(analysis) -> -1
                            Regex("إشارة التحليل\\s*[:：]\\s*WAIT", RegexOption.IGNORE_CASE).containsMatchIn(analysis) -> 0
                            upper.contains("BUY") || analysis.contains("شراء") || analysis.contains("صعود") -> 1
                            upper.contains("SELL") || analysis.contains("بيع") || analysis.contains("هبوط") -> -1
                            else -> 0
                        }
                        synchronized(lock) {
                            cloudAnalysisLine = analysis.take(900)
                            lastCloudDirection = side
                            // تعليم محلي خفيف من اتجاه Gemini؛ نتائج الصفقات المؤكدة تبقى أقوى.
                            if (side != 0 && trainingFeatures != null &&
                                trainingFeatures.size == Learner.N) {
                                Learner.learnDir(this@CaptureService, trainingKey, trainingFeatures,
                                    side == 1, 0.002)
                            }
                            cloudStatus = if (side == 0) "Gemini: وصل التحليل (انتظار/اتجاه غير واضح)"
                                else "Gemini: متصل — ملاحظة ${if (side == 1) "BUY" else "SELL"} نُقلت للتعلم المحلي"
                        }
                        main.post { if (alive) ui(fullText.substringBefore("\\nGemini:"), Signal.OV_GREEN, state) }
                    }
                    is CloudAnalysisResult.Failure -> {
                        if (response.message.contains("429") || response.message.contains("quota", true)) {
                            cloudBackoffUntil = System.currentTimeMillis() + 300_000L
                            cloudStatus = "Gemini: الحصة منتهية، إعادة المحاولة بعد 5 دقائق"
                        } else {
                            cloudStatus = "Gemini: ${response.message}"
                        }
                        main.post { if (alive) ui(fullText.substringBefore("\\nGemini:"), Signal.OV_AMBER, state) }
                    }
                }
            } catch (_: Exception) {
                cloudStatus = "Gemini: تعذر تجهيز صورة الشارت"
                main.post { if (alive) ui(fullText.substringBefore("\\nGemini:"), Signal.OV_AMBER, state) }
            } finally {
                try { bitmap?.recycle() } catch (_: Exception) {}
                cloudBusy.set(false)
            }
        }
    }

    private fun process(read: List<Candle>, now: Long, tf: Int, minConf: Int, sens: Int) {
        synchronized(lock) {
            tfSec = tf
            val detectedSymbol = ScreenOcr.currentSymbol
            if (state == 0 && detectedSymbol != "غير معروف" && detectedSymbol != activeSymbol) {
                activeSymbol = detectedSymbol
                buffer.clear()
                rawSig = null; paper = null; feat = null; trade = null
                state = 0; candleStartMs = 0L; growthSeenAt = 0L
                prevSide = 0; cancelNote = ""
            }
            curConf = minConf; curSens = sens
            lastProcessedAt = now
            // آخر شمعة ما زالت تتشكل، فلا تدخل في التحليل
            val closed = if (read.size > 1) read.dropLast(1) else emptyList()
            diagRead = closed.size
            if (closed.size < 12) {
                if (state == 0) ui("قراءة غير كافية: ${closed.size} شمعة فقط\nقرّب الشارت حتى تظهر 30 إلى 45 شمعة، وتأكد من حدود الشارت واتجاه الهاتف", Color.DKGRAY, 0)
                return
            }
            val bad = MarketValidator.check(closed)
            if (bad != null) {
                diagBad++
                if (state == 0) ui("⚪ لا تدخل — بيانات غير موثوقة: $bad\n$bandText\nتشخيص: قُرئت $diagRead | رفض $diagBad", Color.DKGRAY, 0)
                return
            }
            val forming = read.last()
            val hadPending = buffer.pending > 0
            buffer.update(closed)
            if (!hadPending && buffer.pending > 0) growthSeenAt = now
            else if (buffer.pending == 0 && buffer.appended == 0) growthSeenAt = 0L
            lastFormingClose = buffer.a * forming.close + buffer.b
            pushTick(now, lastFormingClose)
            lastAtr = Ind.atr(buffer.list, 14).coerceAtLeast(1e-6)
            if (buffer.wasReset) { candleStartMs = 0L; paper = null; rawSig = null }
            val newCandle = buffer.appended > 0
            if (newCandle) {
                diagNew++
                val ck = marketKey(tf, Signal.regimeOf(buffer.list))
                if ((cooldownByKey[ck] ?: 0) > 0) cooldownByKey[ck] = (cooldownByKey[ck] ?: 0) - 1
                candleStartMs = if (growthSeenAt > 0) growthSeenAt else now
                growthSeenAt = 0L
                evaluatePaper(buffer.appended)
            }
            when (state) {
                1, 3 -> {
                    tradeTick(now)
                    if (state == 1 && newCandle) analyzeTradeContext(now, minConf, sens)
                }
                0 -> analyzeTick(now, newCandle, tf, minConf, sens)
                else -> {}
            }
        }
    }

    /** بعد إغلاق الشمعة: يقيّم الإشارة الافتراضية (للإحصاء والقفل) ويتعلم اتجاه الشمعة من مؤشراتها */
    private fun evaluatePaper(appended: Int) {
        val p = paper; val f = feat
        paper = null; feat = null
        if (appended != 1) return
        val c = buffer.list.last()
        val diff = c.close - c.open
        if (abs(diff) < 0.02 * lastAtr) return
        if (p != null && buffer.total == p.entryTotal + 1) {
            val win = (p.side == 1 && diff > 0) || (p.side == -1 && diff < 0)
            Learner.paper(this, win, p.key)
        }
        if (f != null && buffer.total == f.entryTotal + 1) {
            Learner.learnDir(this, f.key, f.x, diff > 0, 0.01)
        }
    }

    private fun analyzeTick(now: Long, newCandle: Boolean, tf: Int, minConf: Int, sens: Int) {
        val have = buffer.list.size
        val diag = "تشخيص: قُرئت $diagRead | سجل $have | شموع جديدة $diagNew | إعادة بناء ${buffer.resets} | رفض $diagBad" + autoLine().let { if (it.isEmpty()) "" else "\n$it" }
        if (have < 30) {
            ui("⚪ لا تدخل — جاري تجميع الشموع: $have/30\n$bandText\n$diag", Color.DKGRAY, 0)
            return
        }
        if (newCandle || rawSig == null) {
            val reg = Signal.regimeOf(buffer.list)
            val key = marketKey(tf, reg)
            val s = Signal.compute(buffer.list, minConf, sens, Learner.weights(this, key), Learner.bias(this, key))
            rawSig = s
            rawKey = key
            if (newCandle) {
                paper = if (s.side != 0) Paper(s.side, s.x, buffer.total, key) else null
                feat = Feat(s.x, buffer.total, key)
                cancelNote = if (prevSide != 0 && s.side != prevSide)
                    "أُلغيت إشارة الشمعة السابقة: " + (if (s.side == 0) "تعارض أو ضعف المؤشرات" else "انعكس الاتجاه") else ""
                prevSide = s.side
            }
        }
        val sig = rawSig ?: return
        val since = if (candleStartMs > 0) (now - candleStartMs) / 1000.0 else -1.0
        val remain = if (since >= 0) (tf - since).toInt().coerceAtLeast(0) else -1
        val window = (tf * 0.2).coerceIn(5.0, 15.0)
        val inWindow = since in 0.0..window
        val payout = getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("payout", 85).coerceIn(50, 100)
        val be = 1.0 / (1.0 + payout / 100.0)
        val ps = Learner.paperStats(this, rawKey)
        val ev = ps.second * payout / 100.0 - (1.0 - ps.second)
        val paperLine = if (ps.first < 30) "اختبار افتراضي: ${ps.first}/30 (قيد المعايرة) | نقطة التعادل ${(be * 100).toInt()}%"
        else "اختبار افتراضي: ${(ps.second * 100).toInt()}% من آخر ${ps.first} | التعادل ${(be * 100).toInt()}% | القيمة المتوقعة ${fmt(ev * 100)}%"
        val wait = if (remain >= 0) "الشمعة القادمة بعد $remain ث" else "بانتظار بداية شمعة جديدة"
        val autoOn = getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("auto", 0) == 1
        // في التداول التجريبي التلقائي لا يحجب القفل الإشارات (الهدف جمع بيانات)، وتحميك حدود الصفقات والخسائر
        val locked = !autoOn && Learner.lockedKey(this, rawKey, be)
        val tail = (if (cancelNote.isNotEmpty()) "\n$cancelNote" else "") + (resultBySymbol[activeSymbol]?.let { "\n$it" } ?: "") + "\n$paperLine\n${numbersLine()}\n$diag"
        val sideTxt = if (sig.side == 1) "🟢 شراء" else "🔴 بيع"
        val col = if (sig.side == 1) Signal.OV_GREEN else Signal.OV_RED
        val body = "المدة: $tf ثانية (شمعة واحدة)\nالأسباب: ${sig.why}\n${sig.info}"
        when {
            sig.kind == Signal.SIGNAL && (cooldownByKey[rawKey] ?: 0) > 0 ->
                ui("🟡 انتظار — إيقاف مؤقت بعد خسارتين متتاليتين (${cooldownByKey[rawKey]} شموع متبقية)$tail", Signal.OV_AMBER, 0)
            sig.kind == Signal.SIGNAL && locked ->
                ui("🟡 انتظار — قفل الأمان: نتائج الإشارات الافتراضية دون نقطة التعادل ${(be * 100).toInt()}% (إجمالاً أو في حالة السوق الحالية)\nالتحليل يستمر خلفياً للتعلم$tail", Signal.OV_GRAY, 0)
            sig.kind == Signal.SIGNAL && inWindow -> {
                ui("$sideTxt — درجة التوافق ${sig.conf}%\nوقت الدخول: الآن (الثانية ${since.toInt()} من الشمعة)\n$body$tail", col, 0)
                maybeAutoTrade(sig)
            }
            sig.kind == Signal.SIGNAL && since < 0 ->
                ui("$sideTxt — درجة التوافق ${sig.conf}%\nوقت الدخول: غير مؤكد، ادخل مع بداية شمعة جديدة\n$body$tail", col, 0)
            sig.kind == Signal.SIGNAL ->
                ui("🟡 فرصة مراقبة — فاتت نافذة الشمعة الحالية\\n${watchSummary(sig)}\\n$wait$tail", Signal.OV_AMBER, 0)
            sig.kind == Signal.WAIT && watchEligible(sig) ->
                ui("🔎 فرصة قيد المراقبة\\n${watchSummary(sig)}\\nسبب عدم التأكيد: ${sig.block}\\n$wait$tail", Signal.OV_AMBER, 0)
            sig.kind == Signal.WAIT ->
                ui("🟡 انتظار — ${sig.block}\\n${sig.info}\\n$wait$tail", Signal.OV_AMBER, 0)
            else ->
                ui("⚪ لا تدخل — ${sig.block}\n$wait$tail", Signal.OV_GRAY, 0)
        }
    }

    /**
     * مرشح مراقبة فقط: لا يحول حالة WAIT إلى إشارة دخول.
     * العتبات أوسع لإظهار الإشارات القريبة من التأكيد.
     */
    private fun marketKey(tf: Int, regime: Int): String = "${activeSymbol.replace(' ', '_')}_${tf}_$regime"

    private fun watchEligible(sig: Output): Boolean {
        return sig.kind == Signal.WAIT && sig.conf >= 52 &&
            sig.agree >= 4 && sig.against <= 5
    }

    private fun watchSummary(sig: Output): String {
        val grade = when {
            sig.conf >= 68 && sig.agree >= 7 && sig.against <= 2 -> "مرشح قوي للمراقبة"
            sig.conf >= 60 && sig.agree >= 6 && sig.against <= 3 -> "مرشح متوسط للمراقبة"
            else -> "مرشح أولي يحتاج تأكيدًا"
        }
        val direction = if (sig.p >= 0.5) "صاعد مبدئيًا" else "هابط مبدئيًا"
        return "$grade | الاتجاه: $direction\\n" +
            "التوافق ${sig.conf}% | المتفقة ${sig.agree}/12 | المتعارضة ${sig.against}\\n" +
            "ليست إشارة دخول؛ انتظر إغلاق الشمعة وتأكيد الشروط."
    }

    /** حساب تجريبي مؤكد: ظهرت كلمة Demo (OCR أو نصوص الشاشة) ولم تظهر Real/Live خلال 20 ثانية */
    private fun demoOk(): Boolean {
        val now = System.currentTimeMillis()
        val d = maxOf(ScreenOcr.demoAt, TapService.lastDemoSeenAt)
        val r = maxOf(ScreenOcr.realAt, TapService.lastRealSeenAt)
        return now - d < 20000 && now - r > 20000
    }

    private fun autoLine(): String {
        val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (cfg.getInt("auto", 0) != 1) return ""
        val svc = if (TapService.instance != null) "الخدمة ✓" else "الخدمة ✗"
        val demo = if (demoOk()) "Demo ✓" else "Demo غير مؤكد ✗"
        val cal = if (cfg.getInt("buyX", 0) > 0 && cfg.getInt("sellX", 0) > 0) "الأزرار ✓" else "الأزرار ✗"
        val bal = ScreenOcr.stable(System.currentTimeMillis())
        val balTxt = if (bal.isNaN()) "الرصيد ✗" else "الرصيد ${String.format(java.util.Locale.US, "%.2f", bal)}"
        val cover = if (ScreenOcr.coverNote) "\n⚠ انقل النافذة العائمة لأسفل: تغطي شريط الحساب في أعلى الشاشة فلا أقرأ الرصيد" else ""
        return "تلقائي: $svc | $demo | $balTxt | $cal | صفقات $autoCount | خسائر متتالية $autoLossRun$cover"
    }

    private fun disableAuto(msg: String) {
        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putInt("auto", 0).apply()
        toast("أُوقف التداول التلقائي: $msg")
    }

    /** ينقر زر الشراء أو البيع تلقائياً (حساب تجريبي فقط، ولا ينقر إلا إن تحقق من ظهور Demo على الشاشة) */
    private fun maybeAutoTrade(sig: Output) {
        // Safety baseline: automatic trade taps are disabled until platform-specific
        // account verification and per-platform interaction tests are implemented.
        // Signal calculation and the on-screen analysis continue normally.
        return
    }

    private fun fmt(v: Double): String = String.format(java.util.Locale.US, "%+.2f", v)

    private fun pushTick(t: Long, p: Double) {
        if (p.isNaN()) return
        val i = tickN % tickT.size
        tickT[i] = t; tickP[i] = p; tickN++
    }

    /** وسيط الأسعار المقروءة خلال ±half ملّي ثانية حول t (أرقام السعر في مقياس السجل) */
    private fun priceAt(t: Long, half: Long): Double {
        val vals = ArrayList<Double>()
        val cnt = minOf(tickN, tickT.size)
        for (k in 0 until cnt) if (abs(tickT[k] - t) <= half) vals.add(tickP[k])
        if (vals.size < 2) return Double.NaN
        vals.sort()
        return vals[vals.size / 2]
    }

    private fun numbersLine(): String {
        if (buffer.list.isEmpty() || lastFormingClose.isNaN()) return ""
        val last = buffer.list.last()
        val p3 = priceAt(System.currentTimeMillis() - 3000, 700)
        val spd = if (p3.isNaN()) 0.0 else (lastFormingClose - p3) / lastAtr / 3.0
        return "أرقام: الشمعة الحالية ${fmt((lastFormingClose - last.close) / lastAtr)}×ATR | السرعة ${fmt(spd)}/ث | آخر شمعة ${fmt((last.close - last.open) / lastAtr)}×ATR"
    }

    private fun platformDurSec(): Int =
        getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("dur", 0).let { if (it >= 5) it else tfSec }

    private fun cancelEntry(msg: String) {
        main.removeCallbacks(endRunnable)
        trade = null; state = 0; rawSig = null
        ui(msg, Signal.OV_AMBER, 0)
        toast(msg)
    }

    /** بانتظار انخفاض الرصيد الذي يثبت أن الصفقة دخلت فعلاً في المنصة */
    private fun entryTick(now: Long) {
        val t = trade ?: return
        val ev = ScreenOcr.dropSince(t.created)
        if (ev != null) {
            t.viaBalance = true
            t.afterEntry = ev.new
            t.stake = ev.old - ev.new
            t.endAt = maxOf(ev.t - 1200, t.created) + platformDurSec() * 1000L
            state = 1
            tradeAnalysisLine = "تحليل أثناء الصفقة: بانتظار أول شمعة مغلقة"
            if (t.auto) autoCount++
            main.removeCallbacks(endRunnable)
            main.postDelayed(endRunnable, maxOf(1000L, t.endAt - now) + 30000)
            ui("✔ دخلت الصفقة فعلاً (انخفض الرصيد ${fmt(-t.stake)})\nسيستمر تحليل السوق أثناء الصفقة", Color.rgb(30, 90, 180), 1)
            return
        }
        // نبدأ مهلة مستقلة من لحظة ضغط المستخدم؛ created قد يكون أقدم
        // للبحث عن تغيّر الرصيد الذي حدث قبل الضغط على الزر.
        if (now > t.entryStarted + 25000) {
            cancelEntry("لم يتأكد دخول الصفقة بعد 25 ثانية: لم تُسجَّل. تحقق من الرصيد وحاول مجددًا")
            return
        }
        ui("جاري التحقق من دخول الصفقة في المنصة...\nأنتظر تحديث الرصيد (${(t.entryStarted + 25000 - now) / 1000} ث)", Color.rgb(30, 90, 180), 1)
    }

    /** متابعة التحليل أثناء الصفقة دون إصدار دخول جديد أو تغيير اتجاه الصفقة المفتوحة. */
    private fun analyzeTradeContext(now: Long, minConf: Int, sens: Int) {
        val t = trade ?: return
        val candles = buffer.list
        if (candles.size < 30) {
            tradeAnalysisLine = "تحليل أثناء الصفقة: بيانات غير كافية (${candles.size}/30 شمعة)"
            return
        }
        val regime = Signal.regimeOf(candles)
        val key = marketKey(tfSec, regime)
        val current = Signal.compute(candles, minConf, sens, Learner.weights(this, key), Learner.bias(this, key))
        val direction = when (current.side) {
            1 -> "السوق يميل للصعود"
            -1 -> "السوق يميل للهبوط"
            else -> "لا يوجد اتجاه مؤكد"
        }
        tradeAnalysisLine = "تحليل أثناء الصفقة: $direction | توافق ${current.conf}% | موافقة ${current.agree} | تعارض ${current.against}\\n${current.why}"
        // احفظ عينة إضافية عند كل شمعة مغلقة، مع عدم تعديل خصائص الدخول الأصلية.
        t.samples++
        t.lastSampleAt = now
    }

    private fun tradeTick(now: Long) {
        if (state == 3) { entryTick(now); return }
        val t = trade ?: return
        trackTradeProgress(t, now)
        if (t.viaBalance) {
            val bal = ScreenOcr.stable(now)
            if (!bal.isNaN()) {
                val delta = bal - t.afterEntry
                // ارتفع الرصيد: ربح أو استرداد (قد يصل قبل نهاية المدة التي ضبطتها)
                if (delta >= 0.9 * t.stake) { finishByBalance(delta, t); return }
                // لم يتغير الرصيد بعد الانتهاء بوقت كاف: خسارة
                if (now >= t.endAt + 5000 && abs(delta) < 0.5 * t.stake) { finishByBalance(delta, t); return }
            }
            if (now >= t.endAt + 20000) { finishTrade(); return }
        } else if (now >= t.endAt + 2000) {
            finishTrade(); return
        }
        val rem = ((t.endAt - now) / 1000).toInt()
        val side = if (t.side == 1) "▲ شراء" else "▼ بيع"
        if (rem > 0) {
            ui("صفقة جارية $side\nالمتبقي: $rem ث\nسيستمر تحليل السوق أثناء الصفقة. النتيجة تُقرأ من الرصيد\n${numbersLine()}", Color.rgb(30, 90, 180), 1)
        } else {
            ui("انتهى الوقت — أنتظر تحديث الرصيد لمعرفة النتيجة...\n${numbersLine()}", Color.rgb(30, 90, 180), 1)
        }
    }

    /** متابعة الصفقة وتسجيل مسار السعر دون تغيير قرار الدخول أو الخروج. */
    private fun trackTradeProgress(t: Trade, now: Long) {
        val price = if (!lastFormingClose.isNaN()) lastFormingClose else priceAt(now, 900)
        if (price.isNaN() || t.entry.isNaN()) return
        val signed = (price - t.entry) * t.side
        val atr = lastAtr.coerceAtLeast(1e-9)
        val moveAtr = signed / atr
        t.maxFavorableAtr = maxOf(t.maxFavorableAtr, moveAtr)
        t.maxAgainstAtr = maxOf(t.maxAgainstAtr, -moveAtr)
        t.lastObservedPrice = price
        if (now - t.lastSampleAt >= 5000) {
            t.samples++
            t.lastSampleAt = now
        }
    }

    /** حفظ سجل تعلّم محلي محدود الحجم؛ النتيجة اليدوية تظل قابلة للتصحيح قبل الحفظ. */
    private fun saveTradeJournal(t: Trade, won: Boolean, source: String) {
        val prefs = getSharedPreferences("trade_journal", Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString("records", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val features = JSONArray()
        t.x.forEach { features.put(if (it.isFinite()) it else JSONObject.NULL) }
        val item = JSONObject()
            .put("time", System.currentTimeMillis())
            .put("symbol", activeSymbol)
            .put("marketKey", t.key)
            .put("side", if (t.side == 1) "BUY" else "SELL")
            .put("entry", t.entry)
            .put("durationSeconds", platformDurSec())
            .put("result", if (won) "WIN" else "LOSS")
            .put("resultSource", source)
            .put("maxFavorableATR", t.maxFavorableAtr)
            .put("maxAgainstATR", t.maxAgainstAtr)
            .put("observations", t.samples)
            .put("features", features)
            .put("featureNames", JSONArray(listOf("EMA trend","EMA20 pullback","RSI","RSI divergence","Bollinger","Candle body","ROC","ZScore","Stochastic","Price levels/patterns","MACD","ADX/DI")))
        old.put(item)
        val capped = JSONArray()
        for (i in maxOf(0, old.length() - 200) until old.length()) capped.put(old.getJSONObject(i))
        prefs.edit().putString("records", capped.toString()).apply()
    }

    /** النتيجة من تغيّر الرصيد الفعلي: ربح (ارتفاع أكبر من المبلغ)، استرداد (يساوي المبلغ)، خسارة (لا تغيّر) */
    private fun finishByBalance(delta: Double, t: Trade) {
        main.removeCallbacks(endRunnable)
        val res = when {
            delta >= 1.05 * t.stake -> 1
            delta >= 0.95 * t.stake -> -1
            abs(delta) < 0.5 * t.stake -> 0
            else -> -2
        }
        if (res == -2) { finishTrade(); return }     // قراءة غير منطقية: نرجع للتقدير بالسعر مع تأكيدك
        resultEst = res
        verifiedByBalance = true
        state = 2
        if (res == -1) {
            resultBySymbol[activeSymbol] = "آخر صفقة لهذا الزوج: تعادل (استرداد المبلغ) — لم تُسجَّل"
            discard()
            return
        }
        confirm(null)
    }

    /** يقدّر النتيجة من سعر الدخول والخروج المقروءين، ولا يسجّلها: التسجيل فقط بضغطك */
    private fun finishTrade() {
        val t = trade ?: return
        main.removeCallbacks(endRunnable)
        val exit = priceAt(t.endAt, 1500)
        val atr = lastAtr
        val thr = 0.10 * atr
        val diff = exit - t.entry
        var note = ""
        var est = -1
        if (diff.isNaN()) {
            note = "تعذّرت قراءة سعر الخروج"
        } else if (abs(diff) < thr) {
            note = "فرق السعر ضئيل جداً (${fmt(diff / atr)}×ATR) فلا يمكن الجزم"
        } else {
            est = if ((t.side == 1 && diff > 0) || (t.side == -1 && diff < 0)) 1 else 0
            // تحقق ثانٍ من الشمعة المغلقة إن بدأت الصفقة مع بداية الشمعة
            if (t.fromCandleStart && buffer.total == t.totalAtEntry + 1) {
                val c = buffer.list.last()
                val cd = c.close - c.open
                if (abs(cd) >= thr && ((cd > 0) != (diff > 0))) {
                    est = -1
                    note = "تعارض: سعر الخروج يخالف اتجاه الشمعة المغلقة"
                }
            }
        }
        resultEst = est
        verifiedByBalance = false
        state = 2
        val side = if (t.side == 1) "▲ شراء" else "▼ بيع"
        val col = when (est) { 1 -> Signal.OV_GREEN; 0 -> Signal.OV_RED; else -> Signal.OV_AMBER }
        val msg = when (est) {
            1 -> "انتهت الصفقة ($side)\nالنتيجة المقدّرة: ✔ ربح (فرق السعر ${fmt(diff / atr)}×ATR)\nلن تُسجَّل قبل ضغطك: «تأكيد المقدّر» أو صحّحها"
            0 -> "انتهت الصفقة ($side)\nالنتيجة المقدّرة: ✘ خسارة (فرق السعر ${fmt(diff / atr)}×ATR)\nلن تُسجَّل قبل ضغطك: «تأكيد المقدّر» أو صحّحها"
            else -> "انتهت الصفقة ($side)\n⚠ تعذّر التحقق تلقائياً: $note\nسجّل النتيجة الصحيحة بنفسك، أو «تجاهل»"
        }
        ui(msg, col, 2)
        main.removeCallbacks(confirmRunnable)
        main.postDelayed(confirmRunnable, 60000)
        // التداول التلقائي التجريبي: نسجّل فقط النتيجة المؤكدة بقراءتين، وإلا نتجاهل الصفقة
        if (t.auto) { if (est != -1) confirm(null) else discard() }
    }

    /**
     * side: اتجاه الصفقة (1 شراء، -1 بيع).
     * لا تُسجَّل الصفقة إلا إذا انخفض الرصيد فعلاً (أي دخلت المنصة). عند الضغط اليدوي نبحث أيضاً عن انخفاض خلال آخر 25 ثانية.
     */
    private fun enter(side: Int, auto: Boolean = false) {
        synchronized(lock) {
            if (state != 0) return
            if (lastFormingClose.isNaN()) { toast("انتظر قراءة السعر"); return }
            val x = rawSig?.x ?: DoubleArray(Learner.N)
            val nowMs = System.currentTimeMillis()
            val ep = priceAt(nowMs, 1500).let { if (it.isNaN()) lastFormingClose else it }
            val fromStart = candleStartMs > 0 && (nowMs - candleStartMs) <= 20000
            val t = Trade(side, x, ep, nowMs + platformDurSec() * 1000L, rawKey, buffer.total, fromStart, auto)
            t.created = nowMs - (if (auto) 0L else 25000L)
            t.entryStarted = nowMs
            trade = t
            val balNow = ScreenOcr.stable(nowMs)
            if (balNow.isNaN()) {
                if (auto) { trade = null; toast("تعذّرت قراءة الرصيد: لن أنفّذ"); return }
                // بدون قراءة للرصيد: نعمل كما قبل، والنتيجة تُقدَّر من السعر وتحتاج تأكيدك
                state = 1
            tradeAnalysisLine = "تحليل أثناء الصفقة: بانتظار أول شمعة مغلقة"
                t.created = nowMs
                main.removeCallbacks(endRunnable)
                main.postDelayed(endRunnable, platformDurSec() * 1000L + 2500)
                ui("صفقة جارية (بدون تحقق من الرصيد: تعذّرت قراءته)\nمتابعة التحليل مفعّلة — لا تغيّر الصفقة المفتوحة\\n$tradeAnalysisLine", Color.rgb(30, 90, 180), 1)
                return
            }
            state = 3
            entryTick(nowMs)
        }
    }

    /** تحليل فوري على السجل الحالي بدون انتظار بداية الشمعة */
    private fun analyzeNow() {
        synchronized(lock) {
            if (state != 0) return
            if (buffer.list.size < 30) { toast("السجل ${buffer.list.size}/30 شمعة فقط"); return }
            rawSig = null
            analyzeTick(System.currentTimeMillis(), false, tfSec, curConf, curSens)
        }
    }

    private fun cancelTrade() {
        synchronized(lock) {
            if (state != 1 && state != 3) return
            main.removeCallbacks(endRunnable)
            trade = null; state = 0; rawSig = null
            ui("أُلغيت الصفقة (لم تُسجَّل)\nبانتظار الشمعة القادمة", Color.DKGRAY, 0)
        }
    }

    private fun manualResult(win: Boolean) {
        synchronized(lock) {
            if (state != 1) return
            main.removeCallbacks(endRunnable)
            state = 2
        }
        confirm(win)
    }

    /** win = null يعني اعتماد النتيجة المقدّرة (فقط إن كانت مؤكدة)، ولا شيء يُسجَّل قبل ضغطك */
    private fun confirm(win: Boolean?) {
        synchronized(lock) {
            if (state != 2) return
            val w: Boolean? = win ?: (if (resultEst == 1) true else if (resultEst == 0) false else null)
            if (w == null) { toast("لا توجد نتيجة مؤكدة تلقائياً: اختر ربحت أو خسرت، أو تجاهل"); return }
            main.removeCallbacks(confirmRunnable)
            val t = trade
            if (t != null) {
                Learner.stat(this, w, t.key)
                // الخسارة تُعلَّم بقوة أكبر حتى لا تتكرر الظروف نفسها
                Learner.learn(this, t.key, t.x, t.side, w, if (w) 0.02 else 0.04)
                if (w) {
                    lossStreak[t.key] = 0
                } else {
                    val n = (lossStreak[t.key] ?: 0) + 1
                    lossStreak[t.key] = n
                    if (n >= 2) { cooldownByKey[t.key] = 5; lossStreak[t.key] = 0 }
                }
                if (t.auto) { if (w) autoLossRun = 0 else autoLossRun++ }
                saveTradeJournal(t, w, if (verifiedByBalance) "BALANCE_AUTO" else "USER_CONFIRMED_OR_CORRECTED")
                resultBySymbol[activeSymbol] = "آخر صفقة لهذا الزوج: " + (if (w) "✔ ربح" else "✘ خسارة") + (if (verifiedByBalance) " (مؤكدة من الرصيد)" else " (بتأكيدك)")
                toast(if (w) "سُجّل الربح وتعلّم النظام" else "سُجّلت الخسارة وتعلّم النظام بقوة أكبر")
            }
            trade = null; state = 0; rawSig = null
            ui("بانتظار الشمعة القادمة...", Color.DKGRAY, 0)
        }
    }

    /** تجاهل الصفقة دون تسجيل أو تعلّم */
    private fun discard() {
        synchronized(lock) {
            if (state != 2) return
            main.removeCallbacks(confirmRunnable)
            trade = null; state = 0; rawSig = null
            toast("لم تُسجَّل النتيجة")
            ui("بانتظار الشمعة القادمة...", Color.DKGRAY, 0)
        }
    }

    private fun toast(m: String) {
        main.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    private fun ui(text: String, color: Int, st: Int) {
        main.post {
            fullText = buildString {
                append(text)
                if (cloudStatus.isNotBlank()) append("\\n").append(cloudStatus)
                if (cloudAnalysisLine.isNotBlank()) append("\\nGemini: ").append(cloudAnalysisLine.take(260))
            }
            render()
            tv?.setBackgroundColor(color)
            rowA?.visibility = if (st == 0 && expanded) View.VISIBLE else View.GONE
            rowB?.visibility = if (st == 1) View.VISIBLE else View.GONE
            rowC?.visibility = if (st == 2) View.VISIBLE else View.GONE
            root?.post { updateOv() }
        }
    }

    /** نافذة مختصرة (3 أسطر) حتى لا تغطي الشارت؛ اضغط على النص لعرض التفاصيل */
    private fun render() {
        val lines = fullText.split("\n")
        tv?.text = if (expanded || lines.size <= 3) fullText
        else lines.take(2).joinToString("\n") + "\n⋯ اضغط لفتح التفاصيل والأزرار"
    }

    private fun updateOv() {
        val b = root ?: return
        val loc = IntArray(2)
        try { b.getLocationOnScreen(loc) } catch (_: Exception) { return }
        ovY = loc[1]; ovW = b.width; ovH = b.height
    }

    private fun showOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(235, 25, 25, 25))
            setPadding(4, 4, 4, 4)
            minimumWidth = (screenW * 0.58).toInt()
        }
        val label = TextView(this).apply {
            text = "جاري التحليل... (اسحب هنا لتحريك النافذة؛ بعد دخولك الصفقة اضغط شراء أو بيع)"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.DKGRAY)
            textSize = 11f
            maxLines = 3
            setPadding(10, 7, 10, 7)
        }
        box.addView(label)

        fun newRow(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(row: LinearLayout, t: String, bg: Int, f: () -> Unit) {
            val b = TextView(this).apply {
                text = t
                setTextColor(Color.WHITE)
                setBackgroundColor(bg)
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(4, 8, 4, 8)
                setOnClickListener { f() }
            }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(4, 8, 4, 0)
            row.addView(b, lp)
        }
        val a = newRow(); val bb = newRow(); val cc = newRow()
        btn(a, "دخلت\nشراء ▲", Signal.OV_GREEN) { enter(1) }
        btn(a, "دخلت\nبيع ▼", Signal.OV_RED) { enter(-1) }
        btn(a, "حلّل\nالآن", Color.rgb(30, 90, 180)) { analyzeNow() }
        btn(a, "إيقاف", Color.GRAY) { stopSelf() }
        btn(bb, "✔ ربحت", Signal.OV_GREEN) { manualResult(true) }
        btn(bb, "✘ خسرت", Signal.OV_RED) { manualResult(false) }
        btn(bb, "إلغاء", Color.rgb(130, 90, 20)) { cancelTrade() }
        btn(bb, "إيقاف", Color.GRAY) { stopSelf() }
        btn(cc, "✔\nربحت", Signal.OV_GREEN) { confirm(true) }
        btn(cc, "✘\nخسرت", Signal.OV_RED) { confirm(false) }
        btn(cc, "تأكيد\nالمقدّر", Color.rgb(30, 90, 180)) { confirm(null) }
        btn(cc, "تجاهل", Color.GRAY) { discard() }
        box.addView(a); box.addView(bb); box.addView(cc)
        a.visibility = View.GONE
        bb.visibility = View.GONE
        cc.visibility = View.GONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (screenW * 0.07).toInt()
        lp.y = (screenH * 0.90).toInt()

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        label.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; startX = lp.x; startY = lp.y }
                MotionEvent.ACTION_UP -> {
                    if (abs(ev.rawX - downX) < 12f && abs(ev.rawY - downY) < 12f) {
                        expanded = !expanded
                        render()
                        rowA?.visibility = if (expanded) View.VISIBLE else View.GONE
                        box.post { updateOv() }
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (ev.rawX - downX).toInt()
                    lp.y = startY + (ev.rawY - downY).toInt()
                    try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                    box.post { updateOv() }
                }
            }
            true
        }
        wm.addView(box, lp)
        box.post { updateOv() }
        main.postDelayed(ticker, 1000)
        root = box; tv = label; rowA = a; rowB = bb; rowC = cc
    }

    override fun onDestroy() {
        alive = false
        cloudExecutor.shutdownNow()
        main.removeCallbacks(confirmRunnable)
        main.removeCallbacks(endRunnable)
        main.removeCallbacks(ticker)
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        worker?.quitSafely()
        root?.let {
            try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        root = null; tv = null; rowA = null; rowB = null; rowC = null
        try { bmp?.recycle() } catch (_: Exception) {}
        bmp = null
        @Suppress("DEPRECATION") stopForeground(true)
        super.onDestroy()
    }
}
