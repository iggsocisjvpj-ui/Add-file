package com.candle.assistant

/**
 * عنوان نشر Google Apps Script الذي يستقبل image_base64 وplatform ويرجع analysis.
 * يمكن تغييره من حقل عنوان الخادم داخل التطبيق.
 */
object CloudAiConfig {
    const val DEFAULT_ENDPOINT =
        "https://script.google.com/macros/s/AKfycbz5LD9togwHN1Vk00rxaMsVoY-h54g5NpcTC76WqADdq7G3N3YTHGWh-Jtju30PsFg3Rw/exec"
}
