package com.candle.assistant

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** شاشة سجل الصفقات: كل الأزواج أو زوج محدد، مع إحصاءات الساعة والتوقيت وحركة السعر. */
class JournalActivity : Activity() {
    private lateinit var body: TextView
    private lateinit var chips: LinearLayout
    private lateinit var actions: LinearLayout
    private var selected: String? = null
    private val reqExportFile = 7101
    private val reqImportFile = 7102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.rgb(11, 18, 32))
        root.setPadding(dp(12), dp(28), dp(12), dp(8))

        val title = TextView(this)
        title.text = "📒 سجل الصفقات والتعلّم"
        title.textSize = 20f
        title.setTextColor(Color.WHITE)
        root.addView(title)

        actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        fun act(t: String, f: () -> Unit) {
            val b = Button(this)
            b.text = t; b.isAllCaps = false; b.textSize = 12f; b.setTextColor(Color.WHITE)
            val g = GradientDrawable(); g.setColor(Color.rgb(60, 80, 120)); g.cornerRadius = 12f * d
            b.background = g
            b.setOnClickListener { f() }
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f); lp.setMargins(0, dp(6), dp(4), dp(2))
            actions.addView(b, lp)
        }
        act("📋 نسخ") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("trades", TradeJournal.exportCsv(this)))
            Toast.makeText(this, "نُسخ السجل. الصقه في ملاحظاتك للحفظ", Toast.LENGTH_LONG).show()
        }
        act("📤 مشاركة") {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, TradeJournal.exportCsv(this))
            startActivity(Intent.createChooser(i, "مشاركة السجل"))
        }
        act("📥 لصق") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val txt = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            val n = TradeJournal.importCsv(this, txt)
            Toast.makeText(this, if (n > 0) "أُضيفت $n صفقة" else "لا صفقات جديدة في الحافظة", Toast.LENGTH_LONG).show()
            refresh()
        }
        act("💾 نسخة احتياطية") {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "candle_quant_trades_backup.json")
            }
            startActivityForResult(i, reqExportFile)
        }
        act("📂 استيراد نسخة") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            }
            startActivityForResult(i, reqImportFile)
        }
        root.addView(actions, LinearLayout.LayoutParams(-1, -2))

        val hs = HorizontalScrollView(this)
        chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        hs.addView(chips)
        root.addView(hs, LinearLayout.LayoutParams(-1, -2))

        body = TextView(this)
        body.textSize = 13f
        body.setTextColor(Color.rgb(225, 233, 245))
        body.setTextIsSelectable(true)
        body.setPadding(0, dp(10), 0, dp(20))
        val sv = ScrollView(this)
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        selected = intent?.getStringExtra("symbol")?.takeIf { it.isNotBlank() && it != "غير معروف" }
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            when (requestCode) {
                reqExportFile -> {
                    contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                        it.write(TradeJournal.exportBackupJson(this))
                    } ?: throw IllegalStateException("تعذر فتح ملف الحفظ")
                    Toast.makeText(this, "تم حفظ نسخة احتياطية من سجل الصفقات", Toast.LENGTH_LONG).show()
                }
                reqImportFile -> {
                    val csv = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalStateException("تعذر قراءة الملف")
                    val n = if (csv.trimStart().startsWith("{")) TradeJournal.importBackupJson(this, csv)
                        else TradeJournal.importCsv(this, csv)
                    Toast.makeText(this, "تم استيراد $n صفقة جديدة دون تكرار", Toast.LENGTH_LONG).show()
                    refresh()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر إكمال العملية: ${e.message ?: "خطأ في الملف"}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        TradeJournal.invalidate()
        refresh()
    }

    private fun chip(text: String, active: Boolean, action: () -> Unit) {
        val d = resources.displayMetrics.density
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 12f
        b.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.setColor(if (active) Color.rgb(34, 91, 160) else Color.rgb(25, 35, 54))
        g.cornerRadius = 14f * d
        b.background = g
        b.setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-2, (40 * d).toInt())
        lp.setMargins(0, (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
        chips.addView(b, lp)
    }

    private fun refresh() {
        chips.removeAllViews()
        val pairs = TradeJournal.pairs(this)
        if (selected != null && selected !in pairs) selected = null
        chip("الكل", selected == null) { selected = null; refresh() }
        for (p in pairs) chip(p, selected == p) { selected = p; refresh() }
        body.text = TradeJournal.report(this, selected)
        body.visibility = View.VISIBLE
    }
}
