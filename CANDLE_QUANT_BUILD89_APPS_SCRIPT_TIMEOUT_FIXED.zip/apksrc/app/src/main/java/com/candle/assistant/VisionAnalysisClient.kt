package com.candle.assistant

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

sealed class VisionAnalysisResult {
    data class Success(val analysis: String, val direction: String, val model: String) : VisionAnalysisResult()
    data class Failure(val message: String) : VisionAnalysisResult()
}

/** Sends only the chart image to the user's Google Apps Script Web App. */
private const val DEFAULT_READ_TIMEOUT_MS = 390_000 // 6m 30s: accommodates Apps Script runs near its 6-minute limit.
class VisionAnalysisClient(
    private val endpoint: String,
    private val readTimeoutMs: Int = DEFAULT_READ_TIMEOUT_MS
) {
    fun analyzeChart(imageBytes: ByteArray, platform: String): VisionAnalysisResult {
        if (imageBytes.isEmpty()) return VisionAnalysisResult.Failure("الصورة فارغة")
        val url = try { URL(VisionAiConfig.normalizeEndpoint(endpoint)) }
            catch (_: Exception) { return VisionAnalysisResult.Failure("رابط Apps Script غير صحيح") }
        if (url.protocol != "https" || !url.host.endsWith("google.com"))
            return VisionAnalysisResult.Failure("استخدم رابط Web App المنشور من Google Apps Script عبر HTTPS")

        var connection: HttpURLConnection? = null
        return try {
            val dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(imageBytes, Base64.NO_WRAP)
            val payload = JSONObject()
                .put("platform", platform.take(80))
                .put("image_base64", dataUrl)
            val body = payload.toString().toByteArray(Charsets.UTF_8)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 30_000
                readTimeout = readTimeoutMs
                doOutput = true
                instanceFollowRedirects = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            connection.outputStream.use { it.write(body) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(text) } catch (_: Exception) { null }
            if (code !in 200..299) return VisionAnalysisResult.Failure("Apps Script HTTP $code: ${text.take(180)}")
            if (json == null) return VisionAnalysisResult.Failure("Apps Script لم يُرجع JSON صالحًا: ${text.take(120)}")
            val analysis = json.optString("analysis").trim()
            if (json.optBoolean("ok", true).not()) return VisionAnalysisResult.Failure(json.optString("error", "فشل تحليل الصورة"))
            if (analysis.isBlank()) return VisionAnalysisResult.Failure(json.optString("error").ifBlank { "الرد لا يحتوي على analysis" })
            val rawDirection = json.optString("direction").ifBlank { analysis }
            val direction = parseDirection(rawDirection)
            VisionAnalysisResult.Success(analysis, direction, json.optString("model", "Gemini via Apps Script"))
        } catch (_: java.net.SocketTimeoutException) {
            VisionAnalysisResult.Failure("انتهت مهلة الاتصال بعد 6 دقائق تقريباً. تحقق من سجل تنفيذ Apps Script؛ قد يكون Gemini ما زال يعالج الصورة.")
        } catch (_: java.net.UnknownHostException) {
            VisionAnalysisResult.Failure("تعذر الوصول إلى Google Apps Script؛ تحقق من الإنترنت")
        } catch (e: Exception) {
            VisionAnalysisResult.Failure("فشل اتصال Apps Script: ${e.javaClass.simpleName}: ${(e.message ?: "").take(100)}")
        } finally { connection?.disconnect() }
    }

    private fun parseDirection(value: String): String {
        val s = value.lowercase(Locale.ROOT)
        val buy = Regex("(^|[^a-z])buy([^a-z]|$)|شراء|صاعد|صعود|bullish").containsMatchIn(s)
        val sell = Regex("(^|[^a-z])sell([^a-z]|$)|بيع|هابط|هبوط|bearish").containsMatchIn(s)
        return when { buy && !sell -> "BUY"; sell && !buy -> "SELL"; else -> "WAIT" }
    }
}
