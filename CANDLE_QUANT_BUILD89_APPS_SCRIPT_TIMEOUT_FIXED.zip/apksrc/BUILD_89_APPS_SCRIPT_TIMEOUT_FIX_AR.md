# CANDLE QUANT — Build 89: Apps Script timeout alignment

## What was changed
- Unified all Android calls to Google Apps Script on `VisionAnalysisClient`'s default read timeout: 390,000 ms (6 minutes 30 seconds).
- Removed the separate 60-second timeout from the CaptureService request path.
- The manual Gemini test also uses the same shared default, avoiding inconsistent settings.
- Preserved the existing Build 89 Gradle signing adjustment from the previous package.

## Why
The provided Apps Script execution screenshot shows a completed `doPost` taking 358.641 seconds. The old CaptureService path used a 60-second client read timeout, so Android could stop waiting while the Apps Script execution continued.

## Important limit
This changes how long Android waits; it does not make Apps Script run faster or extend Google's server-side execution limit. Google documents a six-minute maximum runtime per Apps Script execution. An execution taking almost six minutes is fragile and should be optimized in the Apps Script code itself. The Apps Script source (`Code.gs`) was not included in the Android project ZIP, so this package does not optimize server-side Gemini calls.

## Scope
No trading rules, local quantitative analysis, signal generation, or manual BUY/SELL behavior were changed.
