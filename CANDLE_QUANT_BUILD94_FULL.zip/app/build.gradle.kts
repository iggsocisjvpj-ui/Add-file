plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.candle.assistant"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.candle.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 91
        versionName = "3.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.0")
}
