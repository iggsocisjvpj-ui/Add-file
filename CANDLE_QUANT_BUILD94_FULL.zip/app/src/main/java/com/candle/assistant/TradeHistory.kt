package com.candle.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

/**
 * سجل الصفقات الموحّد + تحليل أفضل الأوقات (حسب اليوم والساعة).
 * يحفظ لكل صفقة: الزوج، الفاصل، الاتجاه، سعر الدخول، سعر الإغلاق، النتيجة، والوقت.
 * يعرض فقط الأوقات التي فيها عينات كافية، حتى لا تُختار ساعة بناءً على صفقتين.
 */
object TradeHistory {
    private const val PREF = "trade_history"
    private const val MAX_RECORDS = 5000
    val DAY_NAMES = arrayOf("", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")

    data class Rec(
        val t: Long, val pair: String, val tfSec: Int, val side: Int,
        val entry: Double, val exit: Double?, val win: Boolean
    )

    /** إحصائية خانة واحدة: يوم + ساعة */
    data class Slot(val day: Int, val hour: Int, val n: Int, val wins: Int) {
        val winRate: Double get() = if (n == 0) 0.0 else wins.toDouble() / n
        fun label(): String = "${DAY_NAMES[day]} ${hour.toString().padStart(2, '0')}:00"
    }

    fun add(c: Context, r: Rec) {
        val arr = load(c)
        arr.put(JSONObject()
            .put("t", r.t).put("pair", r.pair).put("tf", r.tfSec).put("side", r.side)
            .put("entry", r.entry).put("exit", r.exit ?: JSONObject.NULL).put("win", r.win))
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - MAX_RECORDS) until arr.length()) trimmed.put(arr.get(i))
        prefs(c).edit().putString("records", trimmed.toString()).apply()
    }

    fun all(c: Context, tz: TimeZone = TimeZone.getDefault()): List<Rec> {
        val arr = load(c)
        val out = ArrayList<Rec>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Rec(
                t = o.optLong("t"),
                pair = o.optString("pair"),
                tfSec = o.optInt("tf"),
                side = o.optInt("side"),
                entry = o.optDouble("entry", Double.NaN),
                exit = if (o.isNull("exit")) null else o.optDouble("exit", Double.NaN),
                win = o.optBoolean("win")
            ))
        }
        return out
    }

    /** إحصائيات يوم/ساعة مع فلتر اختياري للزوج والفاصل */
    fun slots(
        c: Context, pair: String? = null, tfSec: Int? = null,
        tz: TimeZone = TimeZone.getDefault()
    ): List<Slot> {
        val map = HashMap<Pair<Int, Int>, IntArray>()   // (day,hour) -> [n, wins]
        val cal = Calendar.getInstance(tz)
        for (r in all(c)) {
            if (pair != null && r.pair != pair) continue
            if (tfSec != null && r.tfSec != tfSec) continue
            cal.timeInMillis = r.t
            val key = cal.get(Calendar.DAY_OF_WEEK) to cal.get(Calendar.HOUR_OF_DAY)
            val a = map.getOrPut(key) { IntArray(2) }
            a[0]++
            if (r.win) a[1]++
        }
        return map.map { (k, a) -> Slot(k.first, k.second, a[0], a[1]) }
    }

    /** أفضل الأوقات: فقط الخانات التي فيها عدد صفقات لا يقل عن minTrades */
    fun bestSlots(
        c: Context, minTrades: Int = 20, top: Int = 5,
        pair: String? = null, tfSec: Int? = null
    ): List<Slot> =
        slots(c, pair, tfSec)
            .filter { it.n >= minTrades }
            .sortedWith(compareByDescending<Slot> { it.winRate }.thenByDescending { it.n })
            .take(top)

    /** محرك البحث: يعيد ملخصاً نصياً لليوم والساعة المطلوبة (أو لليوم كاملاً) */
    fun search(
        c: Context, day: Int? = null, hour: Int? = null,
        pair: String? = null, tfSec: Int? = null, minTrades: Int = 1
    ): String {
        val list = slots(c, pair, tfSec).filter {
            (day == null || it.day == day) && (hour == null || it.hour == hour) && it.n >= minTrades
        }
        if (list.isEmpty()) return "لا توجد صفقات مطابقة لهذا البحث بعد."
        val n = list.sumOf { it.n }
        val w = list.sumOf { it.wins }
        val head = "المطابق: $n صفقة، ربح $w، نسبة ${"%.1f".format(100.0 * w / n)}%"
        val rows = list.sortedWith(compareBy<Slot> { it.day }.thenBy { it.hour })
            .joinToString("\n") { "${it.label()}: ${it.n} صفقة، ${"%.0f".format(100 * it.winRate)}%" }
        return "$head\n$rows"
    }

    fun reset(c: Context) { prefs(c).edit().clear().apply() }

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun load(c: Context): JSONArray =
        try { JSONArray(prefs(c).getString("records", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
}
