package com.candle.assistant

import android.Manifest
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.ImageView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqCapture = 1001
    private val reqChartImage = 1002
    private var selectedChartBitmap: Bitmap? = null
    private lateinit var aiResult: TextView
    private lateinit var imagePreview: ImageView
    private lateinit var backendField: EditText
    private lateinit var platformField: EditText
    private lateinit var stats: TextView
    private lateinit var advancedDashboard: LinearLayout
    private lateinit var autoStat: TextView
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        val lv = getSharedPreferences("learn", Context.MODE_PRIVATE)
        if (lv.getInt("ver", 0) != Learner.VER) lv.edit().clear().putInt("ver", Learner.VER).apply()
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        // Safety baseline: automatic trading remains disabled until platform/account verification is redesigned.
        p.edit().putInt("auto", 0).apply()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.rgb(10, 15, 28))
        }
        fun rounded(color: Int, radius: Float = 18f): GradientDrawable = GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }
        fun label(t: String, size: Float = 15f) {
            root.addView(TextView(this).apply {
                text = t; textSize = size; setTextColor(Color.rgb(222, 231, 245))
                setPadding(0, 20, 0, 7)
                if (size >= 21f) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            })
        }
        fun field(key: String, title: String, def: Int) {
            label(title, 14f)
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(p.getInt(key, def).toString())
                setTextColor(Color.WHITE); setHintTextColor(Color.rgb(135, 149, 171))
                setPadding(16, 10, 16, 10); background = rounded(Color.rgb(25, 35, 54), 14f)
            }
            fields[key] = e
            root.addView(e, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 })
        }
        fun button(t: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = t; isAllCaps = false; textSize = 14f
                setTextColor(Color.WHITE); background = rounded(Color.rgb(34, 91, 160), 16f)
                setPadding(12, 8, 12, 8); setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 7; bottomMargin = 5 })
        }

        label("CANDLE AI  |  محلل الشموع الذكي", 23f)
        label("اعرض الشارت على أي منصة تداول باستخدام الشموع اليابانية. يُفضّل إظهار 30 شمعة واضحة على الأقل؛ يبني التطبيق سجلاً متحركاً أطول تدريجياً مع تحرك الشارت. حدّد بداية الشارت ونهايته بحيث لا تدخل أزرار المنصة ضمن منطقة القراءة. مدة الصفقة المقترحة تساوي مدة الشمعة.")
        /* chart setup */
        label("إعدادات قراءة الشارت", 18f)
        field("top", "بداية الشارت من أعلى الشاشة %", 12)
        field("bottom", "نهاية الشارت من أعلى الشاشة %", 60)
        field("tf", "مدة الشمعة بالثواني (60 = دقيقة)", 60)
        field("conf", "الحد الأدنى للثقة % (50 إلى 95)", 58)
        field("sens", "الحساسية (1 صارم وبطيء، 5 حساس وسريع)", 3)
        field("dur", "مدة الصفقة في المنصة بالثواني (اجعلها مثل مدة الشمعة)", 60)
        field("payout", "عائد المنصة % (يظهر بجانب زر الشراء)", 85)
        label("التداول التلقائي: متوقف مؤقتًا للحماية", 18f)
        label("التحليل والإشارات يعملان، لكن النقر التلقائي معطّل مؤقتًا. التحقق من Demo عبر نص الشاشة وحده لا يضمن أن الحساب تجريبي، كما تختلف واجهات المنصات. سنعيد تقييم هذه الوظيفة بعد بناء تحقق خاص بكل منصة واختباره بأمان.", 13f)
        button("📒 سجل الصفقات والتعلّم لكل زوج") { startActivity(Intent(this, JournalActivity::class.java)) }
        button("1) فتح إعدادات إمكانية الوصول لتفعيل الخدمة") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2) ضبط موضع زري الشراء والبيع") {
            val svc = TapService.instance
            if (svc != null) svc.calibrate()
            else Toast.makeText(this, "فعّل خدمة «محلل الشموع - نقر تجريبي» أولاً", Toast.LENGTH_LONG).show()
        }
        button("3) التداول التلقائي (متوقف للحماية)") {
            getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putInt("auto", 0).apply()
            Toast.makeText(this, "التداول التلقائي متوقف في هذه النسخة؛ التحليل اليدوي ما زال يعمل", Toast.LENGTH_LONG).show()
            refreshStats()
        }
        autoStat = TextView(this).apply { textSize = 14f; setTextColor(Color.rgb(255, 205, 105)); setPadding(14, 14, 14, 14); background = rounded(Color.rgb(47, 39, 27), 14f); text = "التداول التلقائي متوقف للحماية" }
        root.addView(autoStat)
        button("ابدأ التحليل") { start() }
        button("إيقاف التحليل") {
            stopService(Intent(this, CaptureService::class.java))
            Toast.makeText(this, "تم الإيقاف", Toast.LENGTH_SHORT).show()
        }
        button("تصفير الإحصاءات والتعلم") {
            Learner.reset(this)
            getSharedPreferences("stats", Context.MODE_PRIVATE).edit().clear().apply()
            refreshStats()
        }
        stats = TextView(this).apply { textSize = 16f; setTextColor(Color.rgb(222, 231, 245)); setPadding(14, 18, 14, 18); background = rounded(Color.rgb(20, 30, 47), 16f) }
        root.addView(stats)

        // واجهة الذكاء الاصطناعي الهجين: تحليل صورة محلي، واتصال سحابي اختياري عبر خادم HTTPS.
        label("مساعد الذكاء الاصطناعي الهجين", 22f)
        label("اختر صورة شارت من أي منصة. سيحاول المحلل المحلي قراءة الشموع الملونة من الصورة. التحليل السحابي اختياري ويتطلب خادم HTTPS خاصًا بك؛ لا تضع مفاتيح API هنا.", 13f)

        platformField = EditText(this).apply {
            hint = "اسم المنصة (مثل TradingView أو Binance)"
            setSingleLine(true)
            setText("غير محددة")
            setTextColor(Color.WHITE); setHintTextColor(Color.rgb(135, 149, 171))
            setPadding(16, 10, 16, 10); background = rounded(Color.rgb(25, 35, 54), 14f)
        }
        root.addView(platformField)

        imagePreview = ImageView(this).apply {
            adjustViewBounds = true
            maxHeight = 420
            visibility = View.GONE
            contentDescription = "معاينة صورة الشارت المختارة"
            setBackgroundColor(Color.rgb(20, 30, 47)); setPadding(8, 8, 8, 8)
        }
        root.addView(imagePreview)

        button("اختيار صورة الشارت من الهاتف") {
            val pick = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(Intent.createChooser(pick, "اختر صورة الشارت"), reqChartImage)
        }

        button("تحليل الصورة محليًا دون إنترنت") {
            val bmp = selectedChartBitmap
            if (bmp == null) {
                Toast.makeText(this, "اختر صورة الشارت أولاً", Toast.LENGTH_SHORT).show()
            } else {
                runLocalImageAnalysis(bmp)
            }
        }

        label("عنوان خادم الذكاء الاصطناعي HTTPS (اختياري)", 14f)
        backendField = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
            hint = "https://your-server.example/v1/chart/analyze"
            setText(getSharedPreferences("cfg", Context.MODE_PRIVATE)
                .getString("ai_backend", CloudAiConfig.DEFAULT_ENDPOINT) ?: CloudAiConfig.DEFAULT_ENDPOINT)
            setTextColor(Color.WHITE); setHintTextColor(Color.rgb(135, 149, 171))
            setPadding(16, 10, 16, 10); background = rounded(Color.rgb(25, 35, 54), 14f)
        }
        root.addView(backendField)

        button("إرسال الصورة للتحليل السحابي") {
            val bmp = selectedChartBitmap
            val endpoint = backendField.text.toString().trim()
            val platform = platformField.text.toString().trim().ifBlank { "غير محددة" }
            if (bmp == null) {
                Toast.makeText(this, "اختر صورة الشارت أولاً", Toast.LENGTH_SHORT).show()
            } else if (endpoint.isBlank()) {
                Toast.makeText(this, "الخدمة السحابية غير مهيأة. نحتاج نشر خادم HTTPS أولاً.", Toast.LENGTH_LONG).show()
            } else {
                getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("ai_backend", endpoint).apply()
                runCloudImageAnalysis(bmp, endpoint, platform)
            }
        }

        aiResult = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(222, 231, 245))
            setPadding(16, 18, 16, 18)
            background = rounded(Color.rgb(20, 30, 47), 16f)
            text = "نتائج الذكاء الاصطناعي ستظهر هنا."
        }
        root.addView(aiResult)

        label("لوحة التحليل المتقدم", 21f)
        label("تُحدّث اللوحة بعد تحليل صورة الشارت. Footprint هنا تقديري من OHLC؛ لا يمثل حجم تداول حقيقيًا.", 12f)
        advancedDashboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            background = rounded(Color.rgb(18, 27, 43), 18f)
        }
        root.addView(advancedDashboard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8; bottomMargin = 12 })
        renderDashboardPlaceholder()

        label("طريقة العمل: الحالات 🟢 شراء، 🔴 بيع، 🟡 انتظار (المؤشرات متعارضة)، ⚪ لا تدخل (بيانات غير كافية أو غير موثوقة). تظهر الإشارة في أول ثوانٍ من الشمعة الجديدة مع وقت الدخول والمدة وأسبابها. نفّذ الصفقة في المنصة بمدة شمعة، ثم اضغط في النافذة العائمة «دخلت شراء» أو «دخلت بيع» حسب ما نفّذت. يتوقف التحليل حتى تنتهي الصفقة، ثم يقدّر التطبيق الربح أو الخسارة ويعرضها لتؤكدها أو تصححها، ويتعلم منها تلقائياً. ضع النافذة بعيداً عن الشارت (الافتراضي أسفل الشاشة).", 13f)
        label("تنبيه: الثقة المعروضة درجة تقديرية من النموذج وليست احتمالاً مضموناً. لا يوجد نظام يضمن نسبة ربح، والقرار والنقر بيدك. " +
            "جرّب بالحساب التجريبي وراقب النسبة الفعلية لـ 50 صفقة على الأقل قبل أي مال حقيقي.", 13f)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStats()
    }

    private fun toggleAuto() {
        val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (cfg.getInt("auto", 0) == 1) {
            cfg.edit().putInt("auto", 0).apply()
            Toast.makeText(this, "أُوقف التداول التلقائي", Toast.LENGTH_SHORT).show()
            refreshStats()
            return
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("تأكيد: حساب تجريبي فقط")
            .setMessage("سينقر التطبيق على زري الشراء والبيع تلقائياً. فعّله فقط وأنت على الحساب التجريبي، وسيرفض العمل إن لم تظهر كلمة Demo على الشاشة. هل أنت الآن على حساب تجريبي؟")
            .setPositiveButton("نعم، حساب تجريبي") { _, _ ->
                cfg.edit().putInt("auto", 1).apply()
                refreshStats()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun start() {
        val ed = getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
        for ((k, e) in fields) ed.putInt(k, e.text.toString().toIntOrNull() ?: 0)
        ed.apply()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» ثم ارجع واضغط ابدأ", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        } else if (requestCode == reqChartImage && resultCode == RESULT_OK && data?.data != null) {
            try {
                val uri = data.data!!
                val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bitmap == null) {
                    Toast.makeText(this, "تعذر قراءة الصورة", Toast.LENGTH_SHORT).show()
                } else {
                    selectedChartBitmap?.recycle()
                    selectedChartBitmap = bitmap
                    imagePreview.setImageBitmap(bitmap)
                    imagePreview.visibility = View.VISIBLE
                    aiResult.text = "تم اختيار الصورة. اضغط تحليل الصورة محليًا."
                }
            } catch (_: Exception) {
                Toast.makeText(this, "حدث خطأ أثناء فتح الصورة", Toast.LENGTH_LONG).show()
            }
        }
    }


    private fun runLocalImageAnalysis(source: Bitmap) {
        aiResult.text = "جارٍ تحليل الصورة محليًا..."
        Thread {
            var candles: List<Candle> = emptyList()
            val resultText = try {
                val maxSide = 1800
                val scale = minOf(1.0, maxSide.toDouble() / maxOf(source.width, source.height))
                val bitmap = if (scale < 1.0) Bitmap.createScaledBitmap(
                    source, (source.width * scale).toInt().coerceAtLeast(1),
                    (source.height * scale).toInt().coerceAtLeast(1), true
                ) else source
                val pixels = IntArray(bitmap.width * bitmap.height)
                bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
                candles = CandleReader.read(pixels, bitmap.width, bitmap.height)
                if (bitmap !== source) bitmap.recycle()
                if (candles.size < 30) {
                    "لم يستطع المحلل المحلي استخراج 30 شمعة موثوقة. الشموع المكتشفة: ${candles.size}.\nجرّب صورة أوضح، مع إظهار الشموع فقط وإخفاء القوائم قدر الإمكان."
                } else {
                    val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
                    val output = LocalAiEngine.analyze(
                        this, candles, cfg.getInt("tf", 60),
                        cfg.getInt("conf", 58), cfg.getInt("sens", 3)
                    )
                    val analysis = LocalAiEngine.toAiAnalysis(output)
                    "التحليل المحلي للصورة\nالاتجاه: ${analysis.direction}\nدرجة توافق المؤشرات: ${analysis.confidence}%\nعدد الشموع المستخرجة: ${candles.size}\n\nالتفسير:\n${analysis.explanation}${AdvancedMarketAnalysis.summary(candles)}\n\nالمصدر: ${analysis.source}\nملاحظة: النسبة درجة توافق فني وليست احتمال ربح. وقد تتأثر قراءة الصورة بألوان المنصة أو المؤشرات فوق الشارت."
                }
            } catch (e: Exception) {
                "تعذر تحليل الصورة محليًا: ${e.message ?: "خطأ غير معروف"}"
            }
            runOnUiThread {
                aiResult.text = resultText
                if (candles.size >= 30) renderAdvancedDashboard(candles)
            }
        }.start()
    }

    private fun renderDashboardPlaceholder() {
        advancedDashboard.removeAllViews()
        val t = TextView(this).apply {
            text = "بانتظار تحليل صورة الشارت\nاختر صورة واضحة تحتوي على 30 شمعة على الأقل ثم ابدأ التحليل المحلي."
            textSize = 14f
            setTextColor(Color.rgb(190, 204, 224))
            setPadding(12, 16, 12, 16)
        }
        advancedDashboard.addView(t)
    }

    private fun renderAdvancedDashboard(candles: List<Candle>) {
        advancedDashboard.removeAllViews()
        val fractals = AdvancedMarketAnalysis.fractals(candles)
        val trend = AdvancedMarketAnalysis.supertrend(candles).lastOrNull()
        val lastHigh = fractals.lastOrNull { it.isHigh }
        val lastLow = fractals.lastOrNull { !it.isHigh }
        val recent = candles.takeLast(30)
        val range = (recent.maxOfOrNull { it.high } ?: 0.0) - (recent.minOfOrNull { it.low } ?: 0.0)
        val tick = (range / 400.0).coerceAtLeast(0.01)
        val footprint = AdvancedMarketAnalysis.estimatedFromCandles(candles, tick, 80)
        val flow = AdvancedMarketAnalysis.analyzeFlow(footprint, trend?.direction ?: 0)
        val trendText = when (trend?.direction) { 1 -> "صاعد"; -1 -> "هابط"; else -> "غير متاح" }
        val trendColor = when (trend?.direction) { 1 -> Color.rgb(53, 190, 130); -1 -> Color.rgb(240, 95, 100); else -> Color.LTGRAY }

        fun addCard(title: String, body: String, accent: Int = Color.rgb(92, 160, 230)) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                background = GradientDrawable().apply {
                    setColor(Color.rgb(27, 39, 59)); cornerRadius = 16f
                    setStroke(2, accent)
                }
            }
            card.addView(TextView(this).apply {
                text = title; textSize = 15f; setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setTextColor(accent); setPadding(0, 0, 0, 6)
            })
            card.addView(TextView(this).apply {
                text = body; textSize = 14f; setTextColor(Color.rgb(225, 233, 245))
            })
            advancedDashboard.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
        }

        addCard("اتجاه Supertrend · ATR 10 / معامل 3", "$trendText\nقيمة الخط: ${trend?.value?.let { String.format(java.util.Locale.US, "%.4f", it) } ?: "—"}", trendColor)
        addCard("Fractal · خمس شموع", "آخر قمة مؤكدة: ${lastHigh?.price?.let { String.format(java.util.Locale.US, "%.4f", it) } ?: "—"}\nآخر قاع مؤكد: ${lastLow?.price?.let { String.format(java.util.Locale.US, "%.4f", it) } ?: "—"}")
        addCard("Volume Footprint · تقديري", "الشراء التقديري: ${String.format(java.util.Locale.US, "%.1f", footprint.totalBuy)}\nالبيع التقديري: ${String.format(java.util.Locale.US, "%.1f", footprint.totalSell)}\nDelta تقديري: ${String.format(java.util.Locale.US, "%.1f", footprint.delta)}\nPOC تقريبي: ${footprint.poc?.let { String.format(java.util.Locale.US, "%.4f", it) } ?: "—"}", Color.rgb(235, 180, 80))
        addCard("جدول الشموع الرقمي · آخر 10 شموع · تقديري", AdvancedMarketAnalysis.rowsText(candles, 10) + "\n\nالنشاط = مدى الشمعة ÷ المتوسط (ليس حجمًا فعليًا). الشراء/البيع تقدير من موقع الإغلاق. Δ = شراء − بيع، وΣΔ تراكمي.", Color.rgb(120, 200, 170))
        addCard("Footprint المرئي · شراء مقابل بيع", "الأشرطة الخضراء تمثل ضغط الشراء التقديري، والحمراء ضغط البيع التقديري. كل صف يمثل مستوى سعريًا، وΔ هو الفرق بينهما. الإطار الذهبي يحدد POC التقديري.", Color.rgb(135, 160, 210))
        advancedDashboard.addView(FootprintChartView(this, footprint.levels, footprint.poc), LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = (10 * resources.displayMetrics.density).toInt()
        })
        addCard(
            "محرك Order Flow الذكي · قراءة وصفية",
            "الميل: ${flow.dominantSide}\nقوة الميل النسبي: ${String.format(java.util.Locale.US, "%.1f", flow.pressurePercent)}%\nمستويات Buy Imbalance (3:1): ${flow.buyImbalances}\nمستويات Sell Imbalance (3:1): ${flow.sellImbalances}\n\n${flow.interpretation}\n\nمقارنة الاتجاه: ${flow.trendAgreement}\n\n${flow.limitations}",
            Color.rgb(110, 170, 220)
        )
        val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val technicalOutput = LocalAiEngine.analyze(
            this, candles, cfg.getInt("tf", 60),
            cfg.getInt("conf", 58), cfg.getInt("sens", 3)
        )
        val decision = DecisionEngine.evaluate(
            technicalOutput, trend?.direction ?: 0, flow,
            footprint.quality == AdvancedMarketAnalysis.DataQuality.ESTIMATED_FROM_OHLC
        )
        val decisionColor = when (decision.colorCode) {
            1 -> Color.rgb(53, 190, 130)
            -1 -> Color.rgb(240, 95, 100)
            else -> Color.rgb(235, 180, 80)
        }
        addCard(
            "القرار التحليلي الموحّد · CANDLE AI",
            "النتيجة: ${decision.title}\nدرجة التوافق: ${decision.confidence}%\nالحالة: ${decision.status}\n\nالأسباب:\n• " +
                decision.reasons.joinToString("\n• ") +
                "\n\nهذه قراءة تحليلية تعليمية وليست توصية مالية أو احتمال ربح. لا ينفذ التطبيق أي صفقة تلقائيًا.",
            decisionColor
        )
        addCard("جودة البيانات", "تقديري من شكل الشموع فقط — ليس حجم تداول حقيقيًا ولا بيانات Bid/Ask. لا نستنتج Absorption أو Exhaustion من هذه البيانات. البيانات الحقيقية ستظهر فقط بعد ربط مصدر صفقات موثوق.", Color.rgb(235, 180, 80))
    }

    private fun runCloudImageAnalysis(source: Bitmap, endpoint: String, platform: String) {
        aiResult.text = "جارٍ تجهيز الصورة وإرسالها إلى الخادم الآمن..."
        Thread {
            val result = try {
                val maxSide = 1280
                val scale = minOf(1.0, maxSide.toDouble() / maxOf(source.width, source.height))
                val bitmap = if (scale < 1.0) Bitmap.createScaledBitmap(
                    source, (source.width * scale).toInt().coerceAtLeast(1),
                    (source.height * scale).toInt().coerceAtLeast(1), true
                ) else source
                val stream = java.io.ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 78, stream)
                if (bitmap !== source) bitmap.recycle()
                when (val response = CloudAiClient(endpoint, null, 90_000).analyzeChart(stream.toByteArray(), platform)) {
                    is CloudAnalysisResult.Success -> "التحليل السحابي\n${response.analysis}\n\nالمصدر: الخادم السحابي. تحقق من البيانات والأسعار قبل اتخاذ أي قرار."
                    is CloudAnalysisResult.Failure -> "تعذر التحليل السحابي: ${response.message}\nيمكنك استخدام التحليل المحلي دون إنترنت."
                }
            } catch (e: Exception) {
                "تعذر تجهيز الصورة: ${e.message ?: "خطأ غير معروف"}"
            }
            runOnUiThread { aiResult.text = result }
        }.start()
    }

    override fun onDestroy() {
        selectedChartBitmap?.recycle()
        selectedChartBitmap = null
        super.onDestroy()
    }

    private fun refreshStats() {
        val cfg0 = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        autoStat.text = "التداول التلقائي: " + (if (cfg0.getInt("auto", 0) == 1) "🟢 مفعّل (تجريبي)" else "⚪ متوقف") +
            " | الخدمة: " + (if (TapService.instance != null) "تعمل" else "غير مفعّلة") +
            " | الأزرار: " + (if (cfg0.getInt("buyX", 0) > 0 && cfg0.getInt("sellX", 0) > 0) "مضبوطة" else "غير مضبوطة")
        val s = getSharedPreferences("stats", Context.MODE_PRIVATE)
        val w = s.getInt("w", 0)
        val l = s.getInt("l", 0)
        val n = w + l
        val rate = if (n == 0) 0 else w * 100 / n
        val ps = Learner.paperStats(this)
        stats.text = "صفقاتك المؤكدة: $n | ربح $w | خسارة $l | $rate%\n" +
            "الإشارات الافتراضية: ${ps.first} | النجاح ${(ps.second * 100).toInt()}%\n" +
            "عينات التعلم: ${Learner.samples(this)}" + (if (Learner.locked(this, 1.0 / (1.0 + getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("payout", 85) / 100.0))) "\n⛔ قفل الأمان مفعّل (نجاح الإشارات دون نقطة التعادل)" else "") +
            Learner.keyReport(this).let { if (it.isEmpty()) "" else "\nحسب الفاصل وحالة السوق (إشارات افتراضية):\n$it" }
    }
}
