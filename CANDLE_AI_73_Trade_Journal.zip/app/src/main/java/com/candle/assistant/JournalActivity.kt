package com.candle.assistant

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** شاشة سجل الصفقات: كل الأزواج أو زوج محدد، مع إحصاءات الساعة والتوقيت وحركة السعر. */
class JournalActivity : Activity() {
    private lateinit var body: TextView
    private lateinit var chips: LinearLayout
    private var selected: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.rgb(11, 18, 32))
        root.setPadding(dp(12), dp(28), dp(12), dp(8))

        val title = TextView(this)
        title.text = "📒 سجل الصفقات والتعلّم"
        title.textSize = 20f
        title.setTextColor(Color.WHITE)
        root.addView(title)

        val hs = HorizontalScrollView(this)
        chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        hs.addView(chips)
        root.addView(hs, LinearLayout.LayoutParams(-1, -2))

        body = TextView(this)
        body.textSize = 13f
        body.setTextColor(Color.rgb(225, 233, 245))
        body.setTextIsSelectable(true)
        body.setPadding(0, dp(10), 0, dp(20))
        val sv = ScrollView(this)
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        selected = intent?.getStringExtra("symbol")?.takeIf { it.isNotBlank() && it != "غير معروف" }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        TradeJournal.invalidate()
        refresh()
    }

    private fun chip(text: String, active: Boolean, action: () -> Unit) {
        val d = resources.displayMetrics.density
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 12f
        b.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.setColor(if (active) Color.rgb(34, 91, 160) else Color.rgb(25, 35, 54))
        g.cornerRadius = 14f * d
        b.background = g
        b.setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-2, (40 * d).toInt())
        lp.setMargins(0, (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
        chips.addView(b, lp)
    }

    private fun refresh() {
        chips.removeAllViews()
        val pairs = TradeJournal.pairs(this)
        if (selected != null && selected !in pairs) selected = null
        chip("الكل", selected == null) { selected = null; refresh() }
        for (p in pairs) chip(p, selected == p) { selected = p; refresh() }
        body.text = TradeJournal.report(this, selected)
        body.visibility = View.VISIBLE
    }
}
