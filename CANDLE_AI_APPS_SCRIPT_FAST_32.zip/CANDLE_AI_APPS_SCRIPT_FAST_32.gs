/**
 * CANDLE AI - Google Apps Script Web App
 * Version 3.2 FAST / failover
 *
 * Required Script Property:
 *   GEMINI_API_KEY = your Gemini API key
 *
 * Optional Script Property:
 *   GEMINI_PRIMARY_MODEL = gemini-3.5-flash-lite
 *
 * Note: This version intentionally does NOT read the old GEMINI_MODEL property,
 * so an old value such as gemini-3.8-flash cannot silently override the new default.
 */

var DEFAULT_PRIMARY_MODEL = "gemini-3.5-flash-lite";
var FALLBACK_MODEL = "gemini-3.6-flash";
var MAX_IMAGE_BYTES = 8 * 1024 * 1024;
var MAX_OUTPUT_TOKENS = 1100;
var THINKING_LEVEL = "LOW";
var SCRIPT_VERSION = "3.2-fast-failover";

/** Main endpoint called by the Android app. */
function doPost(e) {
  var startedAt = Date.now();
  var primaryModel = DEFAULT_PRIMARY_MODEL;
  var lastResult = null;

  try {
    if (!e || !e.postData || !e.postData.contents) {
      return jsonResponse({ ok: false, error: "لم يصل محتوى الطلب." });
    }

    var payload;
    try {
      payload = JSON.parse(e.postData.contents);
    } catch (parseError) {
      return jsonResponse({ ok: false, error: "محتوى الطلب ليس JSON صالحاً." });
    }

    var props = PropertiesService.getScriptProperties();
    var apiKey = props.getProperty("GEMINI_API_KEY");
    if (!apiKey) {
      return jsonResponse({ ok: false, error: "مفتاح Gemini غير مضبوط. أضف GEMINI_API_KEY في Script Properties." });
    }

    // Use the new property name so the old GEMINI_MODEL value is not used accidentally.
    primaryModel = cleanModel(props.getProperty("GEMINI_PRIMARY_MODEL") || DEFAULT_PRIMARY_MODEL);

    var image = parseImage(payload.image_base64);
    if (image.error) return jsonResponse({ ok: false, error: image.error });

    var platform = cleanText(payload.platform, "غير محددة");
    var symbol = cleanText(payload.symbol, "غير محدد");
    var timeframe = cleanText(payload.timeframe, "غير محدد");

    var prompt = [
      "أنت محلل فني للرسوم البيانية. حلل الصورة بالعربية بإيجاز ودقة.",
      "المنصة: " + platform + " | الأصل: " + symbol + " | الإطار الزمني: " + timeframe,
      "استخدم ما يظهر في الصورة فقط. لا تخترع أسعاراً أو مؤشرات أو أحجام تداول.",
      "إذا كانت الصورة غير واضحة أو الإشارات متعارضة فاختر WAIT.",
      "أخرج النتيجة بهذه العناوين:",
      "الاتجاه وبنية السوق:",
      "الإشارة الفنية: BUY أو SELL أو WAIT",
      "قوة الدليل: ضعيفة أو متوسطة أو قوية",
      "الشموع والزخم:",
      "الدعم والمقاومة الظاهران:",
      "أهم الأدلة والمخاطر:",
      "اذكر بوضوح ما الذي يبطل السيناريو. لا تضمن الأرباح ولا تعطِ أمراً بتنفيذ صفقة."
    ].join("\n");

    var requestBody = {
      contents: [{
        role: "user",
        parts: [
          { text: prompt },
          { inlineData: { mimeType: image.mimeType, data: image.base64 } }
        ]
      }],
      generationConfig: {
        maxOutputTokens: MAX_OUTPUT_TOKENS,
        thinkingConfig: { thinkingLevel: THINKING_LEVEL }
      }
    };

    // First attempt: fast, low-latency model.
    var result = callGemini(primaryModel, apiKey, requestBody);
    lastResult = result;

    if (result.ok) {
      var primaryText = extractAnalysis(result.data);
      if (primaryText) {
        return successResponse(primaryText, primaryModel, result.data, startedAt, false);
      }
      return jsonResponse({
        ok: false,
        error: "وصل رد من النموذج الأساسي دون نص تحليل. finishReason=" + getFinishReason(result.data),
        model: primaryModel,
        elapsed_ms: Date.now() - startedAt
      });
    }

    // Switch once to the backup only for overload/service errors or missing model.
    // No repeated retries and no long sleep loop.
    if (shouldUseFallback(result.status)) {
      console.warn("Primary model failed; trying fallback once. status=" + result.status +
        " model=" + primaryModel + " message=" + result.message);

      var fallbackResult = callGemini(FALLBACK_MODEL, apiKey, requestBody);
      lastResult = fallbackResult;

      if (fallbackResult.ok) {
        var fallbackText = extractAnalysis(fallbackResult.data);
        if (fallbackText) {
          return successResponse(fallbackText, FALLBACK_MODEL, fallbackResult.data, startedAt, true);
        }
        return jsonResponse({
          ok: false,
          error: "وصل رد من النموذج الاحتياطي دون نص تحليل. finishReason=" + getFinishReason(fallbackResult.data),
          model: FALLBACK_MODEL,
          elapsed_ms: Date.now() - startedAt,
          fallback_used: true
        });
      }
    }

    var elapsed = Date.now() - startedAt;
    console.error("CANDLE_AI_FAILURE primary=" + primaryModel +
      " status=" + (lastResult ? lastResult.status : 0) +
      " elapsed_ms=" + elapsed +
      " message=" + (lastResult ? lastResult.message : "No response"));

    return jsonResponse({
      ok: false,
      error: friendlyGeminiError(lastResult, primaryModel),
      http_status: lastResult ? lastResult.status : 0,
      elapsed_ms: elapsed,
      retryable: !!(lastResult && (lastResult.status === 429 || lastResult.status >= 500 || lastResult.status === 0))
    });

  } catch (err) {
    var elapsedCatch = Date.now() - startedAt;
    console.error("doPost failed after " + elapsedCatch + "ms: " + String(err));
    return jsonResponse({
      ok: false,
      error: "حدث خطأ أثناء تحليل الصورة: " + String(err),
      elapsed_ms: elapsedCatch
    });
  }
}

/** Make one GenerateContent request. Apps Script UrlFetchApp has no per-request timeout option. */
function callGemini(model, apiKey, requestBody) {
  var url = "https://generativelanguage.googleapis.com/v1beta/models/" +
    encodeURIComponent(model) + ":generateContent";

  try {
    var response = UrlFetchApp.fetch(url, {
      method: "post",
      contentType: "application/json",
      headers: { "x-goog-api-key": apiKey },
      payload: JSON.stringify(requestBody),
      muteHttpExceptions: true
    });

    var status = response.getResponseCode();
    var responseText = response.getContentText();
    var data;
    try {
      data = JSON.parse(responseText);
    } catch (parseError) {
      return { ok: false, status: status, message: "استجابة Gemini ليست JSON صحيحة." };
    }

    if (status >= 200 && status < 300) {
      return { ok: true, status: status, data: data };
    }

    var message = data && data.error && data.error.message
      ? data.error.message : "فشل طلب Gemini.";
    return { ok: false, status: status, message: String(message).substring(0, 700) };

  } catch (err) {
    return { ok: false, status: 0, message: String(err).substring(0, 700) };
  }
}

function shouldUseFallback(status) {
  return status === 404 || status === 429 || status === 500 ||
    status === 502 || status === 503 || status === 504 || status === 0;
}

function successResponse(analysis, model, data, startedAt, fallbackUsed) {
  var usage = data && data.usageMetadata ? data.usageMetadata : {};
  var elapsed = Date.now() - startedAt;
  console.log("CANDLE_AI_SUCCESS model=" + model +
    " elapsed_ms=" + elapsed +
    " prompt_tokens=" + (usage.promptTokenCount || 0) +
    " output_tokens=" + (usage.candidatesTokenCount || 0) +
    " thinking_tokens=" + (usage.thoughtsTokenCount || 0) +
    " fallback=" + fallbackUsed);

  return jsonResponse({
    ok: true,
    analysis: analysis,
    model: model,
    elapsed_ms: elapsed,
    fallback_used: fallbackUsed,
    usage: {
      prompt_tokens: usage.promptTokenCount || 0,
      output_tokens: usage.candidatesTokenCount || 0,
      thinking_tokens: usage.thoughtsTokenCount || 0
    }
  });
}

function extractAnalysis(result) {
  var candidates = result && result.candidates ? result.candidates : [];
  if (!candidates.length) return "";
  var parts = candidates[0].content && candidates[0].content.parts
    ? candidates[0].content.parts : [];
  var textParts = [];
  for (var i = 0; i < parts.length; i++) {
    if (parts[i].text && parts[i].thought !== true) textParts.push(parts[i].text);
  }
  return textParts.join("\n").trim();
}

function getFinishReason(result) {
  try { return result.candidates[0].finishReason || "غير محدد"; }
  catch (e) { return "غير محدد"; }
}

function friendlyGeminiError(result, model) {
  if (!result) return "لم تصل استجابة من Gemini.";
  if (result.status === 0) return "تعذر الاتصال بخدمة Gemini أو انقطع الاتصال. تحقق من الشبكة ثم أعد المحاولة.";
  if (result.status === 400) return "Gemini رفض الطلب (400). تحقق من صيغة الصورة وإعدادات الطلب: " + result.message;
  if (result.status === 401 || result.status === 403) return "مفتاح Gemini غير صالح أو لا يملك صلاحية استخدام API: " + result.message;
  if (result.status === 404) return "النموذج الأساسي والاحتياطي غير متاحين لهذا المفتاح أو غير موجودين. تحقق من صلاحية النماذج في Google AI Studio: " + result.message;
  if (result.status === 429) return "تم تجاوز حصة API أو حد الطلبات (429)، وقد يكون الحد على مستوى المشروع/المفتاح وليس النموذج فقط. راجع الحصة في Google AI Studio أو Google Cloud.";
  if (result.status >= 500) return "خدمة Gemini ما زالت تواجه ضغطاً أو عطلاً (HTTP " + result.status + "). جرب لاحقاً. آخر نموذج: " + model;
  return "فشل طلب Gemini (HTTP " + result.status + "): " + result.message;
}

function doGet() {
  var props = PropertiesService.getScriptProperties();
  return jsonResponse({
    ok: true,
    service: "CANDLE AI Apps Script",
    status: "running",
    primary_model: props.getProperty("GEMINI_PRIMARY_MODEL") || DEFAULT_PRIMARY_MODEL,
    fallback_model: FALLBACK_MODEL,
    thinking_level: THINKING_LEVEL,
    max_output_tokens: MAX_OUTPUT_TOKENS,
    version: SCRIPT_VERSION
  });
}

/** Optional manual check from the Apps Script editor. It checks key/model access with a tiny text request. */
function testGeminiModels() {
  var props = PropertiesService.getScriptProperties();
  var apiKey = props.getProperty("GEMINI_API_KEY");
  if (!apiKey) throw new Error("أضف GEMINI_API_KEY في Script Properties أولاً.");

  var models = [props.getProperty("GEMINI_PRIMARY_MODEL") || DEFAULT_PRIMARY_MODEL, FALLBACK_MODEL];
  var report = [];
  for (var i = 0; i < models.length; i++) {
    var model = cleanModel(models[i]);
    var body = {
      contents: [{ role: "user", parts: [{ text: "أجب بكلمة واحدة: جاهز" }] }],
      generationConfig: {
        maxOutputTokens: 32,
        thinkingConfig: { thinkingLevel: THINKING_LEVEL }
      }
    };
    var result = callGemini(model, apiKey, body);
    report.push({
      model: model,
      ok: result.ok,
      status: result.status,
      response: result.ok ? extractAnalysis(result.data) : result.message
    });
  }
  console.log(JSON.stringify(report));
  return report;
}

function parseImage(value) {
  if (!value) return { error: "لم تُرسل صورة الشارت." };
  var raw = String(value).trim();
  var mimeType = "image/jpeg";

  if (raw.indexOf("data:") === 0) {
    var comma = raw.indexOf(",");
    if (comma < 0) return { error: "تنسيق بيانات الصورة غير صحيح." };
    var header = raw.substring(0, comma);
    var match = header.match(/^data:(image\/(?:jpeg|png|webp));base64$/i);
    if (!match) return { error: "الصيغ المدعومة JPEG وPNG وWebP." };
    mimeType = match[1].toLowerCase();
    raw = raw.substring(comma + 1);
  }

  raw = raw.replace(/\s/g, "");
  if (!raw || !/^[A-Za-z0-9+/]*={0,2}$/.test(raw)) {
    return { error: "بيانات Base64 للصورة غير صالحة." };
  }
  if (raw.length > Math.ceil(MAX_IMAGE_BYTES / 3) * 4 + 4) {
    return { error: "حجم الصورة أكبر من 8 MiB." };
  }

  try {
    var bytes = Utilities.base64Decode(raw);
    if (!bytes || bytes.length === 0) return { error: "الصورة فارغة." };
    if (bytes.length > MAX_IMAGE_BYTES) return { error: "حجم الصورة أكبر من 8 MiB." };
  } catch (decodeError) {
    return { error: "تعذر فك ترميز الصورة." };
  }
  return { mimeType: mimeType, base64: raw };
}

function cleanText(value, fallback) {
  if (value === null || value === undefined) return fallback;
  var text = String(value).replace(/[\r\n\t]/g, " ").trim();
  return text ? text.substring(0, 100) : fallback;
}

function cleanModel(value) {
  var name = String(value || "").trim();
  if (!/^[a-zA-Z0-9._-]+$/.test(name)) return DEFAULT_PRIMARY_MODEL;
  return name;
}

function jsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
