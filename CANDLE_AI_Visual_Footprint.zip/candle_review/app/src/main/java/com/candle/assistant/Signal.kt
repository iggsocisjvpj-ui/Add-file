package com.candle.assistant

import android.graphics.Color
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * kind: 2 إشارة (🟢/🔴)، 0 انتظار (🟡 مؤشرات متعارضة أو ضعيفة)، 1 لا تدخل (⚪ بيانات غير كافية أو غير موثوقة)
 * side: 1 شراء، -1 بيع، 0 لا شيء. regime: 0 عادي، 1 نشط، 2 هادئ.
 * conf درجة توافق المؤشرات وليست احتمال ربح.
 */
class Output(
    val kind: Int, val side: Int, val x: DoubleArray, val p: Double, val regime: Int,
    val conf: Int, val agree: Int, val against: Int, val why: String, val block: String, val info: String
)

/**
 * مؤشرات الخيارات الثنائية (شمعة واحدة):
 * EMA20/50، ارتداد EMA20، RSI(7) 70/30 و80/20، دايفرجنس RSI، بولنجر 20/2 (رفض وانفجار)،
 * نسبة الجسم 70%، ROC، Z-Score عن SMA20، ستوكاستك سريع (5,3,3)، حركة السعر عند المستويات، وATR لتحديد حالة السوق.
 * (الحجم غير متاح من قراءة الشاشة فلا يُستعمل.)
 */
object Signal {
    const val SIGNAL = 2
    const val WAIT = 0
    const val NOGO = 1
    private fun sign(v: Double) = if (v > 0) 1.0 else if (v < 0) -1.0 else 0.0
    // ألوان النافذة بعيدة عمداً عن ألوان الشموع حتى لا تُقرأ كشموع
    val OV_GREEN = Color.rgb(20, 110, 100)
    val OV_RED = Color.rgb(150, 50, 80)
    val OV_AMBER = Color.rgb(130, 100, 20)
    val OV_GRAY = Color.rgb(80, 80, 80)
    private val FN = arrayOf(
        "اتجاه EMA 20/50", "ارتداد من EMA20", "تشبع RSI(7)", "دايفرجنس RSI", "بولنجر (رفض/انفجار)",
        "جسم شمعة قوي", "سرعة ROC", "ابتعاد Z-Score", "تقاطع ستوكاستك", "حركة السعر/مستوى",
        "MACD", "قوة الاتجاه ADX/DI"
    )

    /** حالة السوق من ATR: 0 عادي، 1 نشط، 2 هادئ */
    fun regimeOf(c: List<Candle>): Int {
        if (c.size < 22) return 0
        val r = Ind.atr(c, 5) / Ind.atr(c, 20).coerceAtLeast(1e-6)
        return if (r > 1.3) 1 else if (r < 0.75) 2 else 0
    }

    private fun patterns(c: List<Candle>, atr: Double): Double {
        val n = c.size
        val a = c[n - 3]; val b = c[n - 2]; val d = c[n - 1]
        fun body(x: Candle) = abs(x.close - x.open)
        fun bull(x: Candle) = x.close > x.open
        fun bear(x: Candle) = x.close < x.open
        var v = 0.0
        if (bear(b) && bull(d) && d.open <= b.close && d.close >= b.open && body(d) > body(b)) v += 1.0
        if (bull(b) && bear(d) && d.open >= b.close && d.close <= b.open && body(d) > body(b)) v -= 1.0
        val bd = maxOf(body(d), atr * 0.05)
        val lower = minOf(d.open, d.close) - d.low
        val upper = d.high - maxOf(d.open, d.close)
        val downBefore = c[n - 6].close > d.close
        val upBefore = c[n - 6].close < d.close
        if (lower >= 2 * bd && upper <= bd * 0.7 && downBefore) v += 0.8
        if (upper >= 2 * bd && lower <= bd * 0.7 && upBefore) v -= 0.8
        if (bear(a) && body(a) > atr * 0.5 && body(b) < body(a) * 0.4 && bull(d) && d.close > (a.open + a.close) / 2) v += 1.0
        if (bull(a) && body(a) > atr * 0.5 && body(b) < body(a) * 0.4 && bear(d) && d.close < (a.open + a.close) / 2) v -= 1.0
        return v.coerceIn(-1.0, 1.0)
    }

    /** (قريب من دعم، قريب من مقاومة) اعتماداً على قمم/قيعان سابقة */
    private fun levels(c: List<Candle>, atr: Double): Pair<Boolean, Boolean> {
        val n = c.size
        val close = c[n - 1].close
        var nearRes = Double.MAX_VALUE
        var nearSup = Double.MAX_VALUE
        for (i in maxOf(3, n - 80)..(n - 4)) {
            var isHigh = true; var isLow = true
            for (j in (i - 3)..(i + 3)) {
                if (j == i) continue
                if (c[j].high >= c[i].high) isHigh = false
                if (c[j].low <= c[i].low) isLow = false
            }
            if (isHigh && c[i].high > close) nearRes = minOf(nearRes, c[i].high - close)
            if (isLow && c[i].low < close) nearSup = minOf(nearSup, close - c[i].low)
        }
        val thr = 0.6 * atr
        return Pair(nearSup <= thr, nearRes <= thr)
    }

    /** دايفرجنس RSI: قمة سعرية أعلى مع RSI أدنى (هبوطي -1)، وقاع أدنى مع RSI أعلى (صعودي +1) */
    private fun divergence(c: List<Candle>, rsi: DoubleArray): Double {
        val n = c.size
        val highs = ArrayList<Int>(); val lows = ArrayList<Int>()
        for (i in maxOf(2, n - 30)..(n - 3)) {
            if (c[i].high > c[i - 1].high && c[i].high > c[i - 2].high && c[i].high >= c[i + 1].high && c[i].high >= c[i + 2].high) highs.add(i)
            if (c[i].low < c[i - 1].low && c[i].low < c[i - 2].low && c[i].low <= c[i + 1].low && c[i].low <= c[i + 2].low) lows.add(i)
        }
        var v = 0.0
        if (highs.size >= 2) {
            val a = highs[highs.size - 2]; val b = highs.last()
            if (b >= n - 10 && c[b].high > c[a].high && rsi[b] < rsi[a] - 3) v -= 1.0
        }
        if (lows.size >= 2) {
            val a = lows[lows.size - 2]; val b = lows.last()
            if (b >= n - 10 && c[b].low < c[a].low && rsi[b] > rsi[a] + 3) v += 1.0
        }
        return v.coerceIn(-1.0, 1.0)
    }

    /** الشموع المغلقة فقط، من الأقدم إلى الأحدث. */
    fun compute(c: List<Candle>, minConf: Int, sens: Int, w: DoubleArray, bias: Double): Output {
        val nf = Learner.N
        val none = DoubleArray(nf)
        if (c.size < 30) {
            return Output(NOGO, 0, none, 0.5, 0, 0, 0, 0, "", "بيانات غير كافية (${c.size} شمعة، المطلوب 30+)", "")
        }
        if (c.any { !it.open.isFinite() || !it.close.isFinite() || !it.high.isFinite() || !it.low.isFinite() }) {
            return Output(NOGO, 0, none, 0.5, 0, 0, 0, 0, "", "تعذر الوثوق بقراءة الشموع", "")
        }
        val n = c.size
        val closes = c.map { it.close }
        val atr = Ind.atr(c, 14).coerceAtLeast(1e-6)
        val atrRatio = Ind.atr(c, 5) / Ind.atr(c, 20).coerceAtLeast(1e-6)
        val expansion = atrRatio > 1.3
        val quiet = atrRatio < 0.75
        val e20 = Ind.ema(closes, 20); val e50 = Ind.ema(closes, 50)
        val e9 = Ind.ema(closes, 9); val e21 = Ind.ema(closes, 21)
        val last = c[n - 1]
        val body = abs(last.close - last.open)
        val range = (last.high - last.low).coerceAtLeast(1e-9)
        val lowerW = minOf(last.open, last.close) - last.low
        val upperW = last.high - maxOf(last.open, last.close)
        val dir = if (last.close >= last.open) 1.0 else -1.0
        val trust = 0.5 + 0.5 * minOf(1.0, n / 50.0)   // EMA50 تحتاج 50 شمعة لتستقر

        val v = DoubleArray(nf)
        // 0 اتجاه EMA 20/50
        v[0] = trust * (0.45 * tanh((e20[n - 1] - e50[n - 1]) / atr * 1.5) + 0.25 * tanh((e9[n - 1] - e21[n - 1]) / atr * 2) +
            0.3 * (if (last.close > e20[n - 1]) 1.0 else -1.0))
        // 1 ارتداد من EMA20 مع شمعة رفض
        val upTrend = e20[n - 1] > e50[n - 1] && last.close > e50[n - 1]
        val downTrend = e20[n - 1] < e50[n - 1] && last.close < e50[n - 1]
        v[1] = when {
            upTrend && last.low <= e20[n - 1] + 0.25 * atr && last.close > e20[n - 1] && lowerW >= body -> 1.0
            downTrend && last.high >= e20[n - 1] - 0.25 * atr && last.close < e20[n - 1] && upperW >= body -> -1.0
            else -> 0.0
        }
        // 2 RSI(7) بمستويات 70/30 و80/20
        val rs = Ind.rsiSeries(closes, 7)
        val rsi = rs[n - 1]
        v[2] = when {
            rsi < 20 -> 1.0
            rsi < 30 -> 0.6
            rsi > 80 -> -1.0
            rsi > 70 -> -0.6
            else -> ((50 - rsi) / 100).coerceIn(-0.3, 0.3)
        }
        // 3 دايفرجنس RSI
        v[3] = divergence(c, rs)
        // 4 بولنجر 20/2: رفض عند الأطراف، وانفجار بعد الانضغاط
        val bb = Ind.bb(closes, n - 1)
        val sma20 = bb[0]; val sd = bb[1]
        val upper = sma20 + 2 * sd; val lower = sma20 - 2 * sd
        val pb = if (sd < 1e-9) 0.5 else (last.close - lower) / (upper - lower)
        var bwSum = 0.0; var bwCnt = 0
        for (e in maxOf(19, n - 31) until n - 1) { bwSum += 4 * Ind.bb(closes, e)[1]; bwCnt++ }
        val squeeze = bwCnt >= 5 && 4 * sd < 0.6 * (bwSum / bwCnt)
        v[4] = when {
            squeeze && last.close > upper && body / range > 0.6 -> 1.0
            squeeze && last.close < lower && body / range > 0.6 -> -1.0
            last.high > upper && (last.close <= upper || upperW >= body) -> -1.0
            last.low < lower && (last.close >= lower || lowerW >= body) -> 1.0
            else -> ((0.5 - pb) * 0.6).coerceIn(-0.3, 0.3)
        }
        // 5 نسبة الجسم إلى طول الشمعة (فوق 70% زخم قوي)
        v[5] = dir * ((body / range - 0.5) / 0.3).coerceIn(0.0, 1.0)
        // 6 ROC معياري: استمرار عند ATR المتسع، وارتداد عند الهدوء
        val rocs = (maxOf(5, n - 20) until n).map { (closes[it] - closes[it - 5]) / atr }
        val rocMean = rocs.average()
        val rocSd = sqrt(rocs.map { (it - rocMean) * (it - rocMean) }.average())
        val zR = if (rocSd < 1e-6) 0.0 else rocs.last() / rocSd
        v[6] = (if (expansion) 1.0 else if (quiet) -1.0 else 0.4) * tanh(zR / 2)
        // 7 Z-Score عن SMA20 (عودة للمتوسط)
        val z = if (sd < 1e-9) 0.0 else (last.close - sma20) / sd
        v[7] = if (abs(z) > 1.0) -sign(z) * minOf(1.0, (abs(z) - 1.0) / 1.5) else 0.0
        // 8 ستوكاستك سريع (5,3,3): تقاطع في مناطق التشبع 15/85
        fun kS(i: Int) = (0..2).map { Ind.stochK(c, i - it, 5) }.average()
        val k0 = kS(n - 1); val k1 = kS(n - 2)
        val d0 = (0..2).map { kS(n - 1 - it) }.average(); val d1 = (0..2).map { kS(n - 2 - it) }.average()
        val crossUp = k1 <= d1 && k0 > d0
        val crossDn = k1 >= d1 && k0 < d0
        v[8] = when {
            crossUp && k0 < 15 -> 1.0
            crossDn && k0 > 85 -> -1.0
            crossUp && k0 < 35 -> 0.5
            crossDn && k0 > 65 -> -0.5
            else -> 0.0
        }
        // 9 حركة السعر: ابتلاع/بين بار/نجمة عند دعم أو مقاومة
        val (nearSup, nearRes) = levels(c, atr)
        var pat = patterns(c, atr)
        if (pat > 0 && nearSup) pat *= 1.4
        if (pat < 0 && nearRes) pat *= 1.4
        if (pat == 0.0) pat = (if (nearSup) 0.2 else 0.0) - (if (nearRes) 0.2 else 0.0)
        v[9] = pat.coerceIn(-1.0, 1.0)
        // 10 MACD
        val mf = if (n >= 50) 12 else 8; val ms = if (n >= 50) 26 else 17; val mg = if (n >= 50) 9 else 6
        val ef = Ind.ema(closes, mf); val es = Ind.ema(closes, ms)
        val macd = DoubleArray(n) { ef[it] - es[it] }
        val sigl = Ind.ema(macd.asList(), mg)
        val hist = macd[n - 1] - sigl[n - 1]
        val histPrev = macd[n - 2] - sigl[n - 2]
        v[10] = (0.7 * tanh(hist / atr * 5) + 0.3 * sign(hist - histPrev)).coerceIn(-1.0, 1.0)
        // 11 ADX/DI
        val adxv = Ind.adx(c, if (n >= 50) 14 else 9)
        val adx = adxv[0]; val pdi = adxv[1]; val mdi = adxv[2]
        v[11] = (pdi - mdi) / maxOf(pdi + mdi, 1e-9) * (if (adx > 20) 1.0 else 0.4)

        val momentumF = setOf(5, 10, 11)
        val revF = setOf(2, 3, 7, 8)
        val x = DoubleArray(nf)
        for (i in 0 until nf) {
            val m = when {
                expansion -> if (i in momentumF) 1.3 else if (i in revF) 0.6 else 1.0
                quiet -> if (i in revF) 1.3 else if (i in momentumF) 0.6 else 1.0
                else -> 1.0
            }
            x[i] = v[i] * m
        }
        var zz = bias
        for (i in 0 until nf) zz += w[i] * x[i]
        zz = zz.coerceIn(-20.0, 20.0)
        val pUp = 1 / (1 + exp(-zz))
        val up = pUp >= 0.5
        val s = if (up) 1.0 else -1.0
        val pDir = if (up) pUp else 1 - pUp
        var agree = 0; var against = 0
        for (i in 0 until nf) {
            if (x[i] * s > 0.15) agree++
            if (x[i] * s < -0.15) against++
        }
        val need = (6 - sens).coerceIn(2, 5)
        val regime = if (expansion) 1 else if (quiet) 2 else 0
        val regName = if (expansion) "نشط" else if (quiet) "هادئ" else "عادي"
        val info = "السوق: $regName | ATR×${String.format(java.util.Locale.US, "%.1f", atrRatio)} | RSI7 ${rsi.toInt()} | ADX ${adx.toInt()} | شموع $n\nتوافق $agree/$nf | ضد $against"
        val conf = (pDir * 100).toInt()

        val reason: String? = when {
            conf < minConf -> "درجة التوافق $conf% أقل من الحد $minConf%"
            agree < need -> "المؤشرات المتوافقة $agree فقط (المطلوب $need)"
            against > 3 -> "تعارض: $against مؤشرات ضد الاتجاه"
            else -> null
        }
        if (reason != null) return Output(WAIT, 0, x, pDir, regime, conf, agree, against, "", reason, info)

        val order = (0 until nf).filter { x[it] * s > 0.15 }.sortedByDescending { w[it] * x[it] * s }.take(3)
        val why = order.joinToString("، ") { FN[it] }
        return Output(SIGNAL, if (up) 1 else -1, x, pDir, regime, conf, agree, against, why, "", info)
    }
}
