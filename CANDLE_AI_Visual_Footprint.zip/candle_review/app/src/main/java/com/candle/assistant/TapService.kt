package com.candle.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast

/**
 * خدمة إمكانية الوصول: (1) تنقر على زري الشراء والبيع، (2) تتحقق من نصوص الشاشة أن الحساب تجريبي.
 * لا تعمل إلا إذا فعّلتها بنفسك من إعدادات الهاتف، ولا ينقر التطبيق إلا عند تفعيل التداول التلقائي.
 */
class TapService : AccessibilityService() {
    companion object {
        @Volatile var instance: TapService? = null
        @Volatile var lastDemoSeenAt = 0L
        @Volatile var lastRealSeenAt = 0L
        @Volatile var textNodes = 0
    }

    private var lastScan = 0L
    private val main = Handler(Looper.getMainLooper())
    private var calView: TextView? = null
    private val realRe = Regex("(^|[^a-z])(real|live)([^a-z]|$)")

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val now = System.currentTimeMillis()
        if (now - lastScan < 800) return
        lastScan = now
        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return
        if (root.packageName?.toString() == packageName) return   // نصوص تطبيقنا (Demo/تجريبي) لا تُحتسب دليلاً على الحساب
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0; var texts = 0; var demo = false; var real = false
        while (stack.isNotEmpty() && visited < 800) {
            val n = stack.removeLast()
            visited++
            val t = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()
            if (t.isNotBlank()) {
                texts++
                if (t.contains("demo") || t.contains("تجريب")) demo = true
                if (realRe.containsMatchIn(t) || t.contains("حقيق")) real = true
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i)
                if (c != null) stack.add(c)
            }
        }
        if (demo) lastDemoSeenAt = now
        if (real) lastRealSeenAt = now
        textNodes = texts
    }

    fun tap(x: Float, y: Float): Boolean {
        return try {
            val path = Path()
            path.moveTo(x, y)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 50L))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }

    /** يحدد موضع زري الشراء والبيع: افتح المنصة، وبعد 6 ثوانٍ اضغط مكان كل زر (لن ينفَّذ الضغط) */
    fun calibrate() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        Toast.makeText(this, "افتح منصة التداول على الشارت؛ يبدأ التحديد بعد 6 ثوانٍ", Toast.LENGTH_LONG).show()
        main.postDelayed({
            val tv = TextView(this).apply {
                setBackgroundColor(Color.argb(110, 0, 0, 0))
                setTextColor(Color.WHITE)
                textSize = 20f
                gravity = Gravity.CENTER
                text = "اضغط على مكان زر الشراء 🟢\n(لن يُنفَّذ الضغط)"
            }
            var step = 0
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            tv.setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_UP) {
                    val ed = getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
                    if (step == 0) {
                        ed.putInt("buyX", ev.rawX.toInt()).putInt("buyY", ev.rawY.toInt()).apply()
                        step = 1
                        tv.text = "اضغط على مكان زر البيع 🔴\n(لن يُنفَّذ الضغط)"
                    } else {
                        ed.putInt("sellX", ev.rawX.toInt()).putInt("sellY", ev.rawY.toInt()).apply()
                        try { wm.removeView(tv) } catch (_: Exception) {}
                        calView = null
                        Toast.makeText(this, "تم حفظ موضع الزرين", Toast.LENGTH_LONG).show()
                    }
                }
                true
            }
            try {
                wm.addView(tv, lp)
                calView = tv
            } catch (e: Exception) {
                Toast.makeText(this, "تعذّر عرض شاشة التحديد", Toast.LENGTH_LONG).show()
            }
        }, 6000)
    }
}
