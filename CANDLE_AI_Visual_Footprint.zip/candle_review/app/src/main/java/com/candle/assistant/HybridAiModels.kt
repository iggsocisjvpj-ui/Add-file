package com.candle.assistant

/**
 * نماذج موحدة لنتائج الذكاء الاصطناعي المحلي والسحابي.
 * الثقة هنا درجة تقييم وليست احتمال ربح.
 */
data class AiAnalysis(
    val direction: String,
    val confidence: Int,
    val explanation: String,
    val source: String,
    val cloudUsed: Boolean
)

sealed class CloudAnalysisResult {
    data class Success(val analysis: String) : CloudAnalysisResult()
    data class Failure(val message: String) : CloudAnalysisResult()
}
