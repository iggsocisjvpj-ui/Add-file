package com.candle.assistant

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * قراءة النصوص من شريط أعلى الشاشة (OCR على الجهاز): نوع الحساب (Demo/Real) والرصيد.
 * الرصيد هو أدق مرجع: انخفاضه يعني أن الصفقة دخلت فعلاً، وارتفاعه بعد الانتهاء يعني ربحاً.
 */
object ScreenOcr {
    class Ev(val t: Long, val old: Double, val new: Double)

    @Volatile var busy = false
    @Volatile var demoAt = 0L
    @Volatile var realAt = 0L
    @Volatile var stableBal = Double.NaN
    @Volatile var stableAt = 0L
    @Volatile var lastBal = Double.NaN
    @Volatile var reads = 0
    @Volatile var coverNote = false

    private var cand = Double.NaN
    private var candN = 0
    private val events = ArrayList<Ev>()
    private val numRe = Regex("(\\d{1,3}(?:[ ,]\\d{3})+|\\d+)\\.\\d{2}(?!\\d)")
    private val realRe = Regex("(^|[^a-z])(real|live)([^a-z]|$)")
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    fun process(bmp: Bitmap) {
        if (busy) { bmp.recycle(); return }
        busy = true
        try {
            recognizer.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { t ->
                    try { parse(t) } catch (_: Exception) {}
                }
                .addOnCompleteListener {
                    try { bmp.recycle() } catch (_: Exception) {}
                    busy = false
                }
        } catch (e: Exception) {
            try { bmp.recycle() } catch (_: Exception) {}
            busy = false
        }
    }

    private fun parse(t: com.google.mlkit.vision.text.Text) {
        val now = System.currentTimeMillis()
        var seenLabel = false
        var afterLabel = Double.NaN
        var first = Double.NaN
        for (b in t.textBlocks) {
            for (ln in b.lines) {
                val raw = ln.text
                val s = raw.lowercase()
                val isDemo = s.contains("demo") || s.contains("تجريب")
                val isReal = realRe.containsMatchIn(s) || s.contains("حقيق")
                if (isDemo) { demoAt = now; seenLabel = true }
                if (isReal) { realAt = now; seenLabel = true }
                val m = numRe.find(raw)
                if (m != null) {
                    val v = m.value.replace(",", "").replace(" ", "").toDoubleOrNull()
                    if (v != null) {
                        if (first.isNaN()) first = v
                        if (seenLabel && afterLabel.isNaN()) afterLabel = v
                    }
                }
            }
        }
        val bal = if (!afterLabel.isNaN()) afterLabel else first
        if (!bal.isNaN()) { lastBal = bal; reads++; feed(bal, now) }
    }

    /** يعتمد القيمة بعد قراءتين متطابقتين متتاليتين، ويسجّل حدثاً عند تغيّر الرصيد المستقر */
    private fun feed(v: Double, now: Long) {
        if (cand.isNaN() || abs(v - cand) > 0.004) { cand = v; candN = 1 } else candN++
        if (candN >= 2) {
            if (stableBal.isNaN() || abs(stableBal - cand) > 0.004) {
                val old = stableBal
                if (!old.isNaN()) synchronized(events) {
                    events.add(Ev(now, old, cand))
                    if (events.size > 40) events.removeAt(0)
                }
                stableBal = cand
            }
            stableAt = now
        }
    }

    fun stable(now: Long): Double = if (!stableBal.isNaN() && now - stableAt < 6000) stableBal else Double.NaN

    /** آخر انخفاض في الرصيد بعد الزمن t0 (دخول صفقة) بقيمة معقولة */
    fun dropSince(t0: Long): Ev? = synchronized(events) {
        events.lastOrNull { it.t >= t0 && it.new < it.old - 0.5 && it.old - it.new <= it.old * 0.6 }
    }

    fun isDemo(now: Long): Boolean = now - demoAt < 20000 && now - realAt > 20000
}
