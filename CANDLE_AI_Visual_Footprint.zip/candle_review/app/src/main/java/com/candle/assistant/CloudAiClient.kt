package com.candle.assistant

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * عميل سحابي آمن مبدئيًا.
 *
 * لا تضع مفتاح مزود الذكاء الاصطناعي هنا أو داخل APK.
 * مرّر عنوان خادمك الخلفي HTTPS بعد نشره. الخادم الخلفي هو الذي يحتفظ بالمفتاح.
 *
 * عقد API المتوقع:
 * POST /v1/chart/analyze
 * JSON: { "platform": "...", "image_base64": "..." }
 * Response JSON: { "analysis": "..." }
 *
 * استدعِ analyzeChart من خيط خلفي (ليس خيط واجهة Android).
 */
class CloudAiClient(
    private val backendUrl: String,
    private val bearerToken: String? = null
) {
    fun analyzeChart(imageBytes: ByteArray, platform: String): CloudAnalysisResult {
        if (imageBytes.isEmpty()) {
            return CloudAnalysisResult.Failure("الصورة فارغة")
        }
        if (backendUrl.isBlank()) {
            return CloudAnalysisResult.Failure("الخدمة السحابية غير مهيأة بعد")
        }

        val url = try { URL(backendUrl) } catch (_: Exception) {
            return CloudAnalysisResult.Failure("عنوان الخادم غير صحيح")
        }
        if (url.protocol != "https") {
            return CloudAnalysisResult.Failure("يجب استخدام HTTPS لحماية الصور والبيانات")
        }

        var connection: HttpURLConnection? = null
        return try {
            val payload = JSONObject()
                .put("platform", platform.take(80))
                .put("image_base64", Base64.encodeToString(imageBytes, Base64.NO_WRAP))
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 25000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                bearerToken?.takeIf { it.isNotBlank() }?.let {
                    setRequestProperty("Authorization", "Bearer $it")
                }
            }
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                CloudAnalysisResult.Failure("الخادم أعاد الخطأ HTTP $code")
            } else {
                val result = JSONObject(body).optString("analysis").trim()
                if (result.isEmpty()) CloudAnalysisResult.Failure("استجابة الخادم لا تحتوي على analysis")
                else CloudAnalysisResult.Success(result)
            }
        } catch (_: java.net.SocketTimeoutException) {
            CloudAnalysisResult.Failure("انتهت مهلة الاتصال بالخدمة السحابية")
        } catch (_: Exception) {
            CloudAnalysisResult.Failure("تعذر الاتصال بالخدمة السحابية")
        } finally {
            connection?.disconnect()
        }
    }
}
