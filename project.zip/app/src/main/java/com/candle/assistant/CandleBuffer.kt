package com.candle.assistant

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * سجل متحرك للشموع: كل لقطة تُظهر نحو 30 شمعة فقط، فنلصق اللقطة الجديدة بالسجل
 * بمطابقة الشموع المتداخلة (اللون + ملاءمة خطية للسعر)، فيكبر السجل تدريجياً حتى 150 شمعة.
 */
class CandleBuffer(private val maxSize: Int = 150) {
    val list = ArrayList<Candle>()
    var a = 1.0          // تحويل سعر اللقطة الحالية إلى مقياس السجل: y = a*x + b
    var b = 0.0
    var total = 0L       // عدد الشموع المغلقة التي دخلت السجل منذ آخر تصفير
    var appended = 0     // عدد الشموع الجديدة في آخر تحديث
    var wasReset = false

    private fun fill(f: List<Candle>) {
        list.clear(); list.addAll(f)
        a = 1.0; b = 0.0
        total = f.size.toLong()
        wasReset = true
    }

    fun update(f: List<Candle>) {
        appended = 0; wasReset = false
        val n = f.size
        val len = list.size
        if (len == 0) { fill(f); return }
        if (n < 12) return
        val atrB = Ind.atr(list, 14).coerceAtLeast(1e-6)
        var bestS = -1; var bestR = Double.MAX_VALUE; var bestA = 1.0; var bestB = 0.0
        for (s in 0..10) {
            val lo = maxOf(0, n - len - s)
            val hi = n - 1 - s
            val m = hi - lo + 1
            if (m < 12) continue
            var sx = 0.0; var sy = 0.0; var sxx = 0.0; var sxy = 0.0; var same = 0
            for (i in lo..hi) {
                val bc = list[len + s - n + i]
                val x = f[i].close; val y = bc.close
                sx += x; sy += y; sxx += x * x; sxy += x * y
                if ((f[i].close > f[i].open) == (bc.close > bc.open)) same++
            }
            if (same < 0.85 * m) continue
            val den = m * sxx - sx * sx
            if (abs(den) < 1e-9) continue
            val a1 = (m * sxy - sx * sy) / den
            val b1 = (sy - a1 * sx) / m
            if (a1 <= 0.05) continue
            var se = 0.0
            for (i in lo..hi) {
                val e = list[len + s - n + i].close - (a1 * f[i].close + b1)
                se += e * e
            }
            val r = sqrt(se / m) / atrB
            if (r < bestR) { bestR = r; bestS = s; bestA = a1; bestB = b1 }
        }
        if (bestS < 0 || bestR > 0.5) { fill(f); return }   // تغيّر الشارت (زوج/تكبير) فنبدأ سجلاً جديداً
        a = bestA; b = bestB
        if (bestS > 0) {
            for (k in (n - bestS) until n) {
                val c = f[k]
                list.add(Candle(a * c.open + b, a * c.close + b, a * c.high + b, a * c.low + b))
            }
            total += bestS
            appended = bestS
            while (list.size > maxSize) list.removeAt(0)
        }
    }
}
