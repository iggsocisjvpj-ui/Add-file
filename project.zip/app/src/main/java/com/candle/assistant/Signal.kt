package com.candle.assistant

import android.graphics.Color
import kotlin.math.abs

data class Result(val text: String, val color: Int)

object Signal {
    private fun ema(v: List<Double>, span: Int): List<Double> {
        val a = 2.0 / (span + 1)
        val out = ArrayList<Double>()
        var prev = v.first()
        for (x in v) { prev = a * x + (1 - a) * prev; out.add(prev) }
        return out
    }

    private fun rsi(v: List<Double>, n: Int): Double {
        val d = v.zipWithNext { a, b -> b - a }.takeLast(n)
        val gain = d.filter { it > 0 }.sum()
        val loss = -d.filter { it < 0 }.sum()
        if (loss == 0.0) return 100.0
        return 100 - 100 / (1 + gain / loss)
    }

    fun compute(c: List<Candle>, tf: Int): Result {
        if (c.size < 30) {
            return Result("بيانات غير كافية (${c.size} شمعة)\nعدّل حدود الشارت أو قرّب الشموع", Color.DKGRAY)
        }
        val closes = c.map { it.close }
        val fast = ema(closes, 9)
        val slow = ema(closes, 21)
        val d1 = fast.zipWithNext { a, b -> b - a }
        val d2 = d1.zipWithNext { a, b -> b - a }
        val r = rsi(closes, 14)
        val avgRange = c.takeLast(20).map { it.high - it.low }.average()

        var up = 1.0; var down = 1.0; var noise = 1.0
        if (d1.last() > 0 && d2.last() > 0) up *= 1.5
        if (d1.last() < 0 && d2.last() < 0) down *= 1.5
        if (d1.last() > 0 && d2.last() < 0) down *= 1.15   // تباطؤ الصعود
        if (d1.last() < 0 && d2.last() > 0) up *= 1.15     // تباطؤ الهبوط
        if (r < 30) up *= 1.3
        if (r > 70) down *= 1.3
        if (fast.last() > slow.last()) up *= 1.2 else down *= 1.2
        if (abs(fast.last() - slow.last()) < 0.1 * avgRange) noise *= 1.8

        val pu = up * 0.4; val pd = down * 0.4; val pn = noise * 0.2
        val s = pu + pd + pn
        val postUp = pu / s; val postDown = pd / s
        val dur = 2 * tf
        val info = "RSI ${r.toInt()}  |  شموع ${c.size}"
        return when {
            postUp > 0.5 -> Result("شراء ▲  ${(postUp * 100).toInt()}%\nالمدة: $dur ثانية\n$info", Color.rgb(0, 140, 70))
            postDown > 0.5 -> Result("بيع ▼  ${(postDown * 100).toInt()}%\nالمدة: $dur ثانية\n$info", Color.rgb(200, 40, 40))
            else -> Result("لا تدخل\n$info", Color.DKGRAY)
        }
    }
}
