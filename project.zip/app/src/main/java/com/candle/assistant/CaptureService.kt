package com.candle.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class CaptureService : Service() {
    private class Paper(val side: Int, val x: DoubleArray, val entryTotal: Long)
    private class Trade(val side: Int, val x: DoubleArray, val entry: Double, val endAt: Long)

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var root: LinearLayout? = null
    private var tv: TextView? = null
    private var rowA: LinearLayout? = null
    private var rowB: LinearLayout? = null
    private var rowC: LinearLayout? = null
    private var worker: HandlerThread? = null
    private val main = Handler(Looper.getMainLooper())
    private var lastRun = 0L
    private var bmp: Bitmap? = null
    private var px = IntArray(0)
    private var screenW = 1080
    private var screenH = 2400
    @Volatile private var alive = false
    private var bandText = ""

    private val lock = Any()
    private val buffer = CandleBuffer()
    private var state = 0                 // 0 تحليل، 1 صفقة جارية، 2 نتيجة بانتظار التأكيد
    private var candleStartMs = 0L
    private var rawSig: Output? = null
    private var paper: Paper? = null
    private var trade: Trade? = null
    private var resultEst = -1            // 1 ربح، 0 خسارة، -1 تعادل
    private var lastFormingClose = Double.NaN
    private var lastAtr = 1.0
    private var tfSec = 60
    private var tradeMin = 2
    @Volatile private var ovX = 0
    @Volatile private var ovY = 0
    @Volatile private var ovW = 0
    @Volatile private var ovH = 0
    @Volatile private var coverNote = ""
    private val confirmRunnable = Runnable { confirm(null) }
    private val endRunnable = Runnable { synchronized(lock) { if (state == 1) finishTrade() } }
    // مؤقت مستقل عن قراءة الشموع: يحدّث عدّاد الصفقة كل ثانية حتى لو تعذرت قراءة الشارت
    private val ticker = object : Runnable {
        override fun run() {
            if (!alive) return
            synchronized(lock) { if (state == 1) tradeTick(System.currentTimeMillis()) }
            main.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (alive) return START_NOT_STICKY
        startForegroundCompat()
        val code = intent.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        }
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            alive = true
            beginCapture(code, data)
        } catch (e: Exception) {
            alive = false
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cap", "التحليل", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAct = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "إيقاف", stopPi
        ).build()
        val n: Notification = Notification.Builder(this, "cap")
            .setContentTitle("محلل الشموع يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(stopAct)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }
    }

    private fun beginCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { if (alive) stopSelf() }
        }, main)

        val (w, h) = screenSize()
        screenW = w
        screenH = h
        val dpi = resources.displayMetrics.densityDpi
        val t = HandlerThread("analyze").also { it.start() }
        worker = t
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        display = proj.createVirtualDisplay(
            "cap", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        r.setOnImageAvailableListener({ rd -> onImage(rd) }, Handler(t.looper))
        showOverlay()
    }

    private fun onImage(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            if (!alive) return
            val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
            val sens = cfg.getInt("sens", 3).coerceIn(1, 5)
            val interval = (2600 - sens * 400).toLong()
            val now = System.currentTimeMillis()
            if (now - lastRun < interval) return
            lastRun = now
            val topPct = cfg.getInt("top", 16).coerceIn(0, 95)
            val botPct = cfg.getInt("bottom", 60).coerceIn(topPct + 3, 100)
            val tf = cfg.getInt("tf", 60).coerceAtLeast(5)
            val minConf = cfg.getInt("conf", 60).coerceIn(50, 95)

            val plane = img.planes[0]
            val rowPixels = plane.rowStride / plane.pixelStride
            var b = bmp
            if (b == null || b.width != rowPixels || b.height != img.height) {
                b?.recycle()
                b = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
                bmp = b
            }
            plane.buffer.rewind()
            b!!.copyPixelsFromBuffer(plane.buffer)
            val w = img.width
            var topPx = img.height * topPct / 100
            var botPx = img.height * botPct / 100
            // النافذة العائمة تظهر في اللقطة نفسها، فنُخرج منطقتها من التحليل بدل أن تُقرأ كشموع
            if (ovW > 0 && ovY + ovH > topPx && ovY < botPx) {
                val mid = (topPx + botPx) / 2
                if (ovY + ovH / 2 < mid) topPx = minOf(botPx - 60, ovY + ovH + 4)
                else botPx = maxOf(topPx + 60, ovY - 4)
            }
            val top = topPx.coerceIn(0, img.height - 20)
            val bandH = (botPx - top).coerceIn(10, img.height - top)
            bandText = "المنطقة المحللة ${top * 100 / img.height}% إلى ${(top + bandH) * 100 / img.height}%"
            if (px.size != w * bandH) px = IntArray(w * bandH)
            b.getPixels(px, 0, w, 0, top, w, bandH)

            val read = CandleReader.read(px, w, bandH)
            process(read, now, tf, minConf, sens)
        } catch (e: Exception) {
            main.post { tv?.text = "خطأ في التحليل" }
        } finally {
            img.close()
        }
    }

    private fun process(read: List<Candle>, now: Long, tf: Int, minConf: Int, sens: Int) {
        synchronized(lock) {
            tfSec = tf
            // آخر شمعة ما زالت تتشكل، فلا تدخل في التحليل
            val closed = if (read.size > 1) read.dropLast(1) else emptyList()
            if (closed.size < 12) {
                if (state == 0) ui("قراءة غير كافية: ${closed.size} شمعة فقط\nقرّب الشارت حتى تظهر 30 إلى 45 شمعة، وتأكد من حدود الشارت واتجاه الهاتف", Color.DKGRAY, 0)
                return
            }
            val forming = read.last()
            buffer.update(closed)
            lastFormingClose = buffer.a * forming.close + buffer.b
            lastAtr = Ind.atr(buffer.list, 14).coerceAtLeast(1e-6)
            if (buffer.wasReset) { candleStartMs = 0L; paper = null; rawSig = null }
            val newCandle = buffer.appended > 0
            if (newCandle) {
                candleStartMs = now
                evaluatePaper(buffer.appended)
            }
            when (state) {
                1 -> tradeTick(now)
                0 -> analyzeTick(now, newCandle, tf, minConf, sens)
                else -> {}
            }
        }
    }

    /** تقييم الإشارة الافتراضية بعد إغلاق شمعتها: هل أغلقت في اتجاه الإشارة؟ */
    private fun evaluatePaper(appended: Int) {
        val p = paper ?: return
        paper = null
        if (appended != 1 || buffer.total != p.entryTotal + 1) return
        val c = buffer.list.last()
        val diff = c.close - c.open
        if (abs(diff) < 0.02 * lastAtr) return
        val win = (p.side == 1 && diff > 0) || (p.side == -1 && diff < 0)
        Learner.paper(this, win)
        Learner.learn(this, p.x, p.side, win, 0.006)
    }

    private fun analyzeTick(now: Long, newCandle: Boolean, tf: Int, minConf: Int, sens: Int) {
        val have = buffer.list.size
        if (have < 30) {
            ui("جاري تجميع الشموع: $have/30\n$bandText", Color.DKGRAY, 0)
            return
        }
        if (newCandle || rawSig == null) {
            val s = Signal.compute(buffer.list, tf, minConf, sens, Learner.weights(this), Learner.bias(this))
            rawSig = s
            if (newCandle) paper = if (s.side != 0) Paper(s.side, s.x, buffer.total) else null
        }
        val sig = rawSig ?: return
        val since = if (candleStartMs > 0) (now - candleStartMs) / 1000.0 else -1.0
        val remain = if (since >= 0) (tf - since).toInt().coerceAtLeast(0) else -1
        val window = (tf * 0.2).coerceIn(3.0, 12.0)
        val inWindow = since in 0.0..window
        val ps = Learner.paperStats(this)
        val paperLine = if (ps.first < 30) "اختبار افتراضي: ${ps.first}/30 (قيد المعايرة)"
        else "اختبار افتراضي: ${(ps.second * 100).toInt()}% من آخر ${ps.first}"
        val wait = if (remain >= 0) "الشمعة القادمة بعد $remain ث" else "بانتظار بداية شمعة جديدة"
        val locked = Learner.locked(this)
        when {
            sig.side != 0 && locked ->
                ui("لا تدخل — قفل الأمان\nالنجاح الافتراضي ${(ps.second * 100).toInt()}% أقل من 52%\nالتحليل يستمر خلفياً للتعلم", Color.DKGRAY, 0)
            sig.side != 0 && inWindow ->
                ui("ادخل الآن • " + sig.text + "\n" + paperLine, sig.color, 0)
            sig.side != 0 ->
                ui("فاتت نافذة الدخول — انتظر الشمعة القادمة\n$wait\n$paperLine", Color.DKGRAY, 0)
            else ->
                ui(sig.text + "\n" + wait + "\n" + paperLine, Color.DKGRAY, 0)
        }
    }

    private fun tradeTick(now: Long) {
        val t = trade ?: return
        val rem = ((t.endAt - now) / 1000).toInt()
        if (rem <= 0) { finishTrade(); return }
        val side = if (t.side == 1) "▲ شراء" else "▼ بيع"
        ui("صفقة جارية $side\nالمتبقي: $rem ث\nالتحليل متوقف. ستظهر النتيجة المقدّرة عند الانتهاء،\nأو سجّلها يدوياً الآن بالزرين أدناه", Color.rgb(30, 90, 180), 1)
    }

    private fun finishTrade() {
        val t = trade ?: return
        val diff = lastFormingClose - t.entry
        val eps = 0.03 * lastAtr
        resultEst = when {
            diff.isNaN() || abs(diff) < eps -> -1
            (t.side == 1 && diff > 0) || (t.side == -1 && diff < 0) -> 1
            else -> 0
        }
        state = 2
        val side = if (t.side == 1) "▲ شراء" else "▼ بيع"
        val est = when (resultEst) { 1 -> "✔ ربح"; 0 -> "✘ خسارة"; else -> "تعادل" }
        val col = when (resultEst) { 1 -> Signal.OV_GREEN; 0 -> Signal.OV_RED; else -> Color.DKGRAY }
        ui("انتهت الصفقة ($side)\nالنتيجة المقدّرة: $est\nإن كانت القراءة خاطئة اضغط النتيجة الصحيحة، أو «متابعة» لاعتماد المقدّرة", col, 2)
        main.removeCallbacks(confirmRunnable)
        main.postDelayed(confirmRunnable, 25000)
    }

    /** side: اتجاه الصفقة التي نفّذتها أنت في المنصة (1 شراء، -1 بيع) */
    private fun enter(side: Int) {
        synchronized(lock) {
            if (state != 0) return
            if (lastFormingClose.isNaN()) { toast("انتظر قراءة السعر"); return }
            val x = rawSig?.x ?: DoubleArray(Learner.N)
            trade = Trade(side, x, lastFormingClose, System.currentTimeMillis() + tfSec * 1000L)
            state = 1
            main.removeCallbacks(endRunnable)
            main.postDelayed(endRunnable, tfSec * 1000L + 1200)
            ui("صفقة جارية — بدأ العدّ\nالتحليل متوقف حتى تنتهي الصفقة", Color.rgb(30, 90, 180), 1)
        }
    }

    private fun cancelTrade() {
        synchronized(lock) {
            if (state != 1) return
            main.removeCallbacks(endRunnable)
            trade = null; state = 0; rawSig = null
            ui("أُلغيت الصفقة (لم تُسجَّل)\nبانتظار الشمعة القادمة", Color.DKGRAY, 0)
        }
    }

    private fun manualResult(win: Boolean) {
        synchronized(lock) {
            if (state != 1) return
            main.removeCallbacks(endRunnable)
            state = 2
        }
        confirm(win)
    }

    /** win = null يعني اعتماد النتيجة المقدّرة تلقائياً */
    private fun confirm(win: Boolean?) {
        synchronized(lock) {
            if (state != 2) return
            main.removeCallbacks(confirmRunnable)
            val t = trade
            val w: Boolean? = win ?: (if (resultEst == 1) true else if (resultEst == 0) false else null)
            if (t != null && w != null) {
                Learner.stat(this, w)
                Learner.learn(this, t.x, t.side, w, 0.02)
                toast(if (w) "سُجّل الربح وتعلّم النظام" else "سُجّلت الخسارة وتعلّم النظام")
            } else {
                toast("تعادل — لم يُسجَّل")
            }
            trade = null; state = 0; rawSig = null
            ui("بانتظار الشمعة القادمة...", Color.DKGRAY, 0)
        }
    }

    private fun toast(m: String) {
        main.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    private fun ui(text: String, color: Int, st: Int) {
        main.post {
            tv?.text = text
            tv?.setBackgroundColor(color)
            rowA?.visibility = if (st == 0) View.VISIBLE else View.GONE
            rowB?.visibility = if (st == 1) View.VISIBLE else View.GONE
            rowC?.visibility = if (st == 2) View.VISIBLE else View.GONE
            root?.post { updateOv() }
        }
    }

    private fun updateOv() {
        val b = root ?: return
        val loc = IntArray(2)
        try { b.getLocationOnScreen(loc) } catch (_: Exception) { return }
        ovY = loc[1]; ovW = b.width; ovH = b.height
    }

    private fun showOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(235, 25, 25, 25))
            setPadding(8, 8, 8, 8)
            minimumWidth = (screenW * 0.80).toInt()
        }
        val label = TextView(this).apply {
            text = "جاري التحليل... (اسحب هنا لتحريك النافذة؛ بعد دخولك الصفقة اضغط شراء أو بيع)"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.DKGRAY)
            textSize = 12f
            setPadding(24, 14, 24, 14)
        }
        box.addView(label)

        fun newRow(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(row: LinearLayout, t: String, bg: Int, f: () -> Unit) {
            val b = TextView(this).apply {
                text = t
                setTextColor(Color.WHITE)
                setBackgroundColor(bg)
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(6, 14, 6, 14)
                setOnClickListener { f() }
            }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(4, 8, 4, 0)
            row.addView(b, lp)
        }
        val a = newRow(); val bb = newRow(); val cc = newRow()
        btn(a, "دخلت شراء ▲", Signal.OV_GREEN) { enter(1) }
        btn(a, "دخلت بيع ▼", Signal.OV_RED) { enter(-1) }
        btn(a, "إيقاف", Color.GRAY) { stopSelf() }
        btn(bb, "✔ ربحت", Signal.OV_GREEN) { manualResult(true) }
        btn(bb, "✘ خسرت", Signal.OV_RED) { manualResult(false) }
        btn(bb, "إلغاء", Color.rgb(130, 90, 20)) { cancelTrade() }
        btn(bb, "إيقاف", Color.GRAY) { stopSelf() }
        btn(cc, "✔ ربحت", Signal.OV_GREEN) { confirm(true) }
        btn(cc, "✘ خسرت", Signal.OV_RED) { confirm(false) }
        btn(cc, "متابعة", Color.rgb(30, 90, 180)) { confirm(null) }
        btn(cc, "إيقاف", Color.GRAY) { stopSelf() }
        box.addView(a); box.addView(bb); box.addView(cc)
        bb.visibility = View.GONE
        cc.visibility = View.GONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (screenW * 0.07).toInt()
        lp.y = (screenH * 0.80).toInt()

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        label.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; startX = lp.x; startY = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (ev.rawX - downX).toInt()
                    lp.y = startY + (ev.rawY - downY).toInt()
                    try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                    box.post { updateOv() }
                }
            }
            true
        }
        wm.addView(box, lp)
        box.post { updateOv() }
        main.postDelayed(ticker, 1000)
        root = box; tv = label; rowA = a; rowB = bb; rowC = cc
    }

    override fun onDestroy() {
        alive = false
        main.removeCallbacks(confirmRunnable)
        main.removeCallbacks(endRunnable)
        main.removeCallbacks(ticker)
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        worker?.quitSafely()
        root?.let {
            try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        root = null; tv = null; rowA = null; rowB = null; rowC = null
        try { bmp?.recycle() } catch (_: Exception) {}
        bmp = null
        @Suppress("DEPRECATION") stopForeground(true)
        super.onDestroy()
    }
}
