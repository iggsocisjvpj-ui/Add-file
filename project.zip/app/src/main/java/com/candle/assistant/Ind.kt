package com.candle.assistant

import kotlin.math.abs

/** مؤشرات فنية مستقلة عن مقياس السعر (تعمل على بكسلات الشارت). */
object Ind {
    fun ema(v: List<Double>, span: Int): DoubleArray {
        val out = DoubleArray(v.size)
        val a = 2.0 / (span + 1)
        var prev = v[0]
        for (i in v.indices) { prev = a * v[i] + (1 - a) * prev; out[i] = prev }
        return out
    }

    fun atr(c: List<Candle>, n: Int): Double {
        var s = 0.0; var k = 0
        for (i in maxOf(1, c.size - n) until c.size) {
            val pc = c[i - 1].close
            s += maxOf(c[i].high - c[i].low, abs(c[i].high - pc), abs(c[i].low - pc)); k++
        }
        return if (k == 0) 1.0 else s / k
    }

    fun rsi(c: List<Double>, n: Int): Double {
        if (c.size <= n) return 50.0
        var g = 0.0; var l = 0.0
        for (i in 1..n) { val d = c[i] - c[i - 1]; if (d > 0) g += d else l -= d }
        g /= n; l /= n
        for (i in n + 1 until c.size) {
            val d = c[i] - c[i - 1]
            g = (g * (n - 1) + maxOf(d, 0.0)) / n
            l = (l * (n - 1) + maxOf(-d, 0.0)) / n
        }
        return if (l == 0.0) 100.0 else 100 - 100 / (1 + g / l)
    }

    /** [ADX, +DI, -DI] */
    fun adx(c: List<Candle>, n: Int): DoubleArray {
        val m = c.size
        if (m < 2 * n + 2) return doubleArrayOf(20.0, 50.0, 50.0)
        val tr = DoubleArray(m); val pdm = DoubleArray(m); val mdm = DoubleArray(m)
        for (i in 1 until m) {
            val up = c[i].high - c[i - 1].high
            val dn = c[i - 1].low - c[i].low
            pdm[i] = if (up > dn && up > 0) up else 0.0
            mdm[i] = if (dn > up && dn > 0) dn else 0.0
            val pc = c[i - 1].close
            tr[i] = maxOf(c[i].high - c[i].low, abs(c[i].high - pc), abs(c[i].low - pc))
        }
        var trS = 0.0; var pS = 0.0; var mS = 0.0
        for (i in 1..n) { trS += tr[i]; pS += pdm[i]; mS += mdm[i] }
        val dx = ArrayList<Double>()
        var pdi = 0.0; var mdi = 0.0
        fun push() {
            if (trS <= 1e-9) { pdi = 0.0; mdi = 0.0; dx.add(0.0); return }
            pdi = 100 * pS / trS; mdi = 100 * mS / trS
            dx.add(100 * abs(pdi - mdi) / maxOf(pdi + mdi, 1e-9))
        }
        push()
        for (i in n + 1 until m) {
            trS = trS - trS / n + tr[i]; pS = pS - pS / n + pdm[i]; mS = mS - mS / n + mdm[i]
            push()
        }
        var a = dx.take(n).average()
        for (k in n until dx.size) a = (a * (n - 1) + dx[k]) / n
        return doubleArrayOf(a, pdi, mdi)
    }

    fun slope(v: List<Double>, k: Int): Double {
        val y = v.takeLast(k)
        val xm = (y.size - 1) / 2.0
        val ym = y.average()
        var num = 0.0; var den = 0.0
        for (i in y.indices) { num += (i - xm) * (y[i] - ym); den += (i - xm) * (i - xm) }
        return if (den == 0.0) 0.0 else num / den
    }

    fun stochK(c: List<Candle>, i: Int, n: Int): Double {
        var lo = Double.MAX_VALUE; var hi = -Double.MAX_VALUE
        for (j in (i - n + 1)..i) { if (c[j].low < lo) lo = c[j].low; if (c[j].high > hi) hi = c[j].high }
        return if (hi - lo < 1e-9) 50.0 else (c[i].close - lo) / (hi - lo) * 100
    }

    /** [المتوسط، الانحراف] لآخر 20 إغلاقاً حتى end */
    fun bb(closes: List<Double>, end: Int): DoubleArray {
        val s = closes.subList(end - 19, end + 1)
        val m = s.average()
        var sq = 0.0
        for (x in s) sq += (x - m) * (x - m)
        return doubleArrayOf(m, Math.sqrt(sq / s.size))
    }

    fun cci(c: List<Candle>, n: Int): Double {
        val m = c.size
        if (m < n) return 0.0
        var sum = 0.0
        for (i in m - n until m) sum += (c[i].high + c[i].low + c[i].close) / 3
        val ma = sum / n
        var md = 0.0
        for (i in m - n until m) md += abs((c[i].high + c[i].low + c[i].close) / 3 - ma)
        md /= n
        return if (md < 1e-9) 0.0 else ((c[m - 1].high + c[m - 1].low + c[m - 1].close) / 3 - ma) / (0.015 * md)
    }

    /** اتجاه هايكين آشي لآخر 3 شموع (-1..1) */
    fun haScore(c: List<Candle>, atr: Double): Double {
        val m = c.size
        val haC = DoubleArray(m); val haO = DoubleArray(m)
        for (i in 0 until m) {
            haC[i] = (c[i].open + c[i].high + c[i].low + c[i].close) / 4
            haO[i] = if (i == 0) (c[0].open + c[0].close) / 2 else (haO[i - 1] + haC[i - 1]) / 2
        }
        var sum = 0.0
        for (i in m - 3 until m) {
            val hi = maxOf(c[i].high, haO[i], haC[i])
            val lo = minOf(c[i].low, haO[i], haC[i])
            val bull = haC[i] > haO[i]
            val strong = if (bull) (minOf(haO[i], haC[i]) - lo) < 0.1 * atr else (hi - maxOf(haO[i], haC[i])) < 0.1 * atr
            sum += (if (bull) 1.0 else -1.0) * (if (strong) 1.0 else 0.5)
        }
        return sum / 3
    }

    /** طول تتابع الشموع المتشابهة الأخير: موجب صاعد، سالب هابط */
    fun streak(c: List<Candle>): Int {
        val last = c.last()
        val dir = if (last.close >= last.open) 1 else -1
        var k = 0
        for (i in c.indices.reversed()) {
            val d = if (c[i].close >= c[i].open) 1 else -1
            if (d == dir) k++ else break
        }
        return k * dir
    }
}
