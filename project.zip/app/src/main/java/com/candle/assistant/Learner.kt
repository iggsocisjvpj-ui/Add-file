package com.candle.assistant

import android.content.Context
import kotlin.math.exp

/** يتعلم أوزان المؤشرات من نتائج صفقاتك الفعلية (انحدار لوجستي تدريجي). */
object Learner {
    const val N = 10
    private fun prefs(c: Context) = c.getSharedPreferences("learn", Context.MODE_PRIVATE)

    fun weights(c: Context): DoubleArray {
        val d = DoubleArray(N) { 0.35 }
        val s = prefs(c).getString("w", null)
        if (s != null) {
            val p = s.split(",")
            if (p.size == N) for (i in 0 until N) d[i] = p[i].toDoubleOrNull() ?: 0.35
        }
        return d
    }

    fun bias(c: Context): Double = prefs(c).getFloat("b", 0f).toDouble()

    fun setPending(c: Context, o: Output) {
        prefs(c).edit().putString("pend", o.side.toString() + ";" + o.x.joinToString(",")).apply()
    }

    /** يسجل النتيجة في الإحصاءات، ويتعلم إن كانت هناك صفقة مسجّلة بزر «دخلت». */
    fun record(c: Context, win: Boolean): Boolean {
        val st = c.getSharedPreferences("stats", Context.MODE_PRIVATE)
        val k = if (win) "w" else "l"
        st.edit().putInt(k, st.getInt(k, 0) + 1).apply()
        val pend = prefs(c).getString("pend", null) ?: return false
        val parts = pend.split(";")
        if (parts.size != 2) return false
        val side = parts[0].toIntOrNull() ?: return false
        val x = parts[1].split(",").map { it.toDoubleOrNull() ?: 0.0 }
        if (x.size != N) return false
        val yUp = if (side == 1) win else !win
        val y = if (yUp) 1.0 else 0.0
        val w = weights(c)
        var b = bias(c)
        var z = b
        for (i in 0 until N) z += w[i] * x[i]
        val p = 1 / (1 + exp(-z))
        val g = y - p
        for (i in 0 until N) w[i] = (w[i] + 0.05 * g * x[i]).coerceIn(0.0, 1.2)
        b = (b + 0.02 * g).coerceIn(-0.5, 0.5)
        prefs(c).edit().putString("w", w.joinToString(",")).putFloat("b", b.toFloat()).remove("pend").apply()
        return true
    }

    fun reset(c: Context) {
        prefs(c).edit().clear().apply()
    }
}
