package com.candle.assistant

import android.content.Context
import kotlin.math.exp

/** تعلّم تدريجي لأوزان المؤشرات من صفقاتك المؤكدة ومن الإشارات الافتراضية. */
object Learner {
    const val N = 10
    // 0 اتجاه EMA | 1 ارتداد EMA20 | 2 RSI7 | 3 دايفرجنس | 4 بولنجر | 5 جسم الشمعة | 6 ROC | 7 Z-Score | 8 ستوكاستك | 9 حركة السعر
    private val DEF = doubleArrayOf(0.35, 0.28, 0.30, 0.22, 0.34, 0.26, 0.20, 0.26, 0.28, 0.30)
    private fun prefs(c: Context) = c.getSharedPreferences("learn", Context.MODE_PRIVATE)

    fun weights(c: Context): DoubleArray {
        val d = DEF.copyOf()
        val p = prefs(c).getString("w", null)?.split(",")
        if (p != null && p.size == N) for (i in 0 until N) {
            val v = p[i].toDoubleOrNull()
            if (v != null && v.isFinite()) d[i] = v.coerceIn(-1.2, 1.2)
        }
        return d
    }

    fun bias(c: Context): Double = prefs(c).getFloat("b", 0f).toDouble().coerceIn(-1.0, 1.0)

    fun stat(c: Context, win: Boolean) {
        val st = c.getSharedPreferences("stats", Context.MODE_PRIVATE)
        val k = if (win) "w" else "l"
        st.edit().putInt(k, st.getInt(k, 0) + 1).apply()
    }

    /** خطوة تعلّم: side هو اتجاه الصفقة التي نُفّذت فعلاً، وwin نتيجتها */
    fun learn(c: Context, x: DoubleArray, side: Int, win: Boolean, rate: Double) {
        if (x.size != N || x.any { !it.isFinite() } || x.all { it == 0.0 } || side == 0) return
        val y = if (if (side == 1) win else !win) 1.0 else 0.0
        val w = weights(c)
        var b = bias(c)
        var z = b
        for (i in 0 until N) z += w[i] * x[i]
        z = z.coerceIn(-20.0, 20.0)
        val err = y - 1.0 / (1.0 + exp(-z))
        for (i in 0 until N) w[i] = (w[i] + rate * err * x[i]).coerceIn(-1.2, 1.2)
        b = (b + rate * err).coerceIn(-1.0, 1.0)
        val p = prefs(c)
        p.edit().putString("w", w.joinToString(",")).putFloat("b", b.toFloat())
            .putInt("samples", p.getInt("samples", 0) + 1).apply()
    }

    fun samples(c: Context): Int = prefs(c).getInt("samples", 0)

    fun paper(c: Context, win: Boolean) {
        val s = prefs(c).getString("paper", "") ?: ""
        prefs(c).edit().putString("paper", (s + (if (win) "1" else "0")).takeLast(100)).apply()
    }

    fun paperStats(c: Context): Pair<Int, Double> {
        val s = prefs(c).getString("paper", "") ?: ""
        if (s.isEmpty()) return Pair(0, 0.0)
        return Pair(s.length, s.count { it == '1' }.toDouble() / s.length)
    }

    fun locked(c: Context): Boolean {
        val (n, r) = paperStats(c)
        return n >= 30 && r < 0.52
    }

    fun reset(c: Context) { prefs(c).edit().clear().putInt("ver", 4).apply() }
}
