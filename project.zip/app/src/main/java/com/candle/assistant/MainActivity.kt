package com.candle.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqCapture = 1001
    private lateinit var stats: TextView
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun label(t: String, size: Float = 15f) {
            root.addView(TextView(this).apply { text = t; textSize = size; setPadding(0, 24, 0, 4) })
        }
        fun field(key: String, title: String, def: Int) {
            label(title)
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(p.getInt(key, def).toString())
            }
            fields[key] = e
            root.addView(e)
        }
        fun button(t: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = t; setOnClickListener { action() } })
        }

        label("محلل الشموع", 24f)
        label("افتح الشارت في Pocket Option بوضع الشموع اليابانية، واجعل الشارت يملأ الشاشة. " +
            "حدّد أدناه أين يبدأ الشارت وأين ينتهي (كنسبة من ارتفاع الشاشة) بحيث لا تدخل أزرار شراء/بيع الخضراء والحمراء ضمنه.")
        field("top", "بداية الشارت من أعلى الشاشة %", 12)
        field("bottom", "نهاية الشارت من أعلى الشاشة %", 60)
        field("tf", "مدة الشمعة بالثواني (60 = دقيقة)", 60)
        button("ابدأ التحليل") { start() }
        button("إيقاف") {
            startService(Intent(this, CaptureService::class.java).setAction("STOP"))
        }
        label("سجل نتيجة آخر صفقة لتتبع نسبة الربح:")
        button("ربحت ✔") { record(true) }
        button("خسرت ✘") { record(false) }
        stats = TextView(this).apply { textSize = 16f; setPadding(0, 20, 0, 0) }
        root.addView(stats)
        label("تنبيه: التوصيات تقديرية ولا تضمن ربحاً، والقرار والنقر بيدك. لا تخاطر بما لا تتحمل خسارته، وجرّب بالحساب التجريبي أولاً.", 13f)
        setContentView(ScrollView(this).apply { addView(root) })
        refreshStats()
    }

    private fun start() {
        val ed = getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
        for ((k, e) in fields) ed.putInt(k, e.text.toString().toIntOrNull() ?: 0)
        ed.apply()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» ثم ارجع واضغط ابدأ", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }

    private fun record(win: Boolean) {
        val s = getSharedPreferences("stats", Context.MODE_PRIVATE)
        val k = if (win) "w" else "l"
        s.edit().putInt(k, s.getInt(k, 0) + 1).apply()
        refreshStats()
    }

    private fun refreshStats() {
        val s = getSharedPreferences("stats", Context.MODE_PRIVATE)
        val w = s.getInt("w", 0)
        val l = s.getInt("l", 0)
        val n = w + l
        val rate = if (n == 0) 0 else w * 100 / n
        stats.text = "الصفقات: $n   |   ربح: $w   |   خسارة: $l   |   النسبة: $rate%"
    }
}
