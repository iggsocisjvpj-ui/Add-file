package com.candle.assistant

data class Candle(val open: Double, val close: Double, val high: Double, val low: Double)

/** يستخرج الشموع من بكسلات صورة الشارت. السعر = -y (الأعلى أكبر). */
object CandleReader {
    private fun isGreen(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return g > 140 && r < 120 && g - r > 60 && g - b > 20
    }

    private fun isRed(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return r > 170 && g < 120 && b < 130 && r - g > 80
    }

    fun read(px: IntArray, w: Int, h: Int): List<Candle> {
        val gc = IntArray(w); val gmin = IntArray(w) { Int.MAX_VALUE }; val gmax = IntArray(w) { -1 }
        val rc = IntArray(w); val rmin = IntArray(w) { Int.MAX_VALUE }; val rmax = IntArray(w) { -1 }
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val c = px[row + x]
                if (isGreen(c)) {
                    gc[x]++; if (y < gmin[x]) gmin[x] = y; if (y > gmax[x]) gmax[x] = y
                } else if (isRed(c)) {
                    rc[x]++; if (y < rmin[x]) rmin[x] = y; if (y > rmax[x]) rmax[x] = y
                }
            }
        }
        val kind = IntArray(w)   // 0 لا شيء، 1 أخضر، 2 أحمر
        val mn = IntArray(w); val mx = IntArray(w)
        for (x in 0 until w) {
            if (gc[x] >= 2 && gc[x] >= rc[x]) { kind[x] = 1; mn[x] = gmin[x]; mx[x] = gmax[x] }
            else if (rc[x] >= 2) { kind[x] = 2; mn[x] = rmin[x]; mx[x] = rmax[x] }
        }
        val out = ArrayList<Candle>()
        var x = 0
        while (x < w) {
            if (kind[x] == 0) { x++; continue }
            val k = kind[x]
            var e = x
            while (e + 1 < w && kind[e + 1] == k) e++
            val width = e - x + 1
            if (width >= 3) {
                val mins = (x..e).map { mn[it] }.sorted()
                val maxs = (x..e).map { mx[it] }.sorted()
                val high = mins.first(); val low = maxs.last()
                val bodyTop = mins[mins.size / 2]
                val bodyBottom = maxs[maxs.size / 2]
                if (k == 1) out.add(Candle(-bodyBottom.toDouble(), -bodyTop.toDouble(), -high.toDouble(), -low.toDouble()))
                else out.add(Candle(-bodyTop.toDouble(), -bodyBottom.toDouble(), -high.toDouble(), -low.toDouble()))
            }
            x = e + 1
        }
        return out
    }
}
