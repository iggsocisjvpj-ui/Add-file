package com.candle.assistant

data class Candle(val open: Double, val close: Double, val high: Double, val low: Double)

/** يستخرج الشموع من بكسلات صورة الشارت. السعر = -y (الأعلى أكبر). */
object CandleReader {
    private fun isGreen(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return g > 140 && r < 120 && g - r > 60 && g - b > 20
    }

    private fun isRed(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return r > 170 && g < 120 && b < 130 && r - g > 80
    }

    fun read(px: IntArray, w: Int, h: Int): List<Candle> {
        val gc = IntArray(w); val gmin = IntArray(w) { Int.MAX_VALUE }; val gmax = IntArray(w) { -1 }
        val rc = IntArray(w); val rmin = IntArray(w) { Int.MAX_VALUE }; val rmax = IntArray(w) { -1 }
        val cls = ByteArray(w)
        // أي امتداد أفقي ملوّن أطول من هذا ليس جسم شمعة (شريط النسب، خطوط، أزرار) فيُتجاهل
        val maxRun = maxOf(36, w / 16)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val c = px[row + x]
                cls[x] = if (isGreen(c)) 1 else if (isRed(c)) 2 else 0
            }
            var x = 0
            while (x < w) {
                val k = cls[x].toInt()
                if (k == 0) { x++; continue }
                var e = x
                while (e + 1 < w && cls[e + 1].toInt() == k) e++
                if (e - x + 1 <= maxRun) {
                    for (xx in x..e) {
                        if (k == 1) {
                            gc[xx]++; if (y < gmin[xx]) gmin[xx] = y; if (y > gmax[xx]) gmax[xx] = y
                        } else {
                            rc[xx]++; if (y < rmin[xx]) rmin[xx] = y; if (y > rmax[xx]) rmax[xx] = y
                        }
                    }
                }
                x = e + 1
            }
        }
        val kind = IntArray(w)   // 0 لا شيء، 1 أخضر، 2 أحمر
        val cnt = IntArray(w)
        val mn = IntArray(w); val mx = IntArray(w)
        for (x in 0 until w) {
            if (gc[x] >= 2 && gc[x] >= rc[x]) { kind[x] = 1; mn[x] = gmin[x]; mx[x] = gmax[x]; cnt[x] = gc[x] }
            else if (rc[x] >= 2) { kind[x] = 2; mn[x] = rmin[x]; mx[x] = rmax[x]; cnt[x] = rc[x] }
        }
        val out = ArrayList<Candle>()

        fun emit(k: Int, s: Int, e: Int) {
            if (e - s + 1 < 2) return
            val mins = (s..e).map { mn[it] }.sorted()
            val maxs = (s..e).map { mx[it] }.sorted()
            val high = mins.first(); val low = maxs.last()
            val bodyTop = mins[mins.size / 2]
            val bodyBottom = maxs[maxs.size / 2]
            if (k == 1) out.add(Candle(-bodyBottom.toDouble(), -bodyTop.toDouble(), -high.toDouble(), -low.toDouble()))
            else out.add(Candle(-bodyTop.toDouble(), -bodyBottom.toDouble(), -high.toDouble(), -low.toDouble()))
        }

        var x = 0
        while (x < w) {
            if (kind[x] == 0) { x++; continue }
            val k = kind[x]
            var e = x
            while (e + 1 < w && kind[e + 1] == k) e++
            // شموع متلاصقة بنفس اللون: نقسم العنقود عند "الوادي" (عمود أقل كثافة بوضوح من جيرانه).
            // عمود الفتيل قمة وليس وادياً، فلا ينكسر.
            var start = x
            for (i in (x + 1)..(e - 1)) {
                if (cnt[i] * 2 < cnt[i - 1] && cnt[i] * 2 < cnt[i + 1]) {
                    emit(k, start, i - 1)
                    start = i + 1
                }
            }
            emit(k, start, e)
            x = e + 1
        }
        return out
    }
}
