package com.candle.assistant

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val buffer = CandleBuffer()
    private lateinit var db: AppDatabase

    private lateinit var edtStartY: EditText
    private lateinit var edtEndY: EditText
    private lateinit var edtDuration: EditText
    private lateinit var edtMinConf: EditText
    private lateinit var edtSensitivity: EditText

    private lateinit var txtStats: TextView
    private lateinit var txtSignalStatus: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnReset: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = AppDatabase.getDatabase(this)

        edtStartY = findViewById(R.id.edtStartY)
        edtEndY = findViewById(R.id.edtEndY)
        edtDuration = findViewById(R.id.edtDuration)
        edtMinConf = findViewById(R.id.edtMinConf)
        edtSensitivity = findViewById(R.id.edtSensitivity)

        txtStats = findViewById(R.id.txtStats)
        txtSignalStatus = findViewById(R.id.txtSignalStatus)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnReset = findViewById(R.id.btnReset)

        updateStats()

        btnStart.setOnClickListener {
            val serviceIntent = Intent(this, CaptureService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            txtSignalStatus.text = "جاري التحليل وقراءة الشاشة..."
        }

        btnStop.setOnClickListener {
            val serviceIntent = Intent(this, CaptureService::class.java)
            stopService(serviceIntent)
            txtSignalStatus.text = "تم إيقاف التحليل"
        }

        btnReset.setOnClickListener {
            lifecycleScope.launch {
                updateStats()
            }
        }
    }

    private fun updateStats() {
        lifecycleScope.launch {
            val succ = db.tradeDao().getSuccessCount()
            val fail = db.tradeDao().getFailureCount()
            val total = succ + fail
            val winRate = if (total > 0) (succ.toDouble() / total) * 100 else 0.0
            txtStats.text = "📊 صفقاتك المؤكدة: $total | ربح $succ | خسارة $fail | ${String.format("%.1f", winRate)}%"
        }
    }
}
