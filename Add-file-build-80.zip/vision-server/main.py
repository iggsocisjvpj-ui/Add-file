import base64
import binascii
import os
import re
import secrets
import time
from collections import defaultdict, deque
from typing import Optional

from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field
from google import genai
from google.genai import types

app = FastAPI(title="CANDLE Vision Analysis API", version="1.0.0")

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
# Current stable multimodal Flash model; can be overridden in Render environment variables.
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash").strip()
APP_ACCESS_TOKEN = os.getenv("APP_ACCESS_TOKEN", "").strip()
MAX_IMAGE_BYTES = 8 * 1024 * 1024
RATE_LIMIT = 15
RATE_WINDOW_SECONDS = 60
request_times = defaultdict(deque)


class ChartRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")
    platform: str = Field(default="Chart", max_length=80)
    image_base64: str = Field(min_length=100, max_length=11_200_000)
    quantitative_context: Optional[str] = Field(default=None, max_length=1800)


def _rate_limit(client_ip: str) -> None:
    now = time.time()
    bucket = request_times[client_ip]
    while bucket and now - bucket[0] > RATE_WINDOW_SECONDS:
        bucket.popleft()
    if len(bucket) >= RATE_LIMIT:
        raise HTTPException(status_code=429, detail="تم بلوغ حد الطلبات (15 طلبًا في الدقيقة).")
    bucket.append(now)


def _decode_image(raw: str) -> tuple[bytes, str]:
    mime_type = "image/jpeg"
    if raw.startswith("data:"):
        try:
            header, raw = raw.split(",", 1)
            mime_type = header.split(";")[0].split(":", 1)[1].lower()
        except (ValueError, IndexError):
            raise HTTPException(status_code=400, detail="صيغة صورة Base64 غير صالحة.")
    if mime_type not in ("image/jpeg", "image/png", "image/webp"):
        raise HTTPException(status_code=415, detail="الصيغ المدعومة: JPEG وPNG وWebP.")
    try:
        image_bytes = base64.b64decode(raw, validate=True)
    except (binascii.Error, ValueError):
        raise HTTPException(status_code=400, detail="بيانات الصورة Base64 غير صالحة.")
    if not image_bytes:
        raise HTTPException(status_code=400, detail="الصورة فارغة.")
    if len(image_bytes) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="حجم الصورة أكبر من 8 ميغابايت.")
    return image_bytes, mime_type


def _direction(text: str) -> str:
    match = re.search(r"إشارة\s*(?:التحليل)?\s*[:：-]\s*(BUY|SELL|WAIT)", text, re.IGNORECASE)
    if match:
        return match.group(1).upper()
    upper = text.upper()
    if re.search(r"\bBUY\b", upper) or "شراء" in text:
        return "BUY"
    if re.search(r"\bSELL\b", upper) or "بيع" in text:
        return "SELL"
    return "WAIT"


@app.get("/")
def root():
    return {
        "service": "CANDLE Vision Analysis API",
        "status": "running",
        "analyze_endpoint": "/v1/chart/analyze",
        "health_endpoint": "/health",
    }


@app.get("/health")
def health():
    return {
        "ok": True,
        "service": "CANDLE Vision Analysis API",
        "api_key_configured": bool(GEMINI_API_KEY),
        "app_access_token_configured": len(APP_ACCESS_TOKEN) >= 24,
        "model": GEMINI_MODEL,
    }


@app.post("/v1/chart/analyze")
def analyze_chart(
    payload: ChartRequest,
    request: Request,
    authorization: Optional[str] = Header(default=None),
):
    if len(APP_ACCESS_TOKEN) < 24:
        raise HTTPException(status_code=503, detail="يجب ضبط APP_ACCESS_TOKEN بطول 24 حرفًا على الأقل في Render.")
    supplied = authorization or ""
    prefix = "Bearer "
    if not supplied.startswith(prefix) or not secrets.compare_digest(supplied[len(prefix):].strip(), APP_ACCESS_TOKEN):
        raise HTTPException(status_code=401, detail="رمز حماية الخدمة غير صحيح.")

    client_ip = request.client.host if request.client else "unknown"
    _rate_limit(client_ip)
    if not GEMINI_API_KEY:
        raise HTTPException(status_code=503, detail="مفتاح Gemini غير مضبوط في متغير GEMINI_API_KEY على Render.")

    image_bytes, mime_type = _decode_image(payload.image_base64.strip())
    quantitative_context = (payload.quantitative_context or "").strip()
    prompt = f"""
أنت محلل بصري فني حذر لمنصة CANDLE. حلّل صورة الشارت المرفقة فقط.
المصدر: {payload.platform}

بيانات كمية محلية محسوبة من شموع التطبيق (قد تكون تقديرية):
{quantitative_context or "لا توجد بيانات كمية إضافية."}

أعطِ رأيًا بصريًا مستقلًا، ثم وضّح هل يتفق أو يختلف مع السياق الكمي. لا تعتبر السياق الكمي حجم تداول حقيقيًا.
أجب بالعربية وبالهيكل التالي حرفيًا:
الاتجاه:
إشارة التحليل: BUY أو SELL أو WAIT
قوة التوافق الفني: ضعيفة أو متوسطة أو قوية
بنية السوق:
الشموع والسلوك السعري:
الدعم والمقاومة الظاهران:
المؤشرات الظاهرة فعليًا:
مقارنة الرؤية بالتحليل الكمي:
أسباب القرار:
المخاطر وما الذي يلغي القراءة:

قواعد إلزامية:
- لا تخترع أسعارًا أو قيم مؤشرات أو أحجام تداول غير ظاهرة.
- لا تستنتج Volume Footprint حقيقيًا من صورة OHLC فقط.
- إذا كانت الشموع أو الصورة غير واضحة، اختر WAIT واذكر السبب.
- لا تعرض نسبة نجاح متوقعة ولا تعد بأرباح.
- هذا تحليل فقط ولا تنفذ أوامر تداول.
"""

    try:
        client = genai.Client(api_key=GEMINI_API_KEY)
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=[
                types.Part.from_text(text=prompt),
                types.Part.from_bytes(data=image_bytes, mime_type=mime_type),
            ],
            config=types.GenerateContentConfig(
                temperature=0.2,
                max_output_tokens=1400,
            ),
        )
        analysis = (getattr(response, "text", None) or "").strip()
        if not analysis:
            raise HTTPException(status_code=502, detail="عاد Gemini برد فارغ؛ لم يتم احتساب التحليل ناجحًا.")
        return {
            "ok": True,
            "analysis": analysis,
            "direction": _direction(analysis),
            "model": GEMINI_MODEL,
            "image_bytes": len(image_bytes),
        }
    except HTTPException:
        raise
    except Exception as exc:
        # Do not log image bytes, API keys, or the full request body.
        print(f"Vision request failed: {type(exc).__name__}: {str(exc)[:240]}")
        raise HTTPException(
            status_code=502,
            detail=f"فشل استدعاء نموذج الرؤية ({type(exc).__name__}). راجع سجل خدمة Render ومفتاح Gemini والنموذج.",
        )
