package com.candle.assistant

/** Configuration for the new independent image-vision service. */
object VisionAiConfig {
    // Deliberately blank: the retired Apps Script URL is not reused.
    const val DEFAULT_ENDPOINT = ""
    const val DEFAULT_PLATFORM = "Chart"

    fun normalizeEndpoint(value: String): String {
        val raw = value.trim().trimEnd('/')
        if (raw.isBlank()) return ""
        return if (raw.endsWith("/v1/chart/analyze")) raw else "$raw/v1/chart/analyze"
    }
}
