package com.candle.assistant

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

sealed class VisionAnalysisResult {
    data class Success(val analysis: String, val direction: String, val model: String) : VisionAnalysisResult()
    data class Failure(val message: String) : VisionAnalysisResult()
}

/** HTTPS client for the new Render/FastAPI vision service. Run only on a background thread. */
class VisionAnalysisClient(
    private val endpoint: String,
    private val readTimeoutMs: Int = 90_000,
    private val accessToken: String = ""
) {
    fun analyzeChart(
        imageBytes: ByteArray,
        platform: String,
        quantitativeContext: String = ""
    ): VisionAnalysisResult {
        if (imageBytes.isEmpty()) return VisionAnalysisResult.Failure("الصورة فارغة")
        val parsedUrl = try { URL(VisionAiConfig.normalizeEndpoint(endpoint)) }
        catch (_: Exception) { return VisionAnalysisResult.Failure("عنوان خدمة الرؤية غير صحيح") }
        if (parsedUrl.protocol != "https") {
            return VisionAnalysisResult.Failure("يجب أن يبدأ عنوان الخدمة بـ HTTPS")
        }

        var connection: HttpURLConnection? = null
        return try {
            val payload = JSONObject()
                .put("platform", platform.take(80))
                .put("image_base64", Base64.encodeToString(imageBytes, Base64.NO_WRAP))
                .put("quantitative_context", quantitativeContext.take(1800))
            val body = payload.toString().toByteArray(Charsets.UTF_8)
            connection = (parsedUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = readTimeoutMs
                doOutput = true
                useCaches = false
                setRequestProperty("Connection", "close")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                if (accessToken.isNotBlank()) setRequestProperty("Authorization", "Bearer $accessToken")
                setFixedLengthStreamingMode(body.size)
            }
            connection.outputStream.use { it.write(body) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(responseText) } catch (_: Exception) { null }
            if (code !in 200..299) {
                val detail = json?.optString("detail")?.takeIf { it.isNotBlank() }
                    ?: json?.optString("error")?.takeIf { it.isNotBlank() }
                    ?: responseText.take(180).ifBlank { "لا توجد تفاصيل من الخادم" }
                return VisionAnalysisResult.Failure("الخادم HTTP $code: $detail")
            }
            if (json == null) return VisionAnalysisResult.Failure("الخادم لم يُرجع JSON صالحًا")
            val analysis = json.optString("analysis").trim()
            if (analysis.isBlank()) {
                val detail = json.optString("error").ifBlank { "الرد لا يحتوي على نتيجة تحليل" }
                return VisionAnalysisResult.Failure(detail.take(200))
            }
            VisionAnalysisResult.Success(
                analysis = analysis,
                direction = json.optString("direction", "WAIT").uppercase(java.util.Locale.ROOT),
                model = json.optString("model", "")
            )
        } catch (_: java.net.SocketTimeoutException) {
            VisionAnalysisResult.Failure("انتهت مهلة تحليل الصورة على الخادم")
        } catch (_: java.net.UnknownHostException) {
            VisionAnalysisResult.Failure("تعذر الوصول إلى الخادم؛ تحقق من رابط Render والإنترنت")
        } catch (e: Exception) {
            VisionAnalysisResult.Failure("فشل اتصال الرؤية: ${e.javaClass.simpleName}: ${(e.message ?: "").take(100)}")
        } finally {
            connection?.disconnect()
        }
    }
}
