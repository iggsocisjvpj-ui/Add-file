package com.candle.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

/**
 * سجل الصفقات الموحّد + تحليل أفضل الأوقات (حسب اليوم والساعة).
 * يحفظ لكل صفقة: الزوج، الفاصل، الاتجاه، سعر الدخول، سعر الإغلاق، النتيجة، والوقت.
 * يعرض فقط الأوقات التي فيها عينات كافية، حتى لا تُختار ساعة بناءً على صفقتين.
 */
object TradeHistory {
    private const val PREF = "trade_history"
    private const val MAX_RECORDS = 5000
    val DAY_NAMES = arrayOf("", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")

    data class Rec(
        val t: Long, val pair: String, val tfSec: Int, val side: Int,
        val entry: Double, val exit: Double?, val win: Boolean,
        val exitMs: Long = 0L, val durSec: Int = 0, val src: String = ""
    )

    /** إحصائية خانة واحدة: يوم + ساعة */
    data class Slot(val day: Int, val hour: Int, val n: Int, val wins: Int) {
        val winRate: Double get() = if (n == 0) 0.0 else wins.toDouble() / n
        fun label(): String = "${DAY_NAMES[day]} ${hour.toString().padStart(2, '0')}:00"
    }

    fun add(c: Context, r: Rec) {
        val arr = load(c)
        arr.put(JSONObject()
            .put("t", r.t).put("pair", r.pair).put("tf", r.tfSec).put("side", r.side)
            .put("entry", r.entry).put("exit", r.exit ?: JSONObject.NULL).put("win", r.win)
            .put("exitMs", r.exitMs).put("dur", r.durSec).put("src", r.src))
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - MAX_RECORDS) until arr.length()) trimmed.put(arr.get(i))
        prefs(c).edit().putString("records", trimmed.toString()).apply()
    }

    /**
     * تقرير أداء: هل نسبة الربح تتجاوز نقطة التعادل؟
     * نقطة التعادل = 1 / (1 + نسبة العائد). مع عائد 92% تحتاج أكثر من 52.1% ربحاً لتكسب.
     * نستخدم فاصل ويلسون (95%) لأن العينات الصغيرة تُخدِع.
     */
    fun performanceReport(c: Context, payoutPct: Double = 92.0): String {
        val recs = all(c)
        val n = recs.size
        if (n == 0) return "لا توجد صفقات مسجلة بعد."
        val w = recs.count { it.win }
        val p = w.toDouble() / n
        val z = 1.96
        val denom = 1 + z * z / n
        val center = (p + z * z / (2 * n)) / denom
        val half = z * kotlin.math.sqrt(p * (1 - p) / n + z * z / (4.0 * n * n)) / denom
        val lo = center - half
        val hi = center + half
        val breakeven = 1.0 / (1.0 + payoutPct / 100.0)

        val verdict = when {
            n < 200 -> "العينة صغيرة ($n). تحتاج 200 صفقة على الأقل قبل أي حكم."
            lo > breakeven -> "النتيجة تتجاوز نقطة التعادل بثقة 95%."
            hi < breakeven -> "النتيجة أقل من نقطة التعادل بثقة 95%."
            else -> "لا يوجد دليل كافٍ: المجال يحوي نقطة التعادل."
        }

        val sb = StringBuilder()
        sb.append("عدد الصفقات: $n\n")
        sb.append("الربح: $w (${"%.1f".format(p * 100)}%)\n")
        sb.append("مجال الثقة 95%: ${"%.1f".format(lo * 100)}% إلى ${"%.1f".format(hi * 100)}%\n")
        sb.append("نقطة التعادل مع عائد ${"%.0f".format(payoutPct)}%: ${"%.1f".format(breakeven * 100)}%\n")
        sb.append(verdict).append("\n")

        // تفصيل حسب الفريم والمدة، لكل مجموعة 30 صفقة على الأقل
        val byFrame = recs.groupBy { it.tfSec }
        for ((tf, list) in byFrame.toSortedMap()) {
            if (list.size < 30) continue
            val wf = list.count { it.win }
            sb.append("فريم ${tf}ث: ${list.size} صفقة، ${"%.1f".format(100.0 * wf / list.size)}%\n")
        }
        val byDur = recs.groupBy { it.durSec }
        for ((d, list) in byDur.toSortedMap()) {
            if (list.size < 30 || d <= 0) continue
            val wd = list.count { it.win }
            sb.append("مدة ${d}ث: ${list.size} صفقة، ${"%.1f".format(100.0 * wd / list.size)}%\n")
        }
        return sb.toString().trimEnd()
    }

    private const val SHADOW_PREF = "shadow_signals"

    private fun shadowPrefs(c: Context) = c.getSharedPreferences(SHADOW_PREF, Context.MODE_PRIVATE)

    /** يسجل إشارة مُنعت من الفتح، ليُقاس لاحقاً هل كانت ستخسر فعلاً (لتقييم الذاكرة) */
    fun addShadow(c: Context, pair: String, tfSec: Int, side: Int, entry: Double, openMs: Long, durSec: Int, reason: String) {
        if (!entry.isFinite() || entry <= 0.0) return
        val arr = JSONArray(shadowPrefs(c).getString("pending", "[]") ?: "[]")
        arr.put(JSONObject().put("pair", pair).put("tf", tfSec).put("side", side)
            .put("entry", entry).put("open", openMs).put("dur", durSec).put("reason", reason))
        shadowPrefs(c).edit().putString("pending", arr.toString()).apply()
    }

    /** يحسم الإشارات المنتهية: يقرأ سعر الإغلاق عبر الدالة المعطاة ويحدد الربح أو الخسارة */
    fun resolveShadows(c: Context, nowMs: Long, priceAtMs: (Long) -> Double) {
        val pending = JSONArray(shadowPrefs(c).getString("pending", "[]") ?: "[]")
        if (pending.length() == 0) return
        val results = JSONArray(shadowPrefs(c).getString("results", "[]") ?: "[]")
        val still = JSONArray()
        for (i in 0 until pending.length()) {
            val o = pending.optJSONObject(i) ?: continue
            val endMs = o.optLong("open") + o.optInt("dur") * 1000L
            if (nowMs < endMs + 2000L) { still.put(o); continue }
            val exit = priceAtMs(endMs)
            if (!exit.isFinite()) { still.put(o); continue }
            val side = o.optInt("side")
            val entry = o.optDouble("entry")
            val won = (side == 1 && exit > entry) || (side == -1 && exit < entry)
            results.put(JSONObject().put("pair", o.optString("pair")).put("tf", o.optInt("tf"))
                .put("side", side).put("win", won).put("reason", o.optString("reason")))
        }
        shadowPrefs(c).edit()
            .putString("pending", still.toString())
            .putString("results", results.toString()).apply()
    }

    /** مقارنة: كم كانت ستربح الإشارات المحظورة؟ إن كانت أقل من 50% فالذاكرة تمنع خسائر فعلاً */
    fun shadowReport(c: Context): String {
        val arr = JSONArray(shadowPrefs(c).getString("results", "[]") ?: "[]")
        val n = arr.length()
        if (n == 0) return "لا توجد إشارات محظورة محسومة بعد."
        var w = 0
        for (i in 0 until n) if (arr.optJSONObject(i)?.optBoolean("win") == true) w++
        val p = 100.0 * w / n
        val verdict = when {
            n < 50 -> "العينة صغيرة ($n). تحتاج 50 على الأقل."
            p < 45.0 -> "الذاكرة تمنع إشارات كانت ستخسر (نسبتها $p%)."
            p > 55.0 -> "الذاكرة تمنع إشارات كانت ستربح، وهذا يعني أنها تضر."
            else -> "الإشارات المحظورة لم تكن أفضل ولا أسوأ من المعدل."
        }
        return "إشارات محظورة محسومة: $n، كانت ستربح منها ${"%.1f".format(p)}%.\n$verdict"
    }

    /** يستبدل التقدير بالقيم المؤكدة من المنصة لصفقة مطابقة بالزوج ووقت الفتح (فارق حتى 5 ثوانٍ) */
    fun applyPlatform(c: Context, pair: String, openMs: Long, openPx: Double, closePx: Double, closeMs: Long): Boolean {
        val arr = load(c)
        val target = pair.replace("OTC", "").replace(" ", "").trim()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val recPair = o.optString("pair").replace("OTC", "").replace(" ", "").trim()
            if (recPair != target) continue
            if (kotlin.math.abs(o.optLong("t") - openMs) > 5000L) continue
            o.put("entry", openPx)
            o.put("exit", closePx)
            o.put("exitMs", closeMs)
            o.put("src", "platform")
            prefs(c).edit().putString("records", arr.toString()).apply()
            return true
        }
        return false
    }

    /** يغيّر النتيجة فقط لصفقة مسجلة (دون لمس الأسعار) */
    fun setWin(c: Context, pair: String, exitMs: Long, win: Boolean): Boolean {
        val arr = load(c)
        var changed = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("pair") == pair && o.optLong("exitMs", 0L) == exitMs) {
                o.put("win", win)
                changed = true
            }
        }
        if (changed) prefs(c).edit().putString("records", arr.toString()).apply()
        return changed
    }

    /** يضيف الصفقة أو يحدّثها إن كانت مسجلة بنفس الزوج ووقت الخروج (لتفادي التكرار) */
    fun upsert(c: Context, r: Rec) {
        val arr = load(c)
        val kept = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val same = o.optString("pair") == r.pair && o.optLong("exitMs", 0L) == r.exitMs && r.exitMs > 0L
            if (!same) kept.put(o)
        }
        prefs(c).edit().putString("records", kept.toString()).apply()
        add(c, r)
    }

    /** وسيط أسعار الدخول، مرجع لكشف القيم غير المنطقية */
    private fun medianEntry(list: List<Rec>): Double {
        val v = list.map { it.entry }.filter { it.isFinite() && it > 0.0 }.sorted()
        return if (v.isEmpty()) 0.0 else v[v.size / 2]
    }

    /** true إن كان السعر غير منطقي مقارنة بالوسيط (سالب، صفر، أو يبعد أكثر من 2%) */
    fun isSuspicious(v: Double?, median: Double): Boolean {
        if (v == null || !v.isFinite() || v <= 0.0) return true
        if (median <= 0.0) return false
        return kotlin.math.abs(v - median) / median > 0.02
    }

    /**
     * يطابق صفقات السجل مع تفاصيل من المنصة (نفس الزوج والاتجاه، وفرق الوقت حتى 3 ثوانٍ بتوقيت UTC)،
     * ويستبدل أسعار التقدير بأسعار المنصة الدقيقة. يرجع عدد الصفقات المحدّثة.
     */
    fun applyPlatform(c: Context, pairBase: String, side: Int, openSecUtc: Double, entry: Double, exit: Double): Int {
        val arr = load(c)
        var count = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val base = o.optString("pair").replace(" OTC", "").trim()
            if (base != pairBase || o.optInt("side") != side) continue
            val sodUtc = ((o.optLong("t") / 1000L) % 86400L).toDouble()
            if (kotlin.math.abs(sodUtc - openSecUtc) <= 3.0) {
                o.put("entry", entry)
                o.put("exit", exit)
                o.put("src", "platform")
                count++
            }
        }
        if (count > 0) prefs(c).edit().putString("records", arr.toString()).apply()
        return count
    }

    /** نص قابل للقراءة لآخر الصفقات: الدخول والخروج بالوقت والسعر */
    fun lastText(c: Context, limit: Int = 80): String {
        val fmt = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val all = all(c)
        val median = medianEntry(all)
        val list = all.sortedByDescending { it.t }.take(limit)
        if (list.isEmpty()) return "لا توجد صفقات مسجلة بعد."
        return list.joinToString("\n\n") { r ->
            val res = if (r.win) "✔ ربح" else "✘ خسارة"
            val exitTxt = if (r.exitMs > 0) fmt.format(java.util.Date(r.exitMs)) else "-"
            val sideTxt = if (r.side > 0) "شراء" else "بيع"
            "${r.pair} | فريم ${r.tfSec}ث | مدة ${r.durSec}ث | $sideTxt | $res\n" +
            "  دخول: ${fmt.format(java.util.Date(r.t))} بسعر ${r.entry} ${qual(r.entry, median, r.src)}\n" +
            "  خروج: $exitTxt بسعر ${r.exit ?: "غير معروف"} ${qual(r.exit, median, r.src)}"
        }
    }

    /**
     * حدود الحماية: يمنع فتح صفقات جديدة عند تجاوز حد خسائر اليوم، أو عند سلسلة خسائر متتالية.
     * الحدود تُقاس بعدد الصفقات (لا بالمبالغ، لأن المبالغ غير مسجلة هنا).
     * سلسلة الخسائر تنتهي بأول ربح، وحد اليوم يُصفَّر مع بداية يوم جديد.
     * يرجع null إن كان التداول مسموحاً، أو سبب المنع.
     */
    fun limitReason(c: Context, tz: TimeZone = TimeZone.getDefault()): String? {
        val cfg = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val maxDay = cfg.getInt("maxDayLosses", 5)
        val maxConsec = cfg.getInt("maxConsecLosses", 3)
        val recs = all(c, tz).sortedBy { it.t }

        val cal = Calendar.getInstance(tz)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val dayStart = cal.timeInMillis

        val dayLosses = recs.count { it.t >= dayStart && !it.win }
        if (maxDay > 0 && dayLosses >= maxDay) {
            return "تم إيقاف التداول: وصلت $dayLosses خسائر اليوم (الحد $maxDay)."
        }

        var consec = 0
        for (r in recs.asReversed()) {
            if (r.win) break
            consec++
        }
        if (maxConsec > 0 && consec >= maxConsec) {
            return "تم إيقاف التداول: $consec خسائر متتالية (الحد $maxConsec). يتوقف حتى تحقق ربحاً."
        }
        return null
    }

    private fun qual(v: Double?, median: Double, src: String = ""): String =
        if (src == "platform") "(مؤكد من المنصة)" else if (isSuspicious(v, median)) "(مشكوك، لا يُعتمد)" else "(تقديري)"

    fun all(c: Context, tz: TimeZone = TimeZone.getDefault()): List<Rec> {
        val arr = load(c)
        val out = ArrayList<Rec>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Rec(
                t = o.optLong("t"),
                pair = o.optString("pair"),
                tfSec = o.optInt("tf"),
                side = o.optInt("side"),
                entry = o.optDouble("entry", Double.NaN),
                exit = if (o.isNull("exit")) null else o.optDouble("exit", Double.NaN),
                win = o.optBoolean("win"),
                exitMs = o.optLong("exitMs", 0L),
                durSec = o.optInt("dur", 0),
                src = o.optString("src", "")
            ))
        }
        return out
    }

    /** إحصائيات يوم/ساعة مع فلتر اختياري للزوج والفاصل */
    fun slots(
        c: Context, pair: String? = null, tfSec: Int? = null,
        tz: TimeZone = TimeZone.getDefault()
    ): List<Slot> {
        val map = HashMap<Pair<Int, Int>, IntArray>()   // (day,hour) -> [n, wins]
        val cal = Calendar.getInstance(tz)
        for (r in all(c)) {
            if (pair != null && r.pair != pair) continue
            if (tfSec != null && r.tfSec != tfSec) continue
            cal.timeInMillis = r.t
            val key = cal.get(Calendar.DAY_OF_WEEK) to cal.get(Calendar.HOUR_OF_DAY)
            val a = map.getOrPut(key) { IntArray(2) }
            a[0]++
            if (r.win) a[1]++
        }
        return map.map { (k, a) -> Slot(k.first, k.second, a[0], a[1]) }
    }

    /** أفضل الأوقات: فقط الخانات التي فيها عدد صفقات لا يقل عن minTrades */
    fun bestSlots(
        c: Context, minTrades: Int = 20, top: Int = 5,
        pair: String? = null, tfSec: Int? = null
    ): List<Slot> =
        slots(c, pair, tfSec)
            .filter { it.n >= minTrades }
            .sortedWith(compareByDescending<Slot> { it.winRate }.thenByDescending { it.n })
            .take(top)

    /** محرك البحث: يعيد ملخصاً نصياً لليوم والساعة المطلوبة (أو لليوم كاملاً) */
    fun search(
        c: Context, day: Int? = null, hour: Int? = null,
        pair: String? = null, tfSec: Int? = null, minTrades: Int = 1
    ): String {
        val list = slots(c, pair, tfSec).filter {
            (day == null || it.day == day) && (hour == null || it.hour == hour) && it.n >= minTrades
        }
        if (list.isEmpty()) return "لا توجد صفقات مطابقة لهذا البحث بعد."
        val n = list.sumOf { it.n }
        val w = list.sumOf { it.wins }
        val head = "المطابق: $n صفقة، ربح $w، نسبة ${"%.1f".format(100.0 * w / n)}%"
        val rows = list.sortedWith(compareBy<Slot> { it.day }.thenBy { it.hour })
            .joinToString("\n") { "${it.label()}: ${it.n} صفقة، ${"%.0f".format(100 * it.winRate)}%" }
        return "$head\n$rows"
    }

    fun reset(c: Context) { prefs(c).edit().clear().apply() }

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun load(c: Context): JSONArray =
        try { JSONArray(prefs(c).getString("records", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    /** تصدير كل الصفقات كنص CSV: وقت الدخول والسعر، ووقت الخروج والسعر، والنتيجة */
    fun exportCsv(c: Context, tz: TimeZone = TimeZone.getDefault()): String {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).apply { timeZone = tz }
        val sb = StringBuilder("entry_time,entry_price,exit_time,exit_price,pair,tf_sec,duration_sec,side,result,price_quality\n")
        val recs = all(c, tz)
        val median = medianEntry(recs)
        for (r in recs) {
            val entryTime = fmt.format(java.util.Date(r.t))
            val exitTime = if (r.exitMs > 0) fmt.format(java.util.Date(r.exitMs)) else ""
            sb.append(entryTime).append(',').append(r.entry).append(',')
              .append(exitTime).append(',').append(r.exit ?: "").append(',')
              .append(r.pair).append(',').append(r.tfSec).append(',').append(r.durSec).append(',')
              .append(if (r.side > 0) "BUY" else "SELL").append(',')
              .append(if (r.win) "WIN" else "LOSS").append(',')
              .append(if (isSuspicious(r.entry, median) || isSuspicious(r.exit, median)) "suspicious" else "estimated")
              .append('\n')
        }
        return sb.toString()
    }
}
