package com.candle.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqCapture = 1001
    private lateinit var stats: TextView
    private lateinit var autoStat: TextView
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        val lv = getSharedPreferences("learn", Context.MODE_PRIVATE)
        if (lv.getInt("ver", 0) != Learner.VER) lv.edit().clear().putInt("ver", Learner.VER).apply()
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        // Safety baseline: automatic trading remains disabled until platform/account verification is redesigned.
        p.edit().putInt("auto", 0).apply()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun label(t: String, size: Float = 15f) {
            root.addView(TextView(this).apply { text = t; textSize = size; setPadding(0, 24, 0, 4) })
        }
        fun field(key: String, title: String, def: Int) {
            label(title)
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(p.getInt(key, def).toString())
            }
            fields[key] = e
            root.addView(e)
        }
        fun button(t: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = t; setOnClickListener { action() } })
        }

        label("محلل الشموع المتقدم", 24f)
        label("افتح الشارت في Pocket Option بالشموع اليابانية (تكفي نحو 30 شمعة ظاهرة؛ يبني التطبيق سجلاً متحركاً أطول تدريجياً مع تحرك الشارت). " +
            "حدّد أين يبدأ الشارت وأين ينتهي (كنسبة من ارتفاع الشاشة) بحيث لا تدخل أزرار شراء/بيع ضمنه. مدة الصفقة = شمعة واحدة، فاضبط مدة الشمعة بدقة.")
        field("top", "بداية الشارت من أعلى الشاشة %", 12)
        field("bottom", "نهاية الشارت من أعلى الشاشة %", 60)
        field("tf", "مدة الشمعة بالثواني (60 = دقيقة)", 60)
        field("conf", "الحد الأدنى للثقة % (50 إلى 95)", 58)
        field("sens", "الحساسية (1 صارم وبطيء، 5 حساس وسريع)", 3)
        field("dur", "مدة الصفقة في المنصة بالثواني (اجعلها مثل مدة الشمعة)", 60)
        field("payout", "عائد المنصة % (يظهر بجانب زر الشراء)", 85)
        label("التداول التلقائي: متوقف مؤقتًا للحماية", 18f)
        label("التحليل والإشارات يعملان، لكن النقر التلقائي معطّل مؤقتًا. التحقق من Demo عبر نص الشاشة وحده لا يضمن أن الحساب تجريبي، كما تختلف واجهات المنصات. سنعيد تقييم هذه الوظيفة بعد بناء تحقق خاص بكل منصة واختباره بأمان.", 13f)
        button("1) فتح إعدادات إمكانية الوصول لتفعيل الخدمة") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2) ضبط موضع زري الشراء والبيع") {
            val svc = TapService.instance
            if (svc != null) svc.calibrate()
            else Toast.makeText(this, "فعّل خدمة «محلل الشموع - نقر تجريبي» أولاً", Toast.LENGTH_LONG).show()
        }
        button("3) التداول التلقائي (متوقف للحماية)") {
            getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putInt("auto", 0).apply()
            Toast.makeText(this, "التداول التلقائي متوقف في هذه النسخة؛ التحليل اليدوي ما زال يعمل", Toast.LENGTH_LONG).show()
            refreshStats()
        }
        autoStat = TextView(this).apply { textSize = 14f; setPadding(0, 8, 0, 8); text = "التداول التلقائي متوقف للحماية" }
        root.addView(autoStat)
        button("ابدأ التحليل") { start() }
        button("إيقاف التحليل") {
            stopService(Intent(this, CaptureService::class.java))
            Toast.makeText(this, "تم الإيقاف", Toast.LENGTH_SHORT).show()
        }
        button("تصفير الإحصاءات والتعلم") {
            Learner.reset(this)
            getSharedPreferences("stats", Context.MODE_PRIVATE).edit().clear().apply()
            refreshStats()
        }
        stats = TextView(this).apply { textSize = 16f; setPadding(0, 20, 0, 0) }
        root.addView(stats)
        label("طريقة العمل: الحالات 🟢 شراء، 🔴 بيع، 🟡 انتظار (المؤشرات متعارضة)، ⚪ لا تدخل (بيانات غير كافية أو غير موثوقة). تظهر الإشارة في أول ثوانٍ من الشمعة الجديدة مع وقت الدخول والمدة وأسبابها. نفّذ الصفقة في المنصة بمدة شمعة، ثم اضغط في النافذة العائمة «دخلت شراء» أو «دخلت بيع» حسب ما نفّذت. يتوقف التحليل حتى تنتهي الصفقة، ثم يقدّر التطبيق الربح أو الخسارة ويعرضها لتؤكدها أو تصححها، ويتعلم منها تلقائياً. ضع النافذة بعيداً عن الشارت (الافتراضي أسفل الشاشة).", 13f)
        label("تنبيه: الثقة المعروضة درجة تقديرية من النموذج وليست احتمالاً مضموناً. لا يوجد نظام يضمن نسبة ربح، والقرار والنقر بيدك. " +
            "جرّب بالحساب التجريبي وراقب النسبة الفعلية لـ 50 صفقة على الأقل قبل أي مال حقيقي.", 13f)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStats()
    }

    private fun toggleAuto() {
        val cfg = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (cfg.getInt("auto", 0) == 1) {
            cfg.edit().putInt("auto", 0).apply()
            Toast.makeText(this, "أُوقف التداول التلقائي", Toast.LENGTH_SHORT).show()
            refreshStats()
            return
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("تأكيد: حساب تجريبي فقط")
            .setMessage("سينقر التطبيق على زري الشراء والبيع تلقائياً. فعّله فقط وأنت على الحساب التجريبي، وسيرفض العمل إن لم تظهر كلمة Demo على الشاشة. هل أنت الآن على حساب تجريبي؟")
            .setPositiveButton("نعم، حساب تجريبي") { _, _ ->
                cfg.edit().putInt("auto", 1).apply()
                refreshStats()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun start() {
        val ed = getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
        for ((k, e) in fields) ed.putInt(k, e.text.toString().toIntOrNull() ?: 0)
        ed.apply()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» ثم ارجع واضغط ابدأ", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }

    private fun refreshStats() {
        val cfg0 = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        autoStat.text = "التداول التلقائي: " + (if (cfg0.getInt("auto", 0) == 1) "🟢 مفعّل (تجريبي)" else "⚪ متوقف") +
            " | الخدمة: " + (if (TapService.instance != null) "تعمل" else "غير مفعّلة") +
            " | الأزرار: " + (if (cfg0.getInt("buyX", 0) > 0 && cfg0.getInt("sellX", 0) > 0) "مضبوطة" else "غير مضبوطة")
        val s = getSharedPreferences("stats", Context.MODE_PRIVATE)
        val w = s.getInt("w", 0)
        val l = s.getInt("l", 0)
        val n = w + l
        val rate = if (n == 0) 0 else w * 100 / n
        val ps = Learner.paperStats(this)
        stats.text = "صفقاتك المؤكدة: $n | ربح $w | خسارة $l | $rate%\n" +
            "الإشارات الافتراضية: ${ps.first} | النجاح ${(ps.second * 100).toInt()}%\n" +
            "عينات التعلم: ${Learner.samples(this)}" + (if (Learner.locked(this, 1.0 / (1.0 + getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("payout", 85) / 100.0))) "\n⛔ قفل الأمان مفعّل (نجاح الإشارات دون نقطة التعادل)" else "") +
            Learner.keyReport(this).let { if (it.isEmpty()) "" else "\nحسب الفاصل وحالة السوق (إشارات افتراضية):\n$it" }
    }
}
