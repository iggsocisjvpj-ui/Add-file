package com.candle.assistant

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * عميل سحابي لـ Google Apps Script / خادم HTTPS.
 * POST: { "platform": "...", "image_base64": "..." }
 * الرد: { "ok": true, "analysis": "..." } أو { "ok": false, "error": "..." }
 * يجب استدعاؤه من خيط خلفي.
 */
class CloudAiClient(
    private val backendUrl: String,
    private val bearerToken: String? = null,
    private val readTimeoutMs: Int = 90_000
) {
    @Volatile private var stage = "الإرسال"

    fun analyzeChart(imageBytes: ByteArray, platform: String): CloudAnalysisResult {
        var r = attempt(imageBytes, platform)
        if (r is CloudAnalysisResult.Failure && r.message.startsWith("TRANSIENT:")) {
            try { Thread.sleep(1500) } catch (_: InterruptedException) {}
            r = attempt(imageBytes, platform)
        }
        return if (r is CloudAnalysisResult.Failure && r.message.startsWith("TRANSIENT:"))
            CloudAnalysisResult.Failure(r.message.removePrefix("TRANSIENT:")) else r
    }

    private fun attempt(imageBytes: ByteArray, platform: String): CloudAnalysisResult {
        stage = "الإرسال"
        if (imageBytes.isEmpty()) return CloudAnalysisResult.Failure("الصورة فارغة")
        if (backendUrl.isBlank()) return CloudAnalysisResult.Failure("الخدمة السحابية غير مهيأة بعد")
        val url = try { URL(backendUrl) } catch (_: Exception) {
            return CloudAnalysisResult.Failure("عنوان الخادم غير صحيح")
        }
        if (url.protocol != "https") {
            return CloudAnalysisResult.Failure("يجب استخدام HTTPS لحماية الصور والبيانات")
        }

        var connection: HttpURLConnection? = null
        return try {
            val payload = JSONObject()
                .put("platform", platform.take(80))
                .put("image_base64", Base64.encodeToString(imageBytes, Base64.NO_WRAP))
            var conn: HttpURLConnection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                instanceFollowRedirects = false
                connectTimeout = 15_000
                readTimeout = readTimeoutMs
                doOutput = true
                setRequestProperty("Connection", "close")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                bearerToken?.takeIf { it.isNotBlank() }?.let {
                    setRequestProperty("Authorization", "Bearer $it")
                }
            }
            connection = conn
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            var code = conn.responseCode
            // Apps Script ينفذ POST ثم يعيد 302 إلى رابط النتيجة؛ نتبعه بـ GET (https فقط).
            var hops = 0
            while (code in 301..303 && hops < 3) {
                val location = conn.getHeaderField("Location")
                if (location.isNullOrBlank()) break
                val next = URL(url, location)
                if (next.protocol != "https") {
                    return CloudAnalysisResult.Failure("إعادة توجيه غير آمنة")
                }
                stage = "جلب النتيجة"
                conn.disconnect()
                conn = (next.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    instanceFollowRedirects = false
                    connectTimeout = 15_000
                    readTimeout = 30_000
                    setRequestProperty("Connection", "close")
                    setRequestProperty("Accept", "application/json")
                }
                connection = conn
                code = conn.responseCode
                hops++
            }
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                return CloudAnalysisResult.Failure("الخادم أعاد الخطأ HTTP $code")
            }
            val trimmed = body.trim()
            if (!trimmed.startsWith("{")) {
                // صفحة HTML = غالبًا نشر Apps Script غير مضبوط على "أي شخص" أو خطأ في السكربت
                return CloudAnalysisResult.Failure(
                    "الخادم لم يُرجع JSON (تحقق من النشر: الوصول = أي شخص، وأنشئ إصدارًا جديدًا)"
                )
            }
            val json = JSONObject(trimmed)
            val analysis = json.optString("analysis").trim()
            if (analysis.isNotEmpty()) {
                CloudAnalysisResult.Success(analysis)
            } else {
                val err = json.optString("error").trim()
                CloudAnalysisResult.Failure(
                    if (err.isNotEmpty()) "خطأ من الخادم: ${err.take(200)}"
                    else "استجابة الخادم لا تحتوي على analysis"
                )
            }
        } catch (_: java.net.SocketTimeoutException) {
            CloudAnalysisResult.Failure("انتهت مهلة الاتصال بالخدمة السحابية (${readTimeoutMs / 1000}ث)")
        } catch (_: java.net.UnknownHostException) {
            CloudAnalysisResult.Failure("لا يوجد اتصال بالإنترنت")
        } catch (e: java.io.IOException) {
            CloudAnalysisResult.Failure("TRANSIENT:انقطع الاتصال أثناء $stage: ${(e.message ?: e.javaClass.simpleName).take(120)}")
        } catch (e: Exception) {
            CloudAnalysisResult.Failure("تعذر الاتصال بالخدمة السحابية (${e.javaClass.simpleName}: ${(e.message ?: "").take(100)})")
        } finally {
            connection?.disconnect()
        }
    }
}
