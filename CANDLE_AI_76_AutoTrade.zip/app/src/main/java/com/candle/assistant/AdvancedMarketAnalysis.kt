package com.candle.assistant

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Advanced indicators and footprint aggregation. No order execution is performed. */
object AdvancedMarketAnalysis {
    data class FractalPoint(val index: Int, val price: Double, val isHigh: Boolean)
    data class TrendPoint(val index: Int, val value: Double, val direction: Int)
    data class LevelFlow(
        val price: Double,
        val buy: Double,
        val sell: Double,
        val delta: Double
    )
    enum class DataQuality { REAL_TRADE_DATA, ESTIMATED_FROM_OHLC }
    data class Footprint(
        val quality: DataQuality,
        val levels: List<LevelFlow>,
        val poc: Double?,
        val totalBuy: Double,
        val totalSell: Double,
        val delta: Double,
        val note: String
    )

    /** Confirmed 5-bar fractals: the two bars to the right must already be closed. */
    fun fractals(c: List<Candle>, wing: Int = 2): List<FractalPoint> {
        if (wing < 1 || c.size < wing * 2 + 1) return emptyList()
        val out = ArrayList<FractalPoint>()
        for (i in wing until c.size - wing) {
            val x = c[i]
            var high = true
            var low = true
            for (j in i - wing..i + wing) if (j != i) {
                if (c[j].high >= x.high) high = false
                if (c[j].low <= x.low) low = false
            }
            if (high) out.add(FractalPoint(i, x.high, true))
            if (low) out.add(FractalPoint(i, x.low, false))
        }
        return out
    }

    /** Wilder ATR based Supertrend. direction: +1 bullish, -1 bearish. */
    fun supertrend(c: List<Candle>, period: Int = 10, multiplier: Double = 3.0): List<TrendPoint> {
        if (period < 1 || c.size < period + 2) return emptyList()
        val n = c.size
        val tr = DoubleArray(n)
        for (i in 1 until n) {
            val prev = c[i - 1].close
            tr[i] = max(c[i].high - c[i].low, max(abs(c[i].high - prev), abs(c[i].low - prev)))
        }
        val atr = DoubleArray(n)
        var seed = 0.0
        for (i in 1..period) seed += tr[i]
        atr[period] = seed / period
        for (i in period + 1 until n) atr[i] = (atr[i - 1] * (period - 1) + tr[i]) / period

        val upper = DoubleArray(n)
        val lower = DoubleArray(n)
        val finalUpper = DoubleArray(n)
        val finalLower = DoubleArray(n)
        val dir = IntArray(n) { 1 }
        val line = DoubleArray(n)
        for (i in period until n) {
            val mid = (c[i].high + c[i].low) / 2.0
            upper[i] = mid + multiplier * atr[i]
            lower[i] = mid - multiplier * atr[i]
            if (i == period) {
                finalUpper[i] = upper[i]
                finalLower[i] = lower[i]
                dir[i] = if (c[i].close >= mid) 1 else -1
            } else {
                finalUpper[i] = if (upper[i] < finalUpper[i - 1] || c[i - 1].close > finalUpper[i - 1]) upper[i] else finalUpper[i - 1]
                finalLower[i] = if (lower[i] > finalLower[i - 1] || c[i - 1].close < finalLower[i - 1]) lower[i] else finalLower[i - 1]
                dir[i] = when {
                    dir[i - 1] < 0 && c[i].close > finalUpper[i] -> 1
                    dir[i - 1] > 0 && c[i].close < finalLower[i] -> -1
                    else -> dir[i - 1]
                }
            }
            line[i] = if (dir[i] > 0) finalLower[i] else finalUpper[i]
        }
        return (period until n).map { TrendPoint(it, line[it], dir[it]) }
    }

    /** A real print must carry aggressor side from the exchange/feed; do not infer it silently. */
    data class TradePrint(val price: Double, val quantity: Double, val aggressor: Aggressor)
    enum class Aggressor { BUY, SELL, UNKNOWN }

    fun fromRealTrades(trades: List<TradePrint>, tickSize: Double): Footprint {
        require(tickSize > 0.0 && tickSize.isFinite()) { "tickSize must be positive" }
        val bins = sortedMapOf<Double, MutableList<Double>>()
        for (t in trades) {
            if (!t.price.isFinite() || !t.quantity.isFinite() || t.quantity <= 0.0 || t.aggressor == Aggressor.UNKNOWN) continue
            val level = kotlin.math.round(t.price / tickSize) * tickSize
            val v = bins.getOrPut(level) { mutableListOf(0.0, 0.0) }
            if (t.aggressor == Aggressor.BUY) v[0] += t.quantity else v[1] += t.quantity
        }
        val levels = bins.map { (p, v) -> LevelFlow(p, v[0], v[1], v[0] - v[1]) }
        val buy = levels.sumOf { it.buy }; val sell = levels.sumOf { it.sell }
        val poc = levels.maxByOrNull { it.buy + it.sell }?.price
        return Footprint(DataQuality.REAL_TRADE_DATA, levels, poc, buy, sell, buy - sell,
            "بيانات صفقات فعلية مصنفة حسب الطرف المبادر؛ قد تختلف النتيجة حسب مزود البيانات.")
    }

    /**
     * OHLC has no traded volume. This creates a clearly-labelled price-pressure proxy,
     * NOT volume, by distributing candle body/wick weights across price bins.
     */
    fun estimatedFromCandles(candles: List<Candle>, tickSize: Double, maxLevels: Int = 80): Footprint {
        require(tickSize > 0.0 && tickSize.isFinite()) { "tickSize must be positive" }
        val bins = sortedMapOf<Double, MutableList<Double>>()
        for (c in candles) {
            val lo = min(c.low, c.high); val hi = max(c.low, c.high)
            if (!lo.isFinite() || !hi.isFinite() || hi - lo <= 1e-9) continue
            val first = kotlin.math.floor(lo / tickSize).toInt()
            val last = kotlin.math.floor(hi / tickSize).toInt()
            val count = (last - first + 1).coerceAtMost(maxLevels).coerceAtLeast(1)
            val bullish = c.close >= c.open
            val bodyLo = min(c.open, c.close); val bodyHi = max(c.open, c.close)
            for (k in 0 until count) {
                val p = (first + k) * tickSize
                val center = p + tickSize / 2.0
                val inBody = center >= bodyLo && center <= bodyHi
                val weight = if (inBody) 2.0 else 0.5
                val v = bins.getOrPut(p) { mutableListOf(0.0, 0.0) }
                if (bullish) v[0] += weight else v[1] += weight
            }
        }
        val levels = bins.map { (p, v) -> LevelFlow(p, v[0], v[1], v[0] - v[1]) }
        val buy = levels.sumOf { it.buy }; val sell = levels.sumOf { it.sell }
        val poc = levels.maxByOrNull { it.buy + it.sell }?.price
        return Footprint(DataQuality.ESTIMATED_FROM_OHLC, levels, poc, buy, sell, buy - sell,
            "تقدير لضغط السعر من OHLC فقط، وليس حجم تداول أو Bid/Ask حقيقيًا. لا تستخدمه كبيانات حجم فعلية.")
    }


    data class CandleRow(
        val index: Int, val open: Double, val high: Double, val low: Double, val close: Double,
        val bodyPct: Int, val upperWickPct: Int, val lowerWickPct: Int,
        val volProxy: Double, val buyEst: Double, val sellEst: Double,
        val delta: Double, val cumDelta: Double
    )

    /**
     * يحوّل كل شمعة إلى أرقام. الحجم هنا مؤشر نشاط نسبي (مدى الشمعة ÷ متوسط المدى) وليس حجم تداول فعليًا،
     * وتقسيم الشراء/البيع تقدير من موقع الإغلاق داخل الشمعة.
     */
    fun candleRows(candles: List<Candle>): List<CandleRow> {
        if (candles.isEmpty()) return emptyList()
        val ranges = candles.map { max(it.high - it.low, 0.0) }.filter { it > 1e-9 }
        val avgRange = if (ranges.isEmpty()) 1.0 else ranges.average()
        var cum = 0.0
        val out = ArrayList<CandleRow>(candles.size)
        for ((i, c) in candles.withIndex()) {
            val range = max(c.high - c.low, 1e-9)
            val body = abs(c.close - c.open)
            val upper = c.high - max(c.open, c.close)
            val lower = min(c.open, c.close) - c.low
            val vol = range / avgRange
            val clv = ((c.close - c.low) / range).coerceIn(0.0, 1.0)
            val buyShare = (0.7 * clv + 0.3 * (if (c.close >= c.open) 1.0 else 0.0)).coerceIn(0.0, 1.0)
            val buy = vol * buyShare
            val sell = vol - buy
            val delta = buy - sell
            cum += delta
            out.add(CandleRow(i, c.open, c.high, c.low, c.close,
                (body / range * 100).toInt().coerceIn(0, 100),
                (upper / range * 100).toInt().coerceIn(0, 100),
                (lower / range * 100).toInt().coerceIn(0, 100),
                vol, buy, sell, delta, cum))
        }
        return out
    }

    /**
     * درجة ضغط من -1 (بيع) إلى +1 (شراء) من آخر شموع: Delta التقديري، ومع تعارضه مع حركة السعر
     * يُعد تباعدًا (سعر يصعد وDelta سالب = سلبي، والعكس).
     */
    fun pressureScore(candles: List<Candle>, lookback: Int = 8): Double {
        if (candles.size < lookback + 2) return 0.0
        val rows = candleRows(candles).takeLast(lookback)
        val vol = rows.sumOf { it.volProxy }.coerceAtLeast(1e-9)
        val dNorm = rows.sumOf { it.delta } / vol
        val move = rows.last().close - rows.first().open
        val priceDir = if (move > 0) 1.0 else if (move < 0) -1.0 else 0.0
        val dDir = if (dNorm > 0) 1.0 else if (dNorm < 0) -1.0 else 0.0
        val s = if (priceDir != 0.0 && dDir * priceDir < 0 && abs(dNorm) > 0.15) -priceDir * 0.5
                else kotlin.math.tanh(dNorm * 2.0) * 0.8
        return s.coerceIn(-1.0, 1.0)
    }

    fun rowsText(candles: List<Candle>, last: Int = 10): String {
        val f = { d: Double -> String.format(java.util.Locale.US, "%+.2f", d) }
        return candleRows(candles).takeLast(last).joinToString("\n") { r ->
            val dir = if (r.close >= r.open) "▲" else "▼"
            "#${r.index + 1} $dir جسم ${r.bodyPct}% | ظل علوي ${r.upperWickPct}% | سفلي ${r.lowerWickPct}%\n" +
            "   نشاط ${String.format(java.util.Locale.US, "%.2f", r.volProxy)} | شراء ${String.format(java.util.Locale.US, "%.2f", r.buyEst)} | بيع ${String.format(java.util.Locale.US, "%.2f", r.sellEst)} | Δ ${f(r.delta)} | ΣΔ ${f(r.cumDelta)}"
        }
    }

    data class FlowAnalysis(
        val buyImbalances: Int,
        val sellImbalances: Int,
        val dominantSide: String,
        val pressurePercent: Double,
        val interpretation: String,
        val trendAgreement: String,
        val limitations: String
    )

    /**
     * Order-flow interpretation from the supplied footprint.
     * A 3:1 level ratio is a descriptive imbalance threshold, not a trade signal.
     * OHLC-derived estimates must never be described as actual order flow.
     */
    fun analyzeFlow(footprint: Footprint, trendDirection: Int): FlowAnalysis {
        val buyImbalances = footprint.levels.count {
            it.buy > 0.0 && it.buy >= it.sell * 3.0
        }
        val sellImbalances = footprint.levels.count {
            it.sell > 0.0 && it.sell >= it.buy * 3.0
        }
        val total = footprint.totalBuy + footprint.totalSell
        val pressure = if (total > 0.0) {
            (kotlin.math.abs(footprint.delta) / total * 100.0).coerceIn(0.0, 100.0)
        } else 0.0
        val dominant = when {
            footprint.delta > 0.0 -> "ميل شرائي"
            footprint.delta < 0.0 -> "ميل بيعي"
            else -> "توازن تقريبي"
        }
        val trendAgreement = when {
            trendDirection == 0 -> "لا يمكن المقارنة: اتجاه Supertrend غير متاح."
            footprint.delta > 0.0 && trendDirection > 0 -> "توافق وصفي بين الميل الشرائي وSupertrend الصاعد."
            footprint.delta < 0.0 && trendDirection < 0 -> "توافق وصفي بين الميل البيعي وSupertrend الهابط."
            footprint.delta == 0.0 -> "لا يوجد ميل صافٍ واضح للمقارنة مع الاتجاه."
            else -> "تضارب: ضغط السعر المقدر/المقاس يعاكس اتجاه Supertrend؛ الأفضل انتظار تأكيد إضافي."
        }
        val interpretation = when {
            total <= 0.0 -> "لا توجد مستويات كافية لاستخلاص ميل من البيانات الحالية."
            footprint.delta > 0.0 && buyImbalances > sellImbalances ->
                "الميل الإجمالي وعدد مستويات الاختلال يميلان للشراء. هذا وصف للبيانات وليس توصية دخول."
            footprint.delta < 0.0 && sellImbalances > buyImbalances ->
                "الميل الإجمالي وعدد مستويات الاختلال يميلان للبيع. هذا وصف للبيانات وليس توصية دخول."
            else -> "الإشارات مختلطة أو غير حاسمة؛ لا توجد أفضلية واضحة من Footprint وحده."
        }
        val limitations = if (footprint.quality == DataQuality.ESTIMATED_FROM_OHLC) {
            "تنبيه: هذه المستويات تقديرية من OHLC وليست صفقات منفذة أو Bid/Ask. لا يمكن استنتاج Absorption أو Exhaustion أو تدفق أوامر حقيقي منها."
        } else {
            "البيانات مصنفة من صفقات المصدر. لا يمكن تأكيد Absorption أو Exhaustion من التجميع وحده؛ يلزم سياق زمني وحركة السعر/الشموع والتحقق من جودة تصنيف الطرف المبادر."
        }
        return FlowAnalysis(
            buyImbalances, sellImbalances, dominant, pressure,
            interpretation, trendAgreement, limitations
        )
    }

    fun summary(candles: List<Candle>): String {
        val f = fractals(candles)
        val st = supertrend(candles)
        val last = st.lastOrNull()
        val high = f.lastOrNull { it.isHigh }
        val low = f.lastOrNull { !it.isHigh }
        val span = candles.takeLast(30).let { cs ->
            val range = cs.maxOfOrNull { it.high }?.minus(cs.minOfOrNull { it.low } ?: 0.0) ?: 0.0
            (range / 100.0).coerceAtLeast(0.01)
        }
        val fp = estimatedFromCandles(candles, span / 20.0)
        return buildString {
            append("\n\nالمؤشرات المتقدمة\n")
            append("Fractal: ").append(if (high == null && low == null) "لا توجد قمة/قاع مؤكدة" else "آخر قمة ${high?.price ?: "—"} | آخر قاع ${low?.price ?: "—"}").append('\n')
            append("Supertrend (10, 3): ").append(when (last?.direction) { 1 -> "صاعد"; -1 -> "هابط"; else -> "بيانات غير كافية" }).append('\n')
            append("Footprint: تقديري | مستويات سعرية: ${fp.levels.size} | POC تقريبي: ${fp.poc ?: "—"}\n")
            append(fp.note)
        }
    }
}
